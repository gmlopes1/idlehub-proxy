# ⚡ Idle Hub — Navegador Multi‑Sessão com Workspaces

<div align="center">
<img src="docs/new_banner_idlehub.png" width="880" alt="Banner Idle Hub">

![Electron](https://img.shields.io/badge/Electron-44.1.1-47848f?style=for-the-badge&logo=electron)
![License](https://img.shields.io/badge/License-MIT-f1c644?style=for-the-badge&logo=opensource)
![Platform](https://img.shields.io/badge/Platform-Windows%20%7C%20macOS%20%7C%20Linux-0a0d14?style=for-the-badge)
![Status](https://img.shields.io/badge/Status-Ativo-4caf50?style=for-the-badge)

> 🎮 **Versão Adaptada para a Comunidade de Midgard Idle!**  
> Este repositório é um fork dedicado do Idle Hub, customizado especificamente para facilitar o gerenciamento de múltiplas contas, acesso rápido à Wiki, Ranking e Discord do **[Midgard Idle](https://midgardidle.ro/)**.
**Organize contas ilimitadas em workspaces isolados — cada sessão com seus próprios cookies, cache e logins.**

</div>

---

> 🍴 **Este é um fork** do [Idle Hub original](https://github.com/Diinhow/Idle-Hub), criado por [Diinhow](https://github.com/Diinhow). Todo o crédito da base do projeto é dele — aqui eu adiciono e ajusto algumas funcionalidades por cima. Veja o que mudou na seção [Sobre este fork](#-sobre-este-fork).

---

> [!NOTE]
> **📖 Documentação Interativa**:  
> Para visualizar a documentação completa com layout estilizado, acesse o arquivo **[`index.html`](https://diinhow.github.io/Idle-Hub/)** diretamente no seu navegador.

---

## 🖼️ Capturas de Tela

<div align="center">
  <table border="0" cellpadding="10">
    <tr>
      <td colspan="2" align="center">
        <img src="docs/janela-principal.png" width="880" alt="Modo Simples: painel com os números das seis contas">
      </td>
    </tr>
        <tr>
      <td colspan="2" align="center">
        <img src="docs/grid-customizado.png" width="880" alt="Grid personalizado: Deixe as telas no formato que desejar">
      </td>
    </tr>
            <tr>
      <td colspan="2" align="center">
        <img src="docs/opcoes-grid.png" width="880" alt="Grid personalizado: Deixe as telas no formato que desejar">
      </td>
    </tr>
    <tr>
      <td align="center">
        <img src="docs/userscript.png" width="486" height="620" alt="Suporte para UserScript/Tampermonkey">
      </td>
      <td align="center">
        <img src="docs/editarconta.png" width="486" height="705" alt="Editar Conta">
      </td>
    </tr>
  </table>
</div>

> Esta é a versão que roda a partir do código. Não tem executável pronto pra baixar: você pega o código, olha o que ele faz e roda você mesmo. Assim a confiança fica com você, não comigo.

> 🔰 **Nunca mexeu com isso?** Tem um passo a passo pra leigo aqui: **[TUTORIAL.md](docs/TUTORIAL.md)** (ou o arquivo `COMO USAR.txt` dentro da pasta).

> ### 🔒 Seus dados de login ficam só no seu computador
> Login e senha são criptografados no seu próprio PC e nunca saem dele. Nada de servidor, nada de repositório. O código está todo aqui pra você conferir.


## 🚀 Visão Geral

**Idle Hub** é um aplicativo desktop construído com **Electron** que transforma seu navegador em um **gerenciador de sessões múltiplas**. Ele permite criar **workspaces** (ex: "Principal", "Trabalho", "Pessoal") e, dentro de cada um, adicionar quantas **contas** desejar — cada uma com **cookies, cache e logins totalmente isolados**.

Ideal para quem gerencia múltiplos perfis em jogos, redes sociais, e‑commerce ou qualquer serviço que exija login único por sessão.


## ✨ Funcionalidades

| Ícone | Funcionalidade | Descrição |
| :---: | :--- | :--- |
| 📂 | **Workspaces** | Organize suas contas em categorias visuais com ícones, cores e layouts personalizados. Crie, duplique, renomeie e reordene via drag‑and‑drop. |
| 👤 | **Contas Isoladas** | Cada conta roda em uma partição separada do Electron. Cookies, cache, localStorage e sessões são totalmente independentes. |
| 🧩 | **Layouts Flexíveis** | Escolha entre grade automática, painel único, colunas, linhas, livre ou **grade personalizada** (defina linhas × colunas do seu jeito — inclusive formatos verticais como 1×3, 1×4 ou 2×4) para organizar os painéis de cada workspace. |
| 🔄 | **Recarregamento em Segundo Plano** | Troque entre workspaces sem perder o estado das contas — tudo permanece em memória e continua rodando em background. |
| 🔒 | **AutoPreenchimento de Conta** | Login/senha por conta. Preenche sozinho ao carregar o site (com cada site você pode desligar) ou manualmente com Ctrl+Shift+F. |
| 🔇 | **Mudo Global + Individual** | Um botão na barra superior silencia **todas as contas abertas, de todos os workspaces**, de uma vez. Cada conta também mantém seu próprio botão de mudo individual, que continua valendo assim que o mudo global é desligado. |
| 💰 | **Zeny/h na Barra de Status** | Soma em tempo real o "Saldo potencial/h" de todas as contas abertas e mostra o total na barra de status — sem precisar abrir a telemetria em cada uma. |
| 🎫 | **Kit de Diagnóstico (Tickets)** | Ferramentas de diagnóstico direto em cada conta, pra agilizar a abertura de tickets de suporte com a equipe do jogo. |
| ⬇️ | **Atualização Automática** | O app confere sozinho se tem versão nova assim que abre (via GitHub Releases) e baixa em segundo plano — só clicar em "Reiniciar agora" quando o aviso aparecer. |
| 📊 | **Métricas em Tempo Real** | Acompanhe CPU, RAM e FPS de cada conta e do processo principal na barra de status. |
| 🔍 | **Barra de URL Universal** | Digite uma URL e ela será aberta em todas as contas abertas do workspace atual com um clique. |
| 💾 | **Persistência Local** | Tudo é salvo automaticamente em `state.json`. Ao reabrir, o aplicativo restaura exatamente onde você parou. |
| 🌐 | **Export/Import** | Exporte toda a configuração de workspaces e contas para um arquivo `.json` e importe em outra máquina. |
| ⌨️ | **Atalhos de Teclado** | Navegue rapidamente entre painéis, recarregue, silencie e muito mais com atalhos intuitivos. |
| 🎨 | **Temas Escuro/Neon** | Escolha o tema que melhor se adapta à sua preferência visual. |
| 🐌 | **Modo Eco** | que segura o uso de CPU sem atrapalhar o progresso, troca o requestAnimationFrame por uma versão mais lenta. |

---

## 📦 Instalação

### Pré‑requisitos

Você precisa do Node.js instalado uma vez. Depois é rápido.

**1. Instale o Node.js**
Baixe a versão LTS em [nodejs.org](https://nodejs.org) e instale (é next, next, finish).

**2. Baixe este código**
Clique no botão verde **Code** aqui em cima e depois em **Download ZIP**. Extraia a pasta onde quiser. Quem usa Git pode clonar:
```bash
git clone https://github.com/Jaffrito/Idle-Hub.git
cd Idle-Hub
```
**3. Execute**
Dentro da pasta execute o arquivo Abrir IdleHub (.vbs).

## Como rodar (modo desenvolvimento)
```bash
npm install
npm start
```

## Como gerar um instalador (.exe / .dmg / .AppImage)
```bash
npm install
npm run dist
```

---

## 🍴 Sobre este fork (Midgard Idle Edition)

Baseado no [Idle Hub original](https://github.com/Diinhow/Idle-Hub) (créditos ao [Diinhow](https://github.com/Diinhow)). Esta versão foi adaptada e otimizada por **Jaffrito** especialmente para a comunidade do **Midgard Idle**.

### 📦 Histórico de Versões (VemSer)

- **v1.3.0 (Midgard Edition)** — Otimização inicial para a comunidade:
  - **URL Padrão pré-configurada:** O inicializador já aponta de fábrica para o site oficial do Midgard Idle (`https://midgardidle.ro/`).
  - **Atalhos rápidos na barra superior:** Acesso direto com um clique para a **Wiki**, **Ranking** e o **Discord** do jogo.
  - **Nova função "Abrir em nova janela":** Abre contas específicas em um grid próprio e independente fora do painel principal, mantendo perfeitamente a mesma sessão sincronizada (login/cookies).
  - **Atualização de engine:** Electron atualizado da versão 31.0.0 para 44.1.1 para ganho de performance e estabilidade.
  - Correções gerais de usabilidade e adaptações focadas na rotina dos jogadores.

- **v1.4.0 (Midgard Edition)** — Seletor Rápido, Botão de Pânico e Performance:
  - **Seletor Rápido de Contas (1–12):** Implementado na barra superior para alternância ágil entre instâncias ativas do jogo.
  - **Botão de Pânico (Recarregamento Global):** Novo botão na barra superior que limpa o cache HTTP e recarrega todas as contas de todos os workspaces simultaneamente após confirmação. Ideal para destravar telas após atualizações do jogo, mantendo intactos os dados de login, cookies e credenciais.
  - **Otimização de Background e Modo Eco:** Gerenciamento inteligente de ciclos de atualização visual (requestAnimationFrame), reduzindo o consumo de CPU em contas ocultas ou em segundo plano sem impactar o progresso idle.
  - **Atalhos Oficiais Integrados:** Acesso rápido por botão na interface para a Wiki, página de Rankings e servidor do Discord do Midgard Idle.
  - **Isolamento de Sessão:** Manutenção das partições independentes (persist:conta-id) para garantir cookies, caches e logins totalmente separados por conta.

- **v1.5.0 (Midgard Edition)** — Grade Personalizada, Mudo Global e Ajustes:
  - **Grade Personalizada:** Novo modo de layout que permite escolher livremente quantas linhas e colunas cada workspace usa (com atalhos prontos para 1×3, 1×4 e 2×4), além dos formatos quadrados já existentes.
  - **Mudo Global:** O botão de volume da barra superior agora silencia todas as contas abertas de uma vez, em qualquer workspace — o mudo individual de cada conta continua funcionando por baixo.
  - **Zeny/h na Barra de Status:** Soma automática do "Saldo potencial/h" de todas as contas abertas, exibida em tempo real.
  - **Modo Tela Limpa com Trava:** O botão de tela limpa virou multifunção — um clique esconde a interface (revelando ao encostar o mouse na borda, como antes), um segundo clique trava o painel lateral pra ele não aparecer mais nem passando o mouse.
  - **Correção da Tela Cheia (F11):** O botão/atalho de tela cheia voltou a esconder a barra de título corretamente.
  - **Otimização de Performance:** Removida rotina de monitoramento que rodava sem necessidade em todas as contas abertas; consultas de Zeny/h agora só rodam nas contas visíveis na tela, reduzindo o consumo em setups com várias contas abertas ao mesmo tempo.

- **v1.6.0 (Midgard Edition)** — Kit de Diagnóstico:
  - **Ferramentas de Diagnóstico (Kit-Ticket):** Novas ferramentas para gerar relatórios completos direto de cada conta, agilizando a abertura de tickets de suporte de forma mais eficiente.

- **v1.6.3 (Midgard Edition)** — Atualização Automática:
  - **Auto-Update:** O app confere sozinho se tem uma versão nova assim que abre e baixa em segundo plano direto das Releases do GitHub — basta clicar em "Reiniciar agora" quando o aviso aparecer, sem precisar baixar ZIP nem substituir pasta na mão.
  - Pequenas correções de exibição da versão na barra de status.

## Licença

MIT License. Projeto independente.
Idle Hub is made available under the MIT License — you are free to use it for commercial, non-commercial, closed or open projects.
