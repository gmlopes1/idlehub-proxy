
// ---------------------------------------------------------------------------
// i18n — traduções reais (pt/en/es), aplicadas sem precisar recarregar
// ---------------------------------------------------------------------------
// ============================================================
// Verificação de atualizações — link do Gist com o arquivo de versão.
// EDITE AQUI (só no código-fonte, não aparece em nenhum lugar da interface)
// se um dia você trocar de Gist. Formato esperado do arquivo .json dentro
// dele: { "version": "1.3.0", "url": "https://...", "message": "..." }
// ============================================================
const UPDATE_GIST_URL = 'https://gist.github.com/Jaffrito/f623667cd54a8e5473cf7bebfec0bcae';
// ============================================================
// Tema padrão para quem abre o app pela primeira vez.
// Troque para 'neon' se quiser que o tema Neon já venha ativado de cara
// (quem já tiver o app instalado e já tiver escolhido um tema não é afetado
// por essa constante — ela só vale pra configuração inicial/em branco).
// Valores válidos: 'escuro' | 'neon'
// ============================================================
const DEFAULT_THEME = 'escuro';
const I18N = {
  pt: {
    addAccount: 'Adicionar conta', emptyTitle: 'Nenhuma conta aberta',
    emptyDesc: 'Adicione contas a este workspace. Cada conta é uma sessão independente — login, cookies e cache próprios.',
    emptyBtn: 'Adicionar primeira conta', connected: 'Conectado', noActiveAccount: 'Nenhuma conta ativa',
    activeAccountSuffix: '{name} ativa', editAccount: 'Editar conta', accountName: 'Nome da conta',
    initialUrl: 'URL inicial / padrão', cancel: 'Cancelar', save: 'Salvar', editWorkspace: 'Editar workspace',
    collapseSidebar: 'Recolher barra lateral', closeAllTitle: 'Fechar todas as contas abertas',
    workspaceLabel: 'WORKSPACE', openImmediately: 'Abrir a conta assim que criar',
    credsLabel: 'LOGINS / AUTOPREENCHER',
    credsDesc: 'Login/senha por site. Preenche sozinho ao carregar o site (desligue o "Auto" de um site se preferir) ou manualmente com Ctrl+Shift+F.',
    credsAdd: 'Adicionar site', credsEmpty: 'Nenhum login salvo ainda.',
    credsLoginPh: 'Login / e-mail', credsPassPh: 'Senha', credsAuto: 'Auto',
    credsAutoTitle: 'Preencher automaticamente ao carregar este site',
    credsDel: 'Remover credencial', credsShow: 'Mostrar/ocultar senha',
    nameLabel: 'NOME', colorLabel: 'COR', iconLabel: 'ÍCONE', defaultUrlLabel: 'URL PADRÃO', layoutsLabel: 'LAYOUTS',
    layoutAuto: 'Grade automática', layoutSingle: 'Painel único', layoutColumns: 'Colunas', layoutRows: 'Linhas', layoutFree: 'Livre (redimensionável)',
    ctxReload: 'Recarregar', ctxDefaultUrl: 'Ir para a URL padrão', ctxMute: 'Silenciar painel', ctxUnmute: 'Reativar som',
    ctxClose: 'Fechar conta', ctxEdit: 'Editar conta', ctxDuplicate: 'Duplicar conta', ctxClearData: 'Limpar dados da sessão', ctxDelete: 'Excluir conta',
    ctxDevtools: 'Abrir DevTools (F12)', ctxOpenWindow: 'Abrir em nova janela',
    wsCtxEdit: 'Editar workspace', wsCtxDuplicate: 'Duplicar workspace', wsCtxDelete: 'Excluir workspace',
    confirmBtn: 'Confirmar', shortcutsTitle: 'Atalhos de teclado', settingsTitleModal: 'Configurações',
    tabGeneral: 'Geral', tabNav: 'Navegação', tabDownloads: 'Downloads', tabUpdates: 'Atualizações', tabAbout: 'Sobre',
    langLabel: 'Idioma', langSystem: 'Sistema', themeLabel: 'Tema', themeDark: 'Escuro',
    startWithSystem: 'Inicializar com o sistema', reopenLast: 'Reabrir o último workspace ao iniciar',
    cleanModeLabel: 'Modo tela limpa', cleanModeDesc: 'Esconde as barras, a lateral e os cabeçalhos dos painéis (Ctrl+Shift+Z)',
    edgeRevealLabel: 'Mostrar a interface ao encostar nas bordas',
    edgeRevealDesc: 'No modo tela limpa: encoste no topo para as barras, na lateral esquerda para o menu de contas',
    presentationTitle: 'Modo apresentação/gravação (Ctrl+Shift+P)',
    presentationModeLabel: 'Modo apresentação / gravação',
    presentationModeDesc: 'Borra nomes e URLs nos cabeçalhos (contas, sidebar, barra de endereço) — passe o mouse para revelar (Ctrl+Shift+P)',
    ecoModeTitle: 'Modo Eco — reduz uso de CPU (Ctrl+Shift+E)',
    ecoModeLabel: 'Modo Eco',
    ecoModeDesc: 'Reduz o uso de CPU da conta em foco deixando as animações mais lentas — o progresso do jogo não é afetado, só a atualização visual',
    shcEcoMode: 'Modo Eco (reduz CPU)',
    shcPresentation: 'Modo apresentação/gravação',
    shcFillCredentials: 'Preencher login/senha da conta ativa',
    exportBtn: 'Exportar workspaces', importBtn: 'Importar workspaces',
    defaultUrlSettings: 'URL inicial padrão', defaultZoomSettings: 'Zoom padrão para novas contas', defaultLayoutSettings: 'Layout padrão',
    downloadsFolder: 'Pasta de downloads', downloadsFolderDefault: 'Pasta padrão do sistema', chooseFolder: 'Escolher pasta...',
    askEachDownload: 'Perguntar onde salvar cada download',
    updatesIntro: 'O Idle Hub verifica um arquivo simples de versão (não baixa nem instala nada sozinho) — só avisa se tiver algo novo.',
    checkUpdates: 'Verificar atualizações',
    checkingUpdates: 'Verificando...', updatesUpToDate: 'Você está usando a versão mais recente deste projeto.',
    updateInvalidUrl: 'Configure um link de Gist válido (https://gist.github.com/usuario/id) antes de verificar.',
    updateCheckFailed: 'Não foi possível verificar atualizações agora. Confira o link do Gist e sua conexão com a internet.',
    updateAvailableBody: 'Tem uma versão nova disponível: {version}.',
    updateToastTitle: 'Atualização disponível', updateToastOpen: 'Abrir link',
    updateToastBody: 'Tem uma versão nova disponível: {version}.',
    aboutDesc: 'Gerenciador multi-sessão com workspaces: organize contas ilimitadas em grupos, cada uma com sessão isolada.',
    versionLabel: 'Versão', downloadsHead: 'DOWNLOADS', downloadsEmpty: 'Nenhum download nesta sessão',
    back: 'Voltar', forward: 'Avançar', reloadTitle: 'Recarregar (Ctrl+R)', homeTitle: 'Ir para a URL padrão do workspace',
    addressPh: 'Digite uma URL e pressione Enter… (Ctrl+L)', goAllTitle: 'Abrir esta URL em todas as contas abertas (deste workspace)',
    muteTitle: 'Silenciar conta ativa (Ctrl+M)', zoomTitle: 'Zoom da conta ativa', downloadsTitle: 'Downloads',
    cleanModeTitle: 'Modo tela limpa (Ctrl+Shift+Z)', fullscreenTitle: 'Tela cheia (F11)', settingsTitle: 'Configurações (Ctrl+,)', helpTitle: 'Ajuda / Atalhos (F1)',
    statusOnline: 'Online', statusClosed: 'Fechada', accountWord: 'Conta', copySuffix: '(cópia)',
    shcPanel19: 'Selecionar painel 1–9', shcNextPanel: 'Próximo painel', shcNewWorkspace: 'Novo workspace', shcNewAccount: 'Nova conta',
    shcReloadActive: 'Recarregar painel ativo', shcReloadNoCache: 'Recarregar ignorando cache', shcReloadAll: 'Recarregar todas',
    shcMuteActive: 'Silenciar painel ativo', shcMuteAll: 'Silenciar todas', shcFocusAddress: 'Focar barra de endereço',
    shcZoomIn: 'Aumentar zoom', shcZoomOut: 'Diminuir zoom', shcZoomReset: 'Restaurar zoom (100%)',
    shcCleanMode: 'Modo tela limpa', shcFullscreen: 'Tela cheia', shcSettings: 'Configurações', shcHelp: 'Ajuda',
    shcDeleteAccount: 'Excluir conta ativa', shcDevtools: 'Abrir DevTools da conta ativa',
    changeBtn: 'Alterar', pressKeys: 'Pressione uma tecla... (Esc cancela)',
    resetShortcutsBtn: 'Restaurar padrões', resetShortcutsTitle: 'Restaurar atalhos padrão?',
    resetShortcutsBody: 'Todos os atalhos personalizados voltam para o valor original. Essa ação não pode ser desfeita.',
    resetDividersBtn: 'Redefinir tamanho das divisórias',
    dblClickHint: 'Duplo clique para maximizar/restaurar',
    confirmDeleteWsTitle: 'Excluir este workspace?', confirmDeleteWsBody: 'O workspace e todas as suas contas serão removidos da lista. As sessões salvas em disco não são apagadas.',
    confirmDeleteAccTitle: 'Excluir esta conta?', confirmDeleteAccBody: 'A conta "{name}" será removida da lista. A sessão salva em disco não é apagada automaticamente.',
    confirmCloseAllTitle: 'Fechar todas as contas?', confirmCloseAllBody: 'Isso vai fechar {count} conta(s) aberta(s) neste workspace. As sessões salvas em disco não são apagadas.',
    confirmClearDataTitle: 'Limpar dados da sessão?', confirmClearDataBody: 'Cookies, cache e login da conta "{name}" serão apagados. Essa ação não pode ser desfeita.',
    confirmImportTitle: 'Importar workspaces?', confirmImportBody: 'Isso vai substituir todos os workspaces e contas atuais por este arquivo.',
    backupSaved: 'Backup salvo em:\n{path}',
  },
  en: {
    addAccount: 'Add account', emptyTitle: 'No accounts open',
    emptyDesc: 'Add accounts to this workspace. Each account is an independent session — its own login, cookies and cache.',
    emptyBtn: 'Add first account', connected: 'Connected', noActiveAccount: 'No active account',
    activeAccountSuffix: '{name} active', editAccount: 'Edit account', accountName: 'Account name',
    initialUrl: 'Initial / default URL', cancel: 'Cancel', save: 'Save', editWorkspace: 'Edit workspace',
    collapseSidebar: 'Collapse sidebar', closeAllTitle: 'Close all open accounts',
    workspaceLabel: 'WORKSPACE', openImmediately: 'Open the account right away',
    credsLabel: 'LOGINS / AUTOFILL',
    credsDesc: 'Username/password per site. Fills in automatically when the site loads (turn off "Auto" per site) or manually with Ctrl+Shift+F.',
    credsAdd: 'Add site', credsEmpty: 'No saved logins yet.',
    credsLoginPh: 'Username / email', credsPassPh: 'Password', credsAuto: 'Auto',
    credsAutoTitle: 'Fill automatically when this site loads',
    credsDel: 'Remove credential', credsShow: 'Show/hide password',
    nameLabel: 'NAME', colorLabel: 'COLOR', iconLabel: 'ICON', defaultUrlLabel: 'DEFAULT URL', layoutsLabel: 'LAYOUTS',
    layoutAuto: 'Auto grid', layoutSingle: 'Single panel', layoutColumns: 'Columns', layoutRows: 'Rows', layoutFree: 'Free (resizable)',
    ctxReload: 'Reload', ctxDefaultUrl: 'Go to default URL', ctxMute: 'Mute panel', ctxUnmute: 'Unmute',
    ctxClose: 'Close account', ctxEdit: 'Edit account', ctxDuplicate: 'Duplicate account', ctxClearData: 'Clear session data', ctxDelete: 'Delete account',
    ctxDevtools: 'Open DevTools (F12)', ctxOpenWindow: 'Open in new window',
    wsCtxEdit: 'Edit workspace', wsCtxDuplicate: 'Duplicate workspace', wsCtxDelete: 'Delete workspace',
    confirmBtn: 'Confirm', shortcutsTitle: 'Keyboard shortcuts', settingsTitleModal: 'Settings',
    tabGeneral: 'General', tabNav: 'Browsing', tabDownloads: 'Downloads', tabUpdates: 'Updates', tabAbout: 'About',
    langLabel: 'Language', langSystem: 'System', themeLabel: 'Theme', themeDark: 'Dark',
    startWithSystem: 'Launch on system startup', reopenLast: 'Reopen last workspace on launch',
    cleanModeLabel: 'Clean screen mode', cleanModeDesc: 'Hides the bars, sidebar and panel headers (Ctrl+Shift+Z)',
    edgeRevealLabel: 'Reveal interface near screen edges',
    edgeRevealDesc: 'In clean mode: hover the top edge for the bars, left edge for the accounts panel',
    presentationTitle: 'Presentation/recording mode (Ctrl+Shift+P)',
    presentationModeLabel: 'Presentation / recording mode',
    presentationModeDesc: 'Blurs names and URLs in headers (accounts, sidebar, address bar) — hover to reveal (Ctrl+Shift+P)',
    ecoModeTitle: 'Eco mode — reduces CPU usage (Ctrl+Shift+E)',
    ecoModeLabel: 'Eco mode',
    ecoModeDesc: "Reduces CPU usage of the focused account by slowing down animations — game progress isn't affected, only how often the screen redraws",
    shcEcoMode: 'Eco mode (reduce CPU)',
    shcPresentation: 'Presentation/recording mode',
    shcFillCredentials: 'Fill active account login/password',
    exportBtn: 'Export workspaces', importBtn: 'Import workspaces',
    defaultUrlSettings: 'Default initial URL', defaultZoomSettings: 'Default zoom for new accounts', defaultLayoutSettings: 'Default layout',
    downloadsFolder: 'Downloads folder', downloadsFolderDefault: 'System default folder', chooseFolder: 'Choose folder...',
    askEachDownload: 'Ask where to save each download',
    updatesIntro: "Idle Hub checks a simple version file (it doesn't download or install anything on its own) — it just lets you know if there's something new.",
    checkUpdates: 'Check for updates',
    checkingUpdates: 'Checking...', updatesUpToDate: 'You are using the latest version of this project.',
    updateInvalidUrl: 'Set a valid Gist link (https://gist.github.com/user/id) before checking.',
    updateCheckFailed: "Couldn't check for updates right now. Check the Gist link and your internet connection.",
    updateAvailableBody: 'A new version is available: {version}.',
    updateToastTitle: 'Update available', updateToastOpen: 'Open link',
    updateToastBody: 'A new version is available: {version}.',
    aboutDesc: 'Multi-session manager with workspaces: organize unlimited accounts into groups, each with an isolated session.',
    versionLabel: 'Version', downloadsHead: 'DOWNLOADS', downloadsEmpty: 'No downloads this session',
    back: 'Back', forward: 'Forward', reloadTitle: 'Reload (Ctrl+R)', homeTitle: "Go to the workspace's default URL",
    addressPh: 'Type a URL and press Enter… (Ctrl+L)', goAllTitle: 'Open this URL in all open accounts (this workspace)',
    muteTitle: 'Mute active account (Ctrl+M)', zoomTitle: 'Zoom of the active account', downloadsTitle: 'Downloads',
    cleanModeTitle: 'Clean screen mode (Ctrl+Shift+Z)', fullscreenTitle: 'Fullscreen (F11)', settingsTitle: 'Settings (Ctrl+,)', helpTitle: 'Help / Shortcuts (F1)',
    statusOnline: 'Online', statusClosed: 'Closed', accountWord: 'Account', copySuffix: '(copy)',
    shcPanel19: 'Select panel 1–9', shcNextPanel: 'Next panel', shcNewWorkspace: 'New workspace', shcNewAccount: 'New account',
    shcReloadActive: 'Reload active panel', shcReloadNoCache: 'Reload ignoring cache', shcReloadAll: 'Reload all',
    shcMuteActive: 'Mute active panel', shcMuteAll: 'Mute all', shcFocusAddress: 'Focus address bar',
    shcZoomIn: 'Zoom in', shcZoomOut: 'Zoom out', shcZoomReset: 'Reset zoom (100%)',
    shcCleanMode: 'Clean screen mode', shcFullscreen: 'Fullscreen', shcSettings: 'Settings', shcHelp: 'Help',
    shcDeleteAccount: 'Delete active account', shcDevtools: "Open active account's DevTools",
    changeBtn: 'Change', pressKeys: 'Press a key... (Esc cancels)',
    resetShortcutsBtn: 'Reset to defaults', resetShortcutsTitle: 'Reset default shortcuts?',
    resetShortcutsBody: 'All custom shortcuts go back to their original value. This cannot be undone.',
    resetDividersBtn: 'Reset divider sizes',
    dblClickHint: 'Double-click to maximize/restore',
    confirmDeleteWsTitle: 'Delete this workspace?', confirmDeleteWsBody: 'The workspace and all its accounts will be removed from the list. Sessions saved on disk are not deleted.',
    confirmDeleteAccTitle: 'Delete this account?', confirmDeleteAccBody: 'The account "{name}" will be removed from the list. The session saved on disk is not automatically deleted.',
    confirmCloseAllTitle: 'Close all accounts?', confirmCloseAllBody: 'This will close {count} open account(s) in this workspace. Sessions saved on disk are not deleted.',
    confirmClearDataTitle: 'Clear session data?', confirmClearDataBody: 'Cookies, cache and login for "{name}" will be erased. This cannot be undone.',
    confirmImportTitle: 'Import workspaces?', confirmImportBody: 'This will replace all current workspaces and accounts with this file.',
    backupSaved: 'Backup saved to:\n{path}',
  },
  es: {
    addAccount: 'Añadir cuenta', emptyTitle: 'Ninguna cuenta abierta',
    emptyDesc: 'Añade cuentas a este workspace. Cada cuenta es una sesión independiente: su propio inicio de sesión, cookies y caché.',
    emptyBtn: 'Añadir primera cuenta', connected: 'Conectado', noActiveAccount: 'Ninguna cuenta activa',
    activeAccountSuffix: '{name} activa', editAccount: 'Editar cuenta', accountName: 'Nombre de la cuenta',
    initialUrl: 'URL inicial / predeterminada', cancel: 'Cancelar', save: 'Guardar', editWorkspace: 'Editar workspace',
    collapseSidebar: 'Contraer barra lateral', closeAllTitle: 'Cerrar todas las cuentas abiertas',
    workspaceLabel: 'WORKSPACE', openImmediately: 'Abrir la cuenta al crear',
    credsLabel: 'INICIOS DE SESIÓN / AUTORELLENO',
    credsDesc: 'Usuario/contraseña por sitio. Rellena solo al cargar el sitio (desactiva "Auto" por sitio) o manualmente con Ctrl+Shift+F.',
    credsAdd: 'Añadir sitio', credsEmpty: 'Aún no hay inicios de sesión guardados.',
    credsLoginPh: 'Usuario / correo', credsPassPh: 'Contraseña', credsAuto: 'Auto',
    credsAutoTitle: 'Rellenar automáticamente al cargar este sitio',
    credsDel: 'Quitar credencial', credsShow: 'Mostrar/ocultar contraseña',
    nameLabel: 'NOMBRE', colorLabel: 'COLOR', iconLabel: 'ICONO', defaultUrlLabel: 'URL PREDETERMINADA', layoutsLabel: 'DISEÑOS',
    layoutAuto: 'Cuadrícula automática', layoutSingle: 'Panel único', layoutColumns: 'Columnas', layoutRows: 'Filas', layoutFree: 'Libre (redimensionable)',
    ctxReload: 'Recargar', ctxDefaultUrl: 'Ir a la URL predeterminada', ctxMute: 'Silenciar panel', ctxUnmute: 'Reactivar sonido',
    ctxClose: 'Cerrar cuenta', ctxEdit: 'Editar cuenta', ctxDuplicate: 'Duplicar cuenta', ctxClearData: 'Borrar datos de la sesión', ctxDelete: 'Eliminar cuenta',
    ctxDevtools: 'Abrir DevTools (F12)', ctxOpenWindow: 'Abrir en nueva ventana',
    wsCtxEdit: 'Editar workspace', wsCtxDuplicate: 'Duplicar workspace', wsCtxDelete: 'Eliminar workspace',
    confirmBtn: 'Confirmar', shortcutsTitle: 'Atajos de teclado', settingsTitleModal: 'Configuración',
    tabGeneral: 'General', tabNav: 'Navegación', tabDownloads: 'Descargas', tabUpdates: 'Actualizaciones', tabAbout: 'Acerca de',
    langLabel: 'Idioma', langSystem: 'Sistema', themeLabel: 'Tema', themeDark: 'Oscuro',
    startWithSystem: 'Iniciar con el sistema', reopenLast: 'Reabrir el último workspace al iniciar',
    cleanModeLabel: 'Modo pantalla limpia', cleanModeDesc: 'Oculta las barras, la lateral y los encabezados de los paneles (Ctrl+Shift+Z)',
    edgeRevealLabel: 'Mostrar la interfaz al tocar los bordes',
    edgeRevealDesc: 'En modo pantalla limpia: toca el borde superior para las barras, el izquierdo para el menú de cuentas',
    presentationTitle: 'Modo presentación/grabación (Ctrl+Shift+P)',
    presentationModeLabel: 'Modo presentación / grabación',
    presentationModeDesc: 'Difumina nombres y URLs en los encabezados (cuentas, barra lateral, barra de direcciones) — pasa el mouse para revelar (Ctrl+Shift+P)',
    ecoModeTitle: 'Modo Eco — reduce el uso de CPU (Ctrl+Shift+E)',
    ecoModeLabel: 'Modo Eco',
    ecoModeDesc: 'Reduce el uso de CPU de la cuenta activa ralentizando las animaciones — el progreso del juego no se ve afectado, solo la frecuencia de actualización visual',
    shcEcoMode: 'Modo Eco (reduce CPU)',
    shcPresentation: 'Modo presentación/grabación',
    shcFillCredentials: 'Rellenar usuario/contraseña de la cuenta activa',
    exportBtn: 'Exportar workspaces', importBtn: 'Importar workspaces',
    defaultUrlSettings: 'URL inicial predeterminada', defaultZoomSettings: 'Zoom predeterminado para nuevas cuentas', defaultLayoutSettings: 'Diseño predeterminado',
    downloadsFolder: 'Carpeta de descargas', downloadsFolderDefault: 'Carpeta predeterminada del sistema', chooseFolder: 'Elegir carpeta...',
    askEachDownload: 'Preguntar dónde guardar cada descarga',
    updatesIntro: 'Idle Hub verifica un archivo simple de versión (no descarga ni instala nada por su cuenta) — solo avisa si hay algo nuevo.',
    checkUpdates: 'Buscar actualizaciones',
    checkingUpdates: 'Verificando...', updatesUpToDate: 'Estás usando la versión más reciente de este proyecto.',
    updateInvalidUrl: 'Configura un enlace de Gist válido (https://gist.github.com/usuario/id) antes de verificar.',
    updateCheckFailed: 'No se pudo verificar actualizaciones ahora. Revisa el enlace del Gist y tu conexión a internet.',
    updateAvailableBody: 'Hay una versión nueva disponible: {version}.',
    updateToastTitle: 'Actualización disponible', updateToastOpen: 'Abrir enlace',
    updateToastBody: 'Hay una versión nueva disponible: {version}.',
    aboutDesc: 'Gestor multisesión con workspaces: organiza cuentas ilimitadas en grupos, cada una con sesión aislada.',
    versionLabel: 'Versión', downloadsHead: 'DESCARGAS', downloadsEmpty: 'Ninguna descarga en esta sesión',
    back: 'Atrás', forward: 'Adelante', reloadTitle: 'Recargar (Ctrl+R)', homeTitle: 'Ir a la URL predeterminada del workspace',
    addressPh: 'Escribe una URL y presiona Enter… (Ctrl+L)', goAllTitle: 'Abrir esta URL en todas las cuentas abiertas (este workspace)',
    muteTitle: 'Silenciar cuenta activa (Ctrl+M)', zoomTitle: 'Zoom de la cuenta activa', downloadsTitle: 'Descargas',
    cleanModeTitle: 'Modo pantalla limpia (Ctrl+Shift+Z)', fullscreenTitle: 'Pantalla completa (F11)', settingsTitle: 'Configuración (Ctrl+,)', helpTitle: 'Ayuda / Atajos (F1)',
    statusOnline: 'Online', statusClosed: 'Cerrada', accountWord: 'Cuenta', copySuffix: '(copia)',
    shcPanel19: 'Seleccionar panel 1–9', shcNextPanel: 'Panel siguiente', shcNewWorkspace: 'Nuevo workspace', shcNewAccount: 'Nueva cuenta',
    shcReloadActive: 'Recargar panel activo', shcReloadNoCache: 'Recargar ignorando caché', shcReloadAll: 'Recargar todas',
    shcMuteActive: 'Silenciar panel activo', shcMuteAll: 'Silenciar todas', shcFocusAddress: 'Enfocar barra de direcciones',
    shcZoomIn: 'Acercar zoom', shcZoomOut: 'Alejar zoom', shcZoomReset: 'Restablecer zoom (100%)',
    shcCleanMode: 'Modo pantalla limpia', shcFullscreen: 'Pantalla completa', shcSettings: 'Configuración', shcHelp: 'Ayuda',
    shcDeleteAccount: 'Eliminar cuenta activa', shcDevtools: 'Abrir DevTools de la cuenta activa',
    changeBtn: 'Cambiar', pressKeys: 'Presiona una tecla... (Esc cancela)',
    resetShortcutsBtn: 'Restablecer predeterminados', resetShortcutsTitle: '¿Restablecer atajos predeterminados?',
    resetShortcutsBody: 'Todos los atajos personalizados vuelven a su valor original. Esta acción no se puede deshacer.',
    resetDividersBtn: 'Restablecer tamaño de las divisiones',
    dblClickHint: 'Doble clic para maximizar/restaurar',
    confirmDeleteWsTitle: '¿Eliminar este workspace?', confirmDeleteWsBody: 'El workspace y todas sus cuentas se eliminarán de la lista. Las sesiones guardadas en disco no se borran.',
    confirmDeleteAccTitle: '¿Eliminar esta cuenta?', confirmDeleteAccBody: 'La cuenta "{name}" se eliminará de la lista. La sesión guardada en disco no se borra automáticamente.',
    confirmCloseAllTitle: '¿Cerrar todas las cuentas?', confirmCloseAllBody: 'Esto cerrará {count} cuenta(s) abierta(s) en este workspace. Las sesiones guardadas en disco no se borran.',
    confirmClearDataTitle: '¿Borrar datos de la sesión?', confirmClearDataBody: 'Se borrarán cookies, caché e inicio de sesión de "{name}". Esta acción no se puede deshacer.',
    confirmImportTitle: '¿Importar workspaces?', confirmImportBody: 'Esto reemplazará todos los workspaces y cuentas actuales por este archivo.',
    backupSaved: 'Copia de seguridad guardada en:\n{path}',
  },
};
let currentLang = 'pt';
function t(key, vars) {
  let str = (I18N[currentLang] && I18N[currentLang][key]) || I18N.pt[key] || key;
  if (vars) Object.keys(vars).forEach((k) => { str = str.replace(`{${k}}`, vars[k]); });
  return str;
}
function detectSystemLang() {
  const l = (navigator.language || 'pt').toLowerCase();
  if (l.startsWith('pt')) return 'pt';
  if (l.startsWith('es')) return 'es';
  return 'en';
}
function applyLanguage(langSetting) {
  currentLang = langSetting === 'sistema' ? detectSystemLang() : (I18N[langSetting] ? langSetting : 'pt');
  document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll('[data-i18n-title]').forEach((el) => { el.dataset.tooltip = t(el.dataset.i18nTitle); });
  document.querySelectorAll('[data-i18n-ph]').forEach((el) => { el.placeholder = t(el.dataset.i18nPh); });
  renderSidebar(); updateStatusBar(); renderShortcutsList();
  if (!$('#downloads-popover').classList.contains('hidden')) renderDownloadsList();
}
function applyTheme(tema) {
  document.body.classList.toggle('theme-neon', tema === 'neon');
}
// ---------------------------------------------------------------------------
// Ícones: baseados na biblioteca Lucide (https://lucide.dev, licença ISC — open source de verdade)
// ---------------------------------------------------------------------------
const ICONS = {
  apps: '<svg viewBox="0 0 24 24"><rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/></svg>',
  controller: '<svg viewBox="0 0 24 24"><line x1="6" x2="10" y1="11" y2="11"/><line x1="8" x2="8" y1="9" y2="13"/><line x1="15" x2="15.01" y1="12" y2="12"/><line x1="18" x2="18.01" y1="10" y2="10"/><path d="M17.32 5H6.68a4 4 0 0 0-3.978 3.59c-.006.052-.01.101-.017.152C2.604 9.416 2 14.456 2 16a3 3 0 0 0 3 3c1 0 1.5-.5 2-1l1.414-1.414A2 2 0 0 1 9.828 16h4.344a2 2 0 0 1 1.414.586L17 18c.5.5 1 1 2 1a3 3 0 0 0 3-3c0-1.545-.604-6.584-.685-7.258-.007-.05-.011-.1-.017-.151A4 4 0 0 0 17.32 5z"/></svg>',
  swords: '<svg viewBox="0 0 24 24"><polyline points="14.5 17.5 3 6 3 3 6 3 17.5 14.5"/><line x1="13" x2="19" y1="19" y2="13"/><line x1="16" x2="20" y1="16" y2="20"/><line x1="19" x2="21" y1="21" y2="19"/><polyline points="14.5 6.5 18 3 21 3 21 6 17.5 9.5"/><line x1="5" x2="9" y1="14" y2="18"/><line x1="7" x2="4" y1="17" y2="20"/><line x1="3" x2="5" y1="19" y2="21"/></svg>',
  shield: '<svg viewBox="0 0 24 24"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/></svg>',
  flame: '<svg viewBox="0 0 24 24"><path d="M12 3q1 4 4 6.5t3 5.5a1 1 0 0 1-14 0 5 5 0 0 1 1-3 1 1 0 0 0 5 0c0-2-1.5-3-1.5-5q0-2 2.5-4"/></svg>',
  leaf: '<svg viewBox="0 0 24 24"><path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/></svg>',
  drop: '<svg viewBox="0 0 24 24"><path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z"/></svg>',
  bolt: '<svg viewBox="0 0 24 24"><path d="M15.914 4a1.5 1.5 0 00-2.474-1.561l-9 9A1.5 1.5 0 005.5 14h4.002a.5.5 0 01.471.666L8.086 20a1.5 1.5 0 002.475 1.56l9-9A1.5 1.5 0 0018.5 10h-3.997a.5.5 0 01-.472-.667z"/></svg>',
  star: '<svg viewBox="0 0 24 24"><path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"/></svg>',
  crown: '<svg viewBox="0 0 24 24"><path d="M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.734H5.81a1 1 0 0 1-.957-.734L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z"/><path d="M5 21h14"/></svg>',
  ghost: '<svg viewBox="0 0 24 24"><path d="M9 10h.01"/><path d="M15 10h.01"/><path d="M12 2a8 8 0 0 0-8 8v12l3-3 2.5 2.5L12 19l2.5 2.5L17 19l3 3V10a8 8 0 0 0-8-8z"/></svg>',
  rocket: '<svg viewBox="0 0 24 24"><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09"/><path d="M9 12a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.4 22.4 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 .05 5 .05"/></svg>',
};
const ICON_KEYS = ['apps', 'controller', 'swords', 'shield', 'flame', 'leaf', 'drop', 'bolt', 'star', 'crown', 'ghost', 'rocket'];
const ICONS_MINI = {
  reload: '<svg viewBox="0 0 24 24"><path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/></svg>',
  expand: '<svg viewBox="0 0 24 24"><path d="M8 3H5a2 2 0 0 0-2 2v3"/><path d="M21 8V5a2 2 0 0 0-2-2h-3"/><path d="M3 16v3a2 2 0 0 0 2 2h3"/><path d="M16 21h3a2 2 0 0 0 2-2v-3"/></svg>',
  close: '<svg viewBox="0 0 24 24"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>',
  openWindow: '<svg viewBox="0 0 24 24"><path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/></svg>',
  soundOn: '<svg viewBox="0 0 24 24"><path d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z"/><path d="M16 9a5 5 0 0 1 0 6"/><path d="M19.364 18.364a9 9 0 0 0 0-12.728"/></svg>',
  soundOff: '<svg viewBox="0 0 24 24"><path d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z"/><line x1="22" x2="16" y1="9" y2="15"/><line x1="16" x2="22" y1="9" y2="15"/></svg>',
  // Ícone de envelope — botão do Kit-Ticket
  report: '<svg viewBox="0 0 24 24"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>',
  // Ícone de círculo (ponto de gravação) — botão de captura de rede (HAR)
  record: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/></svg>',
  // Ícone de quadrado — mesmo botão, mas enquanto a gravação está em andamento
  recordStop: '<svg viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="1"/></svg>',
};
function muteIcon(muted) { return muted ? ICONS_MINI.soundOff : ICONS_MINI.soundOn; }
const COLORS = ['#e3b341', '#38bdf8', '#34d399', '#f87171', '#a78bfa', '#fb923c', '#f472b6', '#22d3ee'];
const ACCOUNT_COLORS = COLORS;
const DEFAULT_URL = 'https://midgardidle.ro/';
// ---------------------------------------------------------------------------
// Estado global
// ---------------------------------------------------------------------------
let state = {
  nextWorkspaceId: 1, nextAccountId: 1, activeWorkspaceId: null, sidebarCollapsed: false,
  workspaces: [], settings: null, scripts: [],
};
let activeAccountId = null;
let saveTimer = null;
// ---------------------------------------------------------------------------
// Modo "janela avulsa" (aberta via "Abrir em nova janela"): o index.html é
// recarregado numa segunda BrowserWindow com ?standalone=1&account=<json>.
// Nesse modo a janela vira um novo grid independente, com essa conta já
// aberta — mas usando a MESMA partition/sessão dela, então login/cookies
// continuam sincronizados com o painel do grid principal. Esse estado é
// só em memória: nunca lê nem grava o state.json do app principal, então
// contas extras adicionadas aqui somem ao fechar a janela.
// ---------------------------------------------------------------------------
function parseStandaloneAccountFromQuery() {
  try {
    const params = new URLSearchParams(window.location.search);
    if (params.get('standalone') !== '1') return null;
    const raw = params.get('account');
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (err) {
    console.error('Erro ao ler dados da conta desta janela avulsa:', err);
    return null;
  }
}
const STANDALONE_ACCOUNT = parseStandaloneAccountFromQuery();
const $ = (sel) => document.querySelector(sel);
const workspaceIconsEl = $('#workspace-icons');
const accountListEl = $('#account-list');
const grid = $('#grid');
const addressBar = $('#address-bar');
function defaultSettings() {
  return {
    idioma: 'sistema', tema: DEFAULT_THEME, iniciarComSistema: false, reabrirUltimoWorkspace: true,
    urlInicialPadrao: DEFAULT_URL, zoomPadrao: 1, layoutPadrao: 'auto',
    downloadsPath: null, perguntarOndeSalvar: true, modoTelaLimpa: false, encostarBordas: true,
    modoApresentacao: false,
    modoEco: false,
    mudoGlobal: false,
  };
}
function effectiveMuted(acc) { return !!state.settings.mudoGlobal || !!(acc && acc.muted); }
// ---------------------------------------------------------------------------
// Utilidades
// ---------------------------------------------------------------------------
function normalizeUrl(u) { return /^https?:\/\//i.test(u) ? u : 'https://' + u; }
function escapeHtml(str) { const d = document.createElement('div'); d.textContent = str == null ? '' : str; return d.innerHTML; }
function formatUptime(createdAt) {
  const totalSecs = Math.floor((Date.now() - createdAt) / 1000);
  const days = Math.floor(totalSecs / 86400);
  const hours = Math.floor((totalSecs % 86400) / 3600);
  const mins = Math.floor((totalSecs % 3600) / 60);
  const secs = totalSecs % 60;
  if (days > 0) return `${days}d ${hours}h`;
  if (hours > 0) return `${hours}h ${mins}m`;
  return `${mins}m ${secs}s`;
}
function getActiveWorkspace() { return state.workspaces.find((w) => w.id === state.activeWorkspaceId) || state.workspaces[0]; }
function getAccountById(id) {
  for (const ws of state.workspaces) { const a = ws.accounts.find((x) => x.id === id); if (a) return a; }
  return null;
}
function getActiveAccount() { return activeAccountId ? getAccountById(activeAccountId) : null; }
function getActiveCard() { return activeAccountId ? grid.querySelector(`.account-card[data-id="${activeAccountId}"]`) : null; }
function getActiveWebview() { const card = getActiveCard(); return card ? card.querySelector('webview') : null; }
function getOpenAccountsOfActiveWorkspace() {
  const ws = getActiveWorkspace();
  return ws ? ws.accounts.filter((a) => a.status === 'open') : [];
}
let isDirty = false;
function schedulePersist() {
  if (STANDALONE_ACCOUNT) return; // janela avulsa nunca grava no state.json do app principal
  isDirty = true;
  clearTimeout(saveTimer);
  saveTimer = setTimeout(persistState, 400);
}
function serializeState() {
  return {
    nextWorkspaceId: state.nextWorkspaceId, nextAccountId: state.nextAccountId,
    activeWorkspaceId: state.activeWorkspaceId, sidebarCollapsed: state.sidebarCollapsed, settings: state.settings,
    scripts: state.scripts,
    workspaces: state.workspaces.map((ws) => ({
      id: ws.id, name: ws.name, color: ws.color, iconKey: ws.iconKey, defaultUrl: ws.defaultUrl, layout: ws.layout,
      accounts: ws.accounts.map((a) => ({
        id: a.id, name: a.name, url: a.url, defaultUrl: a.defaultUrl, partition: a.partition,
        colorIdx: a.colorIdx, iconKey: a.iconKey || 'apps', status: a.status, muted: !!a.muted, createdAt: a.createdAt,
        zoomFactor: a.zoomFactor || 1, freeWidth: a.freeWidth || null, freeHeight: a.freeHeight || null,
      })),
      autoGridColFr: ws.autoGridColFr || null, autoGridRowFr: ws.autoGridRowFr || null,
    })),
  };
}
async function persistState() {
  isDirty = false;
  try { await window.nativeAPI.saveState(serializeState()); } catch (err) { console.error('Erro ao salvar estado', err); }
}
// ---------------------------------------------------------------------------
// Inicialização
// ---------------------------------------------------------------------------
async function init() {
  let loaded = null;
  if (!STANDALONE_ACCOUNT) {
    try { loaded = await window.nativeAPI.loadState(); } catch (err) { console.error('Erro ao carregar estado salvo', err); }
  }
  if (STANDALONE_ACCOUNT) {
    // Novo grid independente com só essa conta (mesma partition/sessão dela).
    state.settings = defaultSettings();
    const wsId = state.nextWorkspaceId++;
    const ws = {
      id: wsId, name: STANDALONE_ACCOUNT.name || 'Idle Hub', color: COLORS[(STANDALONE_ACCOUNT.colorIdx || 0) % COLORS.length],
      iconKey: STANDALONE_ACCOUNT.iconKey || 'apps', defaultUrl: STANDALONE_ACCOUNT.url || DEFAULT_URL, layout: 'auto', accounts: [],
    };
    state.workspaces.push(ws);
    state.activeWorkspaceId = wsId;
    // Semente alta pro contador de ids: contas novas criadas só nesta janela
    // (via "Adicionar conta") não podem colidir com o id/partition da conta
    // real que abriu a janela nem com nenhuma outra do app principal.
    state.nextAccountId = Date.now();
    const accId = STANDALONE_ACCOUNT.id;
    ws.accounts.push({
      id: accId, name: STANDALONE_ACCOUNT.name || t('accountWord'), url: STANDALONE_ACCOUNT.url, defaultUrl: STANDALONE_ACCOUNT.url,
      partition: STANDALONE_ACCOUNT.partition, colorIdx: STANDALONE_ACCOUNT.colorIdx || 0, iconKey: STANDALONE_ACCOUNT.iconKey || 'apps',
      status: 'open', muted: !!STANDALONE_ACCOUNT.muted, zoomFactor: STANDALONE_ACCOUNT.zoomFactor || 1,
      createdAt: Date.now(), webContentsId: null, pid: null,
    });
  } else if (loaded && loaded.workspaces && loaded.workspaces.length) {
    state = loaded;
    if (!Array.isArray(state.scripts)) state.scripts = [];
    state.settings = { ...defaultSettings(), ...(state.settings || {}) };
    state.workspaces.forEach((ws) => {
      if (!ws.color) ws.color = COLORS[0];
      if (!ws.iconKey) ws.iconKey = 'apps';
      if (!ws.layout) ws.layout = state.settings.layoutPadrao || 'auto';
      if (!ws.defaultUrl) ws.defaultUrl = state.settings.urlInicialPadrao || DEFAULT_URL;
      ws.accounts.forEach((a) => { if (!a.zoomFactor) a.zoomFactor = 1; if (!a.iconKey) a.iconKey = 'apps'; a.webContentsId = null; a.pid = null; });
    });
    if (state.settings.reabrirUltimoWorkspace === false) state.activeWorkspaceId = state.workspaces[0].id;
  } else {
    state.settings = defaultSettings();
    const wsId = state.nextWorkspaceId++;
    const ws = { id: wsId, name: 'Principal', color: COLORS[0], iconKey: 'apps', defaultUrl: state.settings.urlInicialPadrao, layout: state.settings.layoutPadrao, accounts: [] };
    state.workspaces.push(ws);
    state.activeWorkspaceId = wsId;
    const accId = state.nextAccountId++;
    ws.accounts.push({
      id: accId, name: 'Conta 1', url: ws.defaultUrl, defaultUrl: ws.defaultUrl,
      partition: `persist:conta-${accId}`, colorIdx: 0, status: 'open', muted: false, zoomFactor: 1,
      createdAt: Date.now(), webContentsId: null, pid: null,
    });
  }
  if (!state.activeWorkspaceId) state.activeWorkspaceId = state.workspaces[0].id;
  if (state.sidebarCollapsed) applySidebarCollapsed(true);
  applyLanguage(state.settings.idioma);
  applyTheme(state.settings.tema);
  applyCleanMode();
  applyPresentationMode();
  applyEcoMode();
  if (STANDALONE_ACCOUNT) hideStandaloneChrome();
  renderWorkspaceRail();
  renderSidebar();
  renderGrid();
  updateStatusBar();
  updateNavButtons();
  updateZoomLabel();
  updateMuteButton();
  try { state.settings.iniciarComSistema = !!(await window.nativeAPI.getLoginItem()); } catch (err) { /* ignore */ }
  // As credenciais salvas continuam valendo (mesmo id/mesma conta real), mas
  // não faz sentido checar atualização a cada janela avulsa aberta.
  await loadCredentials();
  if (!STANDALONE_ACCOUNT) checkForUpdatesOnStartup();
}
// ---------------------------------------------------------------------------
// Janela avulsa: esconde o que não se aplica a um grid de conta única — a
// coluna de workspaces (não há múltiplos workspaces aqui) e o botão de doar.
// ---------------------------------------------------------------------------
function hideStandaloneChrome() {
  const rail = $('#workspace-rail'); if (rail) rail.style.display = 'none';
  const donateBtn = $('#donate-btn'); if (donateBtn) donateBtn.style.display = 'none';
  const renameWsBtn = $('#rename-workspace-btn'); if (renameWsBtn) renameWsBtn.style.display = 'none';
}
// ---------------------------------------------------------------------------
// Sidebar recolher/expandir
// ---------------------------------------------------------------------------
function applySidebarCollapsed(collapsed) {
  $('#sidebar').classList.toggle('collapsed', collapsed);
  $('#sidebar-collapsed-strip').classList.toggle('hidden', !collapsed);
}
$('#collapse-sidebar-btn').addEventListener('click', () => { state.sidebarCollapsed = true; applySidebarCollapsed(true); schedulePersist(); });
$('#expand-sidebar-btn').addEventListener('click', () => { state.sidebarCollapsed = false; applySidebarCollapsed(false); schedulePersist(); });
// ---------------------------------------------------------------------------
// Modo tela limpa (+ revelar interface ao encostar nas bordas)
// Botão multifunção: 1º clique liga tela limpa (revela ao encostar, como
// sempre foi); 2º clique TRAVA o painel (para de revelar mesmo passando o
// mouse); 3º clique desliga tudo e volta ao normal.
// ---------------------------------------------------------------------------
let cleanModeDefaultIcon = null;
function applyCleanMode() {
  document.body.classList.toggle('clean-mode', !!state.settings.modoTelaLimpa);
  document.body.classList.toggle('edge-reveal', !!state.settings.encostarBordas);
  const btn = $('#topbar-cleanmode');
  if (btn) {
    if (cleanModeDefaultIcon === null) cleanModeDefaultIcon = btn.innerHTML; // guarda o ícone original na 1ª vez
    const locked = !!state.settings.modoTelaLimpa && !state.settings.encostarBordas;
    btn.innerHTML = locked
      ? '<svg viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>'
      : cleanModeDefaultIcon;
    btn.classList.toggle('active-state', !!state.settings.modoTelaLimpa);
    btn.dataset.tooltip = locked
      ? 'Painel travado (clique para voltar ao normal)'
      : (state.settings.modoTelaLimpa ? 'Tela limpa ativa (clique para travar o painel)' : 'Modo tela limpa (Ctrl+Shift+Z)');
  }
}
function toggleCleanMode() {
  if (!state.settings.modoTelaLimpa) {
    // Estado 1: liga tela limpa, com revelar ao encostar (comportamento de sempre)
    state.settings.modoTelaLimpa = true;
    state.settings.encostarBordas = true;
  } else if (state.settings.encostarBordas) {
    // Estado 2: já em tela limpa — trava o painel (não revela mais ao encostar)
    state.settings.encostarBordas = false;
  } else {
    // Estado 3: já travado — desliga tudo e reseta pro padrão (revelar volta
    // a ficar ligado pra próxima vez que ativar tela limpa de novo)
    state.settings.modoTelaLimpa = false;
    state.settings.encostarBordas = true;
  }
  applyCleanMode();
  schedulePersist();
}
// ---------------------------------------------------------------------------
// Modo apresentação/gravação: borra nomes/URLs sensíveis nos cabeçalhos
// (cards, sidebar, barra de endereço). Passar o mouse revela na hora.
// ---------------------------------------------------------------------------
function applyPresentationMode() {
  const on = !!state.settings.modoApresentacao;
  document.body.classList.toggle('presentation-mode', on);
  $('#topbar-presentation') && $('#topbar-presentation').classList.toggle('active-state', on);
}
function togglePresentationMode() {
  state.settings.modoApresentacao = !state.settings.modoApresentacao;
  applyPresentationMode();
  schedulePersist();
}
// ---------------------------------------------------------------------------
// Modo Eco: reduz o uso de CPU da conta em foco também (não só das que já
// estão em segundo plano), trocando o requestAnimationFrame por uma versão
// mais lenta. O progresso do jogo não é afetado — só a frequência de
// atualização visual cai.
// ---------------------------------------------------------------------------
function applyEcoMode() {
  $('#topbar-eco') && $('#topbar-eco').classList.toggle('active-state', !!state.settings.modoEco);
  refreshAllRafThrottles();
}
function toggleEcoMode() {
  state.settings.modoEco = !state.settings.modoEco;
  applyEcoMode();
  schedulePersist();
}
let revealTimer = null;
function revealTop() { clearTimeout(revealTimer); document.body.classList.add('reveal-top'); }
function revealLeft() { clearTimeout(revealTimer); document.body.classList.add('reveal-left'); }
function scheduleHide() {
  clearTimeout(revealTimer);
  revealTimer = setTimeout(() => { document.body.classList.remove('reveal-top', 'reveal-left'); }, 400);
}
$('#edge-trigger-top').addEventListener('mouseenter', revealTop);
$('#edge-trigger-left').addEventListener('mouseenter', revealLeft);
[$('#edge-trigger-top'), $('#edge-trigger-left'), $('#titlebar'), $('#toolbar'), $('#workspace-rail'), $('#sidebar')].forEach((el) => {
  el.addEventListener('mouseleave', scheduleHide);
  el.addEventListener('mouseenter', () => clearTimeout(revealTimer));
});
// ---------------------------------------------------------------------------
// Modal de confirmação genérico
// ---------------------------------------------------------------------------
const confirmOverlay = $('#confirm-overlay');
let confirmCallback = null;
function showConfirm(title, body, onConfirm) {
  $('#confirm-title').textContent = title;
  $('#confirm-body').textContent = body;
  confirmCallback = onConfirm;
  confirmOverlay.classList.remove('hidden');
}
function hideConfirm() { confirmOverlay.classList.add('hidden'); confirmCallback = null; }
$('#confirm-ok').addEventListener('click', () => { const cb = confirmCallback; hideConfirm(); if (cb) cb(); });
$('#confirm-cancel').addEventListener('click', hideConfirm);
$('#confirm-close').addEventListener('click', hideConfirm);
confirmOverlay.addEventListener('click', (e) => { if (e.target === confirmOverlay) hideConfirm(); });
// ---------------------------------------------------------------------------
// Workspaces
// ---------------------------------------------------------------------------
// Acha o menor número "livre" pra um nome tipo "Prefixo N" — se você excluir
// "Conta 3" e criar outra, ela reaproveita o "3" em vez de virar "Conta 4".
// (o id interno de cada conta/workspace continua sempre único e crescente —
// só o NÚMERO NO NOME é reaproveitado, o que é seguro pois nomes podem repetir.)
function nextSequentialName(existingNames, prefix) {
  const used = new Set();
  const escaped = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp(`^${escaped}\\s+(\\d+)$`);
  existingNames.forEach((n) => { const m = n.match(re); if (m) used.add(Number(m[1])); });
  let i = 1;
  while (used.has(i)) i++;
  return `${prefix} ${i}`;
}
function createWorkspace() {
  const id = state.nextWorkspaceId++;
  const idx = state.workspaces.length;
  const name = nextSequentialName(state.workspaces.map((w) => w.name), 'Workspace');
  const ws = {
    id, name, color: COLORS[idx % COLORS.length], iconKey: ICON_KEYS[idx % ICON_KEYS.length],
    defaultUrl: state.settings.urlInicialPadrao || DEFAULT_URL, layout: state.settings.layoutPadrao || 'auto', accounts: [],
  };
  state.workspaces.push(ws);
  state.activeWorkspaceId = id;
  activeAccountId = null;
  renderWorkspaceRail(); renderSidebar(); renderGrid(); updateStatusBar(); schedulePersist();
  requestAnimationFrame(() => {
    const el = workspaceIconsEl.querySelector(`.ws-icon[data-id="${id}"]`);
    if (el) el.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  });
}
function switchWorkspace(id) {
  if (state.activeWorkspaceId === id) return;
  state.activeWorkspaceId = id;
  activeAccountId = null;
  renderWorkspaceRail(); renderSidebar(); renderGrid(); updateStatusBar();
  updateNavButtons(); updateZoomLabel(); updateMuteButton();
}
function reorderWorkspace(draggedId, targetId) {
  const from = state.workspaces.findIndex((w) => w.id === draggedId);
  const to = state.workspaces.findIndex((w) => w.id === targetId);
  if (from === -1 || to === -1 || from === to) return;
  const [item] = state.workspaces.splice(from, 1);
  state.workspaces.splice(to, 0, item);
  renderWorkspaceRail(); schedulePersist();
}
function duplicateWorkspace(id) {
  const src = state.workspaces.find((w) => w.id === id);
  if (!src) return;
  const newId = state.nextWorkspaceId++;
  const copy = {
    id: newId, name: `${src.name} ${t('copySuffix')}`, color: src.color, iconKey: src.iconKey, defaultUrl: src.defaultUrl, layout: src.layout,
    accounts: src.accounts.map((a) => {
      const newAccId = state.nextAccountId++;
      return {
        id: newAccId, name: a.name, url: a.defaultUrl, defaultUrl: a.defaultUrl, partition: `persist:conta-${newAccId}`,
        colorIdx: a.colorIdx, iconKey: a.iconKey || 'apps', status: 'closed', muted: false, zoomFactor: 1, createdAt: Date.now(), webContentsId: null, pid: null,
      };
    }),
  };
  state.workspaces.push(copy);
  state.activeWorkspaceId = newId;
  activeAccountId = null;
  renderWorkspaceRail(); renderSidebar(); renderGrid(); updateStatusBar(); schedulePersist();
}
function deleteWorkspace(id) {
  if (state.workspaces.length <= 1) return;
  state.workspaces = state.workspaces.filter((w) => w.id !== id);
  if (state.activeWorkspaceId === id) state.activeWorkspaceId = state.workspaces[0].id;
  activeAccountId = null;
  renderWorkspaceRail(); renderSidebar(); renderGrid(); updateStatusBar(); schedulePersist();
}
function confirmDeleteWorkspace(id) {
  const ws = state.workspaces.find((w) => w.id === id);
  if (!ws || state.workspaces.length <= 1) return;
  showConfirm(t('confirmDeleteWsTitle'), t('confirmDeleteWsBody'), () => deleteWorkspace(id));
}
function renderWorkspaceRail() {
  workspaceIconsEl.innerHTML = '';
  state.workspaces.forEach((ws) => {
    const el = document.createElement('div');
    el.className = 'ws-icon' + (ws.id === state.activeWorkspaceId ? ' active' : '');
    el.draggable = true;
    el.dataset.id = ws.id;
    el.dataset.tooltip = ws.name;
    el.style.setProperty('--ws-color', ws.color);
    const openCount = ws.accounts.filter((a) => a.status === 'open').length;
    el.innerHTML = `<span class="ws-indicator" style="background:${ws.color}"></span>${ICONS[ws.iconKey] || ICONS.apps}<span class="ws-badge">${openCount}</span>`;
    el.addEventListener('click', () => switchWorkspace(ws.id));
    el.addEventListener('contextmenu', (e) => { e.preventDefault(); openWsContextMenu(e.clientX, e.clientY, ws.id); });
    el.addEventListener('dragstart', (e) => { el.classList.add('dragging'); e.dataTransfer.setData('text/ws-id', String(ws.id)); });
    el.addEventListener('dragend', () => el.classList.remove('dragging'));
    el.addEventListener('dragover', (e) => { e.preventDefault(); el.classList.add('drag-over'); });
    el.addEventListener('dragleave', () => el.classList.remove('drag-over'));
    el.addEventListener('drop', (e) => {
      e.preventDefault(); el.classList.remove('drag-over');
      const wsId = Number(e.dataTransfer.getData('text/ws-id'));
      if (wsId) { reorderWorkspace(wsId, ws.id); return; }
      const accId = Number(e.dataTransfer.getData('text/acc-id'));
      if (accId) moveAccountToWorkspace(accId, ws.id);
    });
    workspaceIconsEl.appendChild(el);
  });
}
// ---------------------------------------------------------------------------
// Menu de contexto do workspace
// ---------------------------------------------------------------------------
const wsCtxMenu = $('#ws-context-menu');
let ctxWorkspaceId = null;
function openWsContextMenu(x, y, wsId) {
  ctxWorkspaceId = wsId;
  const deleteBtn = wsCtxMenu.querySelector('[data-action="delete"]');
  deleteBtn.disabled = state.workspaces.length <= 1;
  wsCtxMenu.classList.remove('hidden');
  const w = 200, h = 160;
  wsCtxMenu.style.left = `${Math.max(4, Math.min(x, window.innerWidth - w - 8))}px`;
  wsCtxMenu.style.top = `${Math.max(4, Math.min(y, window.innerHeight - h - 8))}px`;
}
function closeWsContextMenu() { wsCtxMenu.classList.add('hidden'); ctxWorkspaceId = null; }
document.addEventListener('click', (e) => { if (!wsCtxMenu.contains(e.target)) closeWsContextMenu(); });
wsCtxMenu.addEventListener('click', (e) => {
  const btn = e.target.closest('button[data-action]');
  if (!btn || ctxWorkspaceId == null || btn.disabled) return;
  const id = ctxWorkspaceId, action = btn.dataset.action;
  if (action === 'edit') { switchWorkspace(id); openWorkspaceEditModal(); }
  else if (action === 'duplicate') duplicateWorkspace(id);
  else if (action === 'delete') confirmDeleteWorkspace(id);
  closeWsContextMenu();
});
// ---------------------------------------------------------------------------
// Modal "Editar workspace"
// ---------------------------------------------------------------------------
const wsEditOverlay = $('#ws-edit-overlay');
let wsEditColor = null, wsEditIcon = null;
// Adiciona a opção "Grade personalizada" no <select> de layout (uma vez só)
// e os campos de linhas/colunas, sem precisar editar o index.html.
function ensureCustomGridOption() {
  const select = $('#ws-edit-layout');
  if (!select || select.querySelector('option[value="custom"]')) return;
  const opt = document.createElement('option');
  opt.value = 'custom';
  opt.textContent = 'Grade personalizada (linhas × colunas)';
  select.appendChild(opt);
}
function ensureCustomGridControls() {
  let wrap = $('#ws-edit-custom-grid');
  if (wrap) return wrap;
  const anchor = $('#ws-edit-reset-dividers');
  if (!anchor || !anchor.parentElement) return null;
  wrap = document.createElement('div');
  wrap.id = 'ws-edit-custom-grid';
  wrap.className = 'hidden';
  wrap.style.cssText = 'align-items:center; gap:10px; margin-top:8px; flex-wrap:wrap;';
  const inputStyle = 'width:52px; background:#0f1218; color:#e5e7eb; border:1px solid #2a2f3a; border-radius:6px; padding:4px 6px; font-size:13px;';
  wrap.innerHTML = `
    <label style="display:flex; align-items:center; gap:6px; font-size:12px; color:#e5e7eb;">Linhas
      <input id="ws-edit-custom-rows" type="number" min="1" max="8" value="2" style="${inputStyle}">
    </label>
    <label style="display:flex; align-items:center; gap:6px; font-size:12px; color:#e5e7eb;">Colunas
      <input id="ws-edit-custom-cols" type="number" min="1" max="8" value="2" style="${inputStyle}">
    </label>
    <span style="display:flex; gap:6px;">
      <button type="button" data-rows="1" data-cols="3" class="btn-icon" style="width:auto; padding:0 8px; font-size:11px;">1×3</button>
      <button type="button" data-rows="1" data-cols="4" class="btn-icon" style="width:auto; padding:0 8px; font-size:11px;">1×4</button>
      <button type="button" data-rows="2" data-cols="4" class="btn-icon" style="width:auto; padding:0 8px; font-size:11px;">2×4</button>
    </span>
  `;
  anchor.parentElement.insertBefore(wrap, anchor.nextSibling);
  wrap.querySelectorAll('button[data-rows]').forEach((btn) => {
    btn.addEventListener('click', () => {
      $('#ws-edit-custom-rows').value = btn.dataset.rows;
      $('#ws-edit-custom-cols').value = btn.dataset.cols;
    });
  });
  return wrap;
}
function openWorkspaceEditModal() {
  const ws = getActiveWorkspace();
  if (!ws) return;
  ensureCustomGridOption();
  ensureCustomGridControls();
  $('#ws-edit-name').value = ws.name;
  $('#ws-edit-url').value = ws.defaultUrl || '';
  $('#ws-edit-layout').value = ws.layout || 'auto';
  $('#ws-edit-custom-rows').value = ws.customRows || 2;
  $('#ws-edit-custom-cols').value = ws.customCols || 2;
  wsEditColor = ws.color; wsEditIcon = ws.iconKey;
  renderWsEditColors(); renderWsEditIcons();
  updateResetDividersVisibility();
  wsEditOverlay.classList.remove('hidden');
  $('#ws-edit-name').focus();
}
function updateResetDividersVisibility() {
  const layout = $('#ws-edit-layout').value;
  $('#ws-edit-reset-dividers').classList.toggle('hidden', layout !== 'auto');
  const customWrap = $('#ws-edit-custom-grid');
  if (customWrap) customWrap.style.display = layout === 'custom' ? 'flex' : 'none';
}
$('#ws-edit-layout').addEventListener('change', updateResetDividersVisibility);
$('#ws-edit-reset-dividers').addEventListener('click', () => {
  const ws = getActiveWorkspace();
  if (!ws) return;
  ws.autoGridColFr = null;
  ws.autoGridRowFr = null;
  renderGrid();
  schedulePersist();
});
function renderWsEditColors() {
  const wrap = $('#ws-edit-colors'); wrap.innerHTML = '';
  COLORS.forEach((c) => {
    const b = document.createElement('button');
    b.style.background = c; b.style.color = c;
    if (c === wsEditColor) b.classList.add('selected');
    b.addEventListener('click', () => { wsEditColor = c; renderWsEditColors(); });
    wrap.appendChild(b);
  });
}
function renderWsEditIcons() {
  const wrap = $('#ws-edit-icons'); wrap.innerHTML = '';
  ICON_KEYS.forEach((key) => {
    const b = document.createElement('button');
    b.innerHTML = ICONS[key];
    if (key === wsEditIcon) b.classList.add('selected');
    b.addEventListener('click', () => { wsEditIcon = key; renderWsEditIcons(); });
    wrap.appendChild(b);
  });
}
$('#rename-workspace-btn').addEventListener('click', openWorkspaceEditModal);
$('#ws-edit-close').addEventListener('click', () => wsEditOverlay.classList.add('hidden'));
wsEditOverlay.addEventListener('click', (e) => { if (e.target === wsEditOverlay) wsEditOverlay.classList.add('hidden'); });
$('#ws-edit-save').addEventListener('click', () => {
  const ws = getActiveWorkspace();
  if (!ws) return;
  const name = $('#ws-edit-name').value.trim();
  const url = $('#ws-edit-url').value.trim();
  if (name) ws.name = name;
  ws.color = wsEditColor || ws.color;
  ws.iconKey = wsEditIcon || ws.iconKey;
  ws.defaultUrl = url ? normalizeUrl(url) : ws.defaultUrl;
  ws.layout = $('#ws-edit-layout').value;
  if (ws.layout === 'custom') {
    ws.customRows = Math.max(1, Math.min(8, parseInt($('#ws-edit-custom-rows').value, 10) || 2));
    ws.customCols = Math.max(1, Math.min(8, parseInt($('#ws-edit-custom-cols').value, 10) || 2));
  }
  wsEditOverlay.classList.add('hidden');
  renderWorkspaceRail(); renderSidebar(); renderGrid(); updateStatusBar(); schedulePersist();
});
// ---------------------------------------------------------------------------
// Contas: criação instantânea (sem modal) / abrir / fechar / duplicar / editar / excluir / limpar
// ---------------------------------------------------------------------------
function createAccount(name, url, openImmediately = true, opts = {}) {
  const ws = opts.workspaceId != null
    ? state.workspaces.find((w) => w.id === opts.workspaceId) || getActiveWorkspace()
    : getActiveWorkspace();
  if (!ws) return null;
  const id = state.nextAccountId++;
  const finalUrl = url && url.trim() ? normalizeUrl(url.trim()) : (ws.defaultUrl || DEFAULT_URL);
  const account = {
    id, name: name || `${t('accountWord')} ${id}`, url: finalUrl, defaultUrl: finalUrl,
    partition: `persist:conta-${id}`,
    colorIdx: opts.colorIdx != null ? opts.colorIdx : ws.accounts.length % ACCOUNT_COLORS.length,
    iconKey: opts.iconKey || 'apps',
    status: openImmediately ? 'open' : 'closed', muted: false, zoomFactor: state.settings.zoomPadrao || 1,
    createdAt: Date.now(), webContentsId: null, pid: null,
  };
  ws.accounts.push(account);
  renderWorkspaceRail(); renderSidebar(); renderGrid();
  if (openImmediately && ws.id === getActiveWorkspace().id) setActiveAccount(id);
  schedulePersist();
  return account;
}
function openAccount(id, urlOverride) {
  const acc = getAccountById(id);
  if (!acc) return;
  if (urlOverride) acc.url = urlOverride;
  acc.status = 'open';
  renderSidebar(); renderGrid();
  setActiveAccount(id);
  schedulePersist();
}
function closeAccount(id) {
  const acc = getAccountById(id);
  if (!acc) return;
  acc.status = 'closed'; acc.webContentsId = null; acc.pid = null;
  if (activeAccountId === id) activeAccountId = null;
  renderSidebar(); renderGrid(); updateStatusBar(); updateNavButtons(); updateZoomLabel(); updateMuteButton();
  schedulePersist();
}
// ---------------------------------------------------------------------------
// Abrir conta em uma janela própria (fora do grid). Usa a MESMA partition da
// conta, então login/cookies continuam sincronizados com o painel do grid —
// é a mesma sessão sendo exibida em duas janelas, não uma cópia.
// ---------------------------------------------------------------------------
async function openAccountInWindow(id) {
  const acc = getAccountById(id);
  if (!acc) return;
  const url = normalizeUrl(acc.url || acc.defaultUrl || DEFAULT_URL);
  try {
    await window.nativeAPI.openAccountWindow({
      accountId: acc.id,
      url,
      partition: acc.partition,
      title: acc.name,
      zoomFactor: acc.zoomFactor || 1,
      muted: !!acc.muted,
      colorIdx: acc.colorIdx || 0,
      iconKey: acc.iconKey || 'apps',
    });
  } catch (err) {
    console.error('Erro ao abrir conta em nova janela:', err);
  }
}
// ---------------------------------------------------------------------------
// Kit-Ticket: gera um pacote de suporte (log do console + estado do
// personagem, tudo extraído da própria conta) para anexar em tickets —
// ajuda a staff quando o usuário abre um chamado incompleto. Fluxo:
// 1) confirma com o usuário que ele já deixou as telas certas abertas;
// 2) lê o nome do personagem e o estado (Informações básicas, Status e
//    Equipamentos) direto do HTML da página do jogo; 3) salva log + estado;
// 4) o main.js abre a pasta no final. Sem screenshot — todos os dados
// relevantes já vêm extraídos diretamente do front-end.
// ---------------------------------------------------------------------------
// Mesmo princípio do EXTRACT_ZENY_INJECT: um scriptzinho injetado na página
// do jogo, que acha o nome do personagem no HUD e devolve o texto pra gente.
// O jogo tem PELO MENOS duas telas diferentes que mostram o nome (o HUD
// compacto do mobile e um painel expandido de status), com estruturas de
// HTML/CSS diferentes entre si — por isso tentamos 2 estratégias em ordem,
// da mais específica pra mais genérica, parando na primeira que funcionar:
//
// 1) HUD compacto (mobile-basic-info): lá SÓ o span do nome tem "font-bold"
//    (o da classe/job usa "font-normal"), então a classe sozinha já resolve.
// 2) Painel expandido de status: lá os dois spans (nome E classe/job) usam
//    "font-bold", então a classe deixa de ser confiável. Em vez disso,
//    usamos o AVATAR do personagem (data-testid="character-portrait-canvas")
//    como "ponto de referência" fixo: o bloco de nome/classe fica sempre ao
//    lado dele, e o nome é sempre o PRIMEIRO <span> desse bloco.
const EXTRACT_CHAR_NAME_INJECT = `(function(){
  function limpa(texto) { return (texto || '').trim(); }

  // Estratégia 1: HUD compacto do mobile.
  var elMobile = document.querySelector('[data-testid="mobile-basic-info"] span.font-bold');
  if (elMobile) {
    var nome1 = limpa(elMobile.getAttribute('title') || elMobile.textContent);
    if (nome1) return nome1;
  }

  // Estratégia 2: painel expandido — usa o avatar como referência fixa.
  var canvas = document.querySelector('[data-testid="character-portrait-canvas"]');
  if (canvas) {
    var mascara = canvas.parentElement;
    var quadroAvatar = mascara ? mascara.parentElement : null;
    var blocoNome = quadroAvatar ? quadroAvatar.nextElementSibling : null;
    var primeiroSpan = blocoNome ? blocoNome.querySelector('span') : null;
    if (primeiroSpan) {
      var nome2 = limpa(primeiroSpan.getAttribute('title') || primeiroSpan.textContent);
      if (nome2) return nome2;
    }
  }

  return null;
})();`;
async function extractCharacterName(accountId) {
  const webview = grid.querySelector(`.account-card[data-id="${accountId}"] webview`);
  if (!webview) return null;
  try {
    return await webview.executeJavaScript(EXTRACT_CHAR_NAME_INJECT);
  } catch (err) {
    return null; // HUD pode não estar montado ainda (tela de login, etc.)
  }
}
// Extração do "estado" do personagem: Informações básicas (HP, SP, nível
// base/job + %exp, peso, zeny, classe), Status/Atributos (STR/AGI/VIT/INT/
// DEX/LUK, ATK/MATK/HIT/CRI/DEF/MDEF/FLEE/ASPD, pontos restantes) e
// Equipamentos (os slots equipados). Sugestão do Poring: como o jogo é
// browser/JS, dá pra ler os valores direto do HTML em vez de depender de
// screenshot. Usamos atributos de ACESSIBILIDADE (role="progressbar",
// aria-label, data-testid) como referência — eles servem para leitores de
// tela, então tendem a ser MUITO estáveis entre atualizações do jogo.
const EXTRACT_GAME_STATE_INJECT = `(function(){
  function limpa(t) { return (t || '').trim(); }
  var linhas = [];
  var vistos = {};
  function add(txt) {
    txt = limpa(txt);
    if (!txt || vistos[txt]) return;
    vistos[txt] = true;
    linhas.push(txt);
  }

  // ===== Informações básicas =====
  document.querySelectorAll('[role="progressbar"]').forEach(function (bar) {
    var label = limpa(bar.getAttribute('aria-label'));
    if (!label) return;
    var pct = bar.getAttribute('aria-valuenow');
    var span = bar.querySelector('span');
    var valorTexto = span ? limpa(span.textContent) : '';
    if (label === 'HP' || label === 'SP') {
      add(label + ': ' + (valorTexto || '?') + (pct != null ? ' (' + pct + '%)' : ''));
    } else if (/Lv\\..*EXP$/i.test(label)) {
      add(label.replace(/\\s*EXP$/i, '') + (pct != null ? ' - ' + pct + '% exp' : ''));
    }
  });
  document.querySelectorAll('[title]').forEach(function (el) {
    var titulo = limpa(el.getAttribute('title'));
    if (/^(Base Lv\\.|Classe Lv\\.|Peso:|Zeny:)/i.test(titulo)) add(titulo);
  });
  var pesoEl = document.querySelector('[aria-label^="Peso:"]');
  if (pesoEl) add(pesoEl.getAttribute('aria-label'));
  var zenyEl = document.querySelector('fieldset[aria-label="Zeny"]');
  if (zenyEl) add(zenyEl.textContent);
  var elMobileNome = document.querySelector('[data-testid="mobile-basic-info"] span.font-bold');
  if (elMobileNome && elMobileNome.nextElementSibling) {
    var classeMobile = limpa(elMobileNome.nextElementSibling.getAttribute('title') || elMobileNome.nextElementSibling.textContent);
    if (classeMobile) add('Classe: ' + classeMobile);
  } else {
    var canvasClasse = document.querySelector('[data-testid="character-portrait-canvas"]');
    if (canvasClasse) {
      var blocoNomeClasse = canvasClasse.parentElement && canvasClasse.parentElement.parentElement
        ? canvasClasse.parentElement.parentElement.nextElementSibling : null;
      var spansClasse = blocoNomeClasse ? blocoNomeClasse.querySelectorAll('span') : [];
      if (spansClasse[1]) {
        var classeExp = limpa(spansClasse[1].getAttribute('title') || spansClasse[1].textContent);
        if (classeExp) add('Classe: ' + classeExp);
      }
    }
  }

  // ===== Janela de Status/Atributos =====
  function encontrarJanelaPorTitlebar(aria) {
    var titlebar = document.querySelector('[aria-label="' + aria + '"]');
    return (titlebar && titlebar.parentElement) ? titlebar.parentElement : document;
  }
  var janelaStatus = encontrarJanelaPorTitlebar('Mover status');
  janelaStatus.querySelectorAll('[role="status"][aria-label$=" value"]').forEach(function (el) {
    var atributo = limpa(el.getAttribute('aria-label')).replace(/\\s*value$/i, '');
    add(atributo + ': ' + limpa(el.textContent));
  });
  var readouts = janelaStatus.querySelector('.ro-win-stats-readouts');
  if (readouts) {
    var combate = {};
    readouts.querySelectorAll(':scope > div').forEach(function (linha) {
      var spans = linha.querySelectorAll(':scope > span');
      if (spans.length >= 2) combate[limpa(spans[0].textContent)] = limpa(spans[1].textContent);
    });
    ['ATK', 'MATK', 'HIT', 'CRI', 'DEF', 'MDEF', 'FLEE', 'ASPD'].forEach(function (chave) {
      if (combate[chave] != null) add(chave + ': ' + combate[chave]);
    });
  }
  var pontosEl = janelaStatus.querySelector('[data-testid="status-points-remaining"]');
  if (pontosEl) add('Pontos restantes: ' + limpa(pontosEl.textContent));

  // ===== Janela de Equipamentos =====
  var janelaEquip = encontrarJanelaPorTitlebar('Mover equipamentos');
  var slotsEquipados = [];
  janelaEquip.querySelectorAll('button[data-slot-state]').forEach(function (btn) {
    var rotulo = limpa(btn.getAttribute('aria-label'));
    if (rotulo) slotsEquipados.push(rotulo);
  });
  if (slotsEquipados.length) {
    add('--- Equipamentos ---');
    slotsEquipados.forEach(function (s) { add(s.indexOf(':') !== -1 ? s : s + ': (vazio)'); });
  }

  return linhas.length ? linhas.join('\\n') : null;
})();`;
async function extractGameState(accountId) {
  const webview = grid.querySelector(`.account-card[data-id="${accountId}"] webview`);
  if (!webview) return null;
  try {
    return await webview.executeJavaScript(EXTRACT_GAME_STATE_INJECT);
  } catch (err) {
    return null;
  }
}
// ---------------------------------------------------------------------------
// Captura de console: em vez de depender do evento 'console-message' do
// <webview> (que em algumas versões do Electron/Chromium não é 100%
// confiável, ou pode perder mensagens dependendo do timing), usamos o MESMO
// princípio do RAF_THROTTLE_INJECT e do AUTOFILL_INJECT: injetamos um script
// que SOBRESCREVE window.console.log/warn/error/info/debug diretamente
// dentro da página do jogo, guardando cada chamada num array global
// (window.__idleHubConsoleBuffer). Na hora de gerar o Kit-Ticket, a gente só
// LÊ esse array via executeJavaScript — muito mais garantido, porque é o
// mesmo mecanismo que já usamos com sucesso pro throttle de rAF e pro Zeny/h.
// ---------------------------------------------------------------------------
const CONSOLE_CAPTURE_INJECT = `(function(){
  if (window.__idleHubConsoleCaptureReady) return;
  window.__idleHubConsoleCaptureReady = true;
  window.__idleHubConsoleBuffer = [];
  var niveis = { log: 'LOG', warn: 'AVISO', error: 'ERRO', info: 'INFO', debug: 'DEBUG' };
  Object.keys(niveis).forEach(function (metodo) {
    var original = console[metodo] ? console[metodo].bind(console) : function(){};
    console[metodo] = function () {
      try {
        var args = Array.prototype.slice.call(arguments).map(function (a) {
          if (typeof a === 'string') return a;
          try { return JSON.stringify(a); } catch (e) { return String(a); }
        });
        var hora = new Date().toLocaleTimeString('pt-BR');
        window.__idleHubConsoleBuffer.push('[' + hora + '] [' + niveis[metodo] + '] ' + args.join(' '));
        if (window.__idleHubConsoleBuffer.length > 1000) window.__idleHubConsoleBuffer.shift();
      } catch (e) { /* nunca deixa o log quebrar o jogo */ }
      original.apply(console, arguments);
    };
  });
  // Bônus: captura também erros não tratados (uncaught exceptions) e
  // promises rejeitadas sem .catch — informação valiosa pra debug que às
  // vezes nem passa pelo console.error.
  window.addEventListener('error', function (e) {
    try {
      var hora = new Date().toLocaleTimeString('pt-BR');
      window.__idleHubConsoleBuffer.push('[' + hora + '] [ERRO-JS] ' + (e.message || 'erro desconhecido') + (e.filename ? ' (' + e.filename + ':' + e.lineno + ')' : ''));
    } catch (err) { /* ignore */ }
  });
  window.addEventListener('unhandledrejection', function (e) {
    try {
      var hora = new Date().toLocaleTimeString('pt-BR');
      var motivo = (e.reason && e.reason.message) ? e.reason.message : String(e.reason);
      window.__idleHubConsoleBuffer.push('[' + hora + '] [PROMISE-REJEITADA] ' + motivo);
    } catch (err) { /* ignore */ }
  });
})();`;
async function extractConsoleLog(accountId) {
  const webview = grid.querySelector(`.account-card[data-id="${accountId}"] webview`);
  if (!webview) return null;
  try {
    return await webview.executeJavaScript('window.__idleHubConsoleBuffer ? window.__idleHubConsoleBuffer.join("\\n") : null');
  } catch (err) {
    return null;
  }
}
function openReportConfirm(accountId) {
  const acc = getAccountById(accountId);
  if (!acc) return;
  showConfirm(
    'Gerar Kit-Ticket',
    'Antes de continuar, abra as janelas de Informações básicas, Status e Equipamentos. Quando estiver tudo certo, clique em Confirmar.',
    () => generateReportForAccount(accountId),
  );
}
async function generateReportForAccount(id) {
  const acc = getAccountById(id);
  if (!acc) return;
  if (acc.status !== 'open') {
    alert('Abra a conta antes de gerar o Kit-Ticket.');
    return;
  }
  const agora = new Date();
  const pad2 = (n) => String(n).padStart(2, '0');
  const hhmmss = `${pad2(agora.getHours())}${pad2(agora.getMinutes())}${pad2(agora.getSeconds())}`;
  const ddmmyy = `${pad2(agora.getDate())}${pad2(agora.getMonth() + 1)}${String(agora.getFullYear()).slice(-2)}`;
  const nomeDoHud = await extractCharacterName(id);
  const nomeBruto = nomeDoHud || acc.name || 'Personagem';
  const nomePersonagem = nomeBruto.replace(/[\\/:*?"<>|]/g, '_').trim() || 'Personagem';
  const logName = `${nomePersonagem}-log-${hhmmss}-${ddmmyy}.txt`;
  const stateName = `${nomePersonagem}-estado-${hhmmss}-${ddmmyy}.txt`;
  const logExtraido = await extractConsoleLog(id);
  const logContent = logExtraido || '(nenhuma mensagem de console foi registrada nesta sessão)';
  const dataHoraLegivel = agora.toLocaleString('pt-BR');
  const estadoExtraido = await extractGameState(id);
  const stateContent = `=== Kit-Ticket — Estado do personagem ===\nPersonagem: ${nomeBruto}\nCapturado em: ${dataHoraLegivel}\n\n${estadoExtraido || '(não foi possível extrair o estado do personagem nesta sessão — a tela pode não estar carregada)'}`;
  try {
    const result = await window.nativeAPI.generateReport({ logName, logContent, stateName, stateContent });
    if (!result || !result.ok) {
      alert('Não foi possível gerar o Kit-Ticket. Veja o DevTools (Ctrl+Shift+I no app) para detalhes do erro.');
    }
  } catch (err) {
    console.error('Erro ao gerar Kit-Ticket:', err);
    alert('Não foi possível gerar o Kit-Ticket. Veja o DevTools (Ctrl+Shift+I no app) para detalhes do erro.');
  }
}
// ---------------------------------------------------------------------------
// Gravação de rede (HAR) — ideia do Poring: um botão tipo "record". Clica
// pra começar a gravar o tráfego de rede daquela conta, reproduz o bug no
// jogo, clica de novo pra parar — o app salva um arquivo .har (o mesmo
// formato que o Chrome DevTools exporta em Network > Save all as HAR) na
// pasta Kit-Ticket.
// ---------------------------------------------------------------------------
async function toggleNetworkRecording(accountId) {
  const acc = getAccountById(accountId);
  if (!acc) return;
  const card = grid.querySelector(`.account-card[data-id="${accountId}"]`);
  const btn = card ? card.querySelector('.netrecord') : null;
  if (!acc.recordingNetwork) {
    if (acc.status !== 'open' || !acc.webContentsId) {
      alert('Abra a conta antes de gravar a rede.');
      return;
    }
    try {
      const result = await window.nativeAPI.startNetworkRecording({ webContentsId: acc.webContentsId });
      if (!result || !result.ok) {
        alert('Não foi possível iniciar a gravação de rede: ' + ((result && result.error) || 'erro desconhecido'));
        return;
      }
      // Pedido do Poring: reset() + start() nos DOIS objetos de diagnóstico
      // dele (presentation e socket), nessa ordem — reset de ambos primeiro,
      // start de ambos depois. Se a página ainda não tiver esses objetos
      // (só chega no update de amanhã dele), ignora silenciosamente — não
      // pode travar a gravação de rede por causa disso.
      if (card) {
        const webview = card.querySelector('webview');
        if (webview) {
          webview.executeJavaScript(`(function(){
            try {
              var presentation = window.__midgardIdlePresentationTimelineDiagnostics;
              var socket = window.__midgardIdleGameSocketDiagnostics;
              if (presentation && presentation.reset) presentation.reset();
              if (socket && socket.reset) socket.reset();
              if (presentation && presentation.start) presentation.start();
              if (socket && socket.start) socket.start();
            } catch (e) {}
          })();`).catch((err) => console.error('Erro ao iniciar diagnóstico do Poring:', err));
        }
      }
      acc.recordingNetwork = true;
      if (btn) {
        btn.innerHTML = ICONS_MINI.recordStop;
        btn.title = 'Parar gravação de rede';
        btn.style.color = '#f87171';
      }
    } catch (err) {
      console.error('Erro ao iniciar gravação de rede:', err);
      alert('Não foi possível iniciar a gravação de rede.');
    }
  } else {
    const nomeDoHud = await extractCharacterName(accountId);
    const nomeBruto = nomeDoHud || acc.name || 'Personagem';
    const nomePersonagem = nomeBruto.replace(/[\/:*?"<>|]/g, '_').trim() || 'Personagem';
    const agora = new Date();
    const pad2 = (n) => String(n).padStart(2, '0');
    const hhmmss = `${pad2(agora.getHours())}${pad2(agora.getMinutes())}${pad2(agora.getSeconds())}`;
    const ddmmyy = `${pad2(agora.getDate())}${pad2(agora.getMonth() + 1)}${String(agora.getFullYear()).slice(-2)}`;
    const harName = `${nomePersonagem}-rede-${hhmmss}-${ddmmyy}.har`;
    // Pedido do Poring: stop() nos DOIS objetos primeiro, depois monta o
    // "capture" com presentation.snapshot(), presentation.receipts() e
    // socket.snapshot() — exatamente a estrutura que ele passou. Se a
    // página ainda não tiver os objetos, manda null (main.js só salva o
    // arquivo extra se tiver algo).
    let diagnosticsSnapshot = null;
    if (card) {
      const webview = card.querySelector('webview');
      if (webview) {
        try {
          diagnosticsSnapshot = await webview.executeJavaScript(`(function(){
            try {
              var presentation = window.__midgardIdlePresentationTimelineDiagnostics;
              var socket = window.__midgardIdleGameSocketDiagnostics;
              if (presentation && presentation.stop) presentation.stop();
              if (socket && socket.stop) socket.stop();
              var capture = {
                presentation: (presentation && presentation.snapshot) ? presentation.snapshot() : null,
                receipts: (presentation && presentation.receipts) ? presentation.receipts() : null,
                socket: (socket && socket.snapshot) ? socket.snapshot() : null,
              };
              if (capture.presentation == null && capture.receipts == null && capture.socket == null) return null;
              return capture;
            } catch (e) { return null; }
          })();`);
        } catch (err) {
          console.error('Erro ao encerrar/coletar diagnóstico do Poring:', err);
        }
      }
    }
    try {
      const result = await window.nativeAPI.stopNetworkRecording({ webContentsId: acc.webContentsId, harName, diagnosticsSnapshot });
      if (!result || !result.ok) {
        alert('Não foi possível salvar a gravação de rede: ' + ((result && result.error) || 'erro desconhecido'));
      }
    } catch (err) {
      console.error('Erro ao parar gravação de rede:', err);
      alert('Não foi possível salvar a gravação de rede.');
    } finally {
      acc.recordingNetwork = false;
      if (btn) {
        btn.innerHTML = ICONS_MINI.record;
        btn.title = 'Gravar rede (HAR)';
        btn.style.color = '';
      }
    }
  }
}
function closeAllAccountsOfActiveWorkspace() {
  const ws = getActiveWorkspace();
  if (!ws) return;
  const open = ws.accounts.filter((a) => a.status === 'open');
  if (!open.length) return;
  showConfirm(t('confirmCloseAllTitle'), t('confirmCloseAllBody', { count: open.length }), () => {
    open.forEach((a) => { a.status = 'closed'; a.webContentsId = null; a.pid = null; });
    activeAccountId = null;
    renderSidebar(); renderGrid(); updateStatusBar(); updateNavButtons(); updateZoomLabel(); updateMuteButton();
    schedulePersist();
  });
}
function deleteAccount(id) {
  const acc = getAccountById(id);
  if (!acc) return;
  showConfirm(t('confirmDeleteAccTitle'), t('confirmDeleteAccBody', { name: acc.name }), () => {
    const ws = getActiveWorkspace();
    if (!ws) return;
    ws.accounts = ws.accounts.filter((a) => a.id !== id);
    if (activeAccountId === id) activeAccountId = null;
    delete credentials[id];
    window.nativeAPI.deleteCredentials(id);
    window.nativeAPI.closeAccountWindow(id).catch(() => {});
    renderWorkspaceRail(); renderSidebar(); renderGrid(); updateStatusBar(); schedulePersist();
  });
}
function duplicateAccount(id) {
  const ws = getActiveWorkspace();
  const src = getAccountById(id);
  if (!ws || !src) return;
  const newId = state.nextAccountId++;
  const copy = {
    id: newId, name: `${src.name} ${t('copySuffix')}`, url: src.defaultUrl, defaultUrl: src.defaultUrl,
    partition: `persist:conta-${newId}`, colorIdx: src.colorIdx || 0, iconKey: src.iconKey || 'apps',
    status: 'open', muted: false, zoomFactor: src.zoomFactor || 1, createdAt: Date.now(), webContentsId: null, pid: null,
  };
  ws.accounts.push(copy);
  renderWorkspaceRail(); renderSidebar(); renderGrid();
  setActiveAccount(newId);
  schedulePersist();
}
function editAccount(id, name, url, opts = {}) {
  const acc = getAccountById(id);
  if (!acc) return;
  if (name.trim()) acc.name = name.trim();
  if (opts.colorIdx != null) acc.colorIdx = opts.colorIdx;
  if (opts.iconKey) acc.iconKey = opts.iconKey;
  const trimmedUrl = url.trim();
  if (trimmedUrl) {
    const full = normalizeUrl(trimmedUrl);
    // Só navega se a URL realmente mudou — antes, salvar só o nome (com o
    // campo de URL ainda preenchido com o valor atual) fazia a página
    // recarregar de volta pra URL padrão do nada, perdendo o progresso.
    const changed = full !== acc.defaultUrl;
    acc.defaultUrl = full;
    if (changed) {
      acc.url = full;
      if (acc.status === 'open') {
        const webview = grid.querySelector(`.account-card[data-id="${acc.id}"] webview`);
        if (webview) webview.loadURL(full);
      }
    }
  }
  renderSidebar(); renderGrid(); schedulePersist();
}
function clearAccountData(id) {
  const acc = getAccountById(id);
  if (!acc) return;
  showConfirm(t('confirmClearDataTitle'), t('confirmClearDataBody', { name: acc.name }), async () => {
    await window.nativeAPI.clearPartition(acc.partition);
    window.nativeAPI.closeAccountWindow(id).catch(() => {});
    if (acc.status === 'open') {
      const webview = grid.querySelector(`.account-card[data-id="${acc.id}"] webview`);
      if (webview) webview.reload();
    }
  });
}
function reorderAccount(draggedId, targetId) {
  const ws = getActiveWorkspace();
  if (!ws) return;
  const from = ws.accounts.findIndex((a) => a.id === draggedId);
  const to = ws.accounts.findIndex((a) => a.id === targetId);
  if (from === -1 || to === -1 || from === to) return;
  const [item] = ws.accounts.splice(from, 1);
  ws.accounts.splice(to, 0, item);
  renderSidebar(); renderGrid(); schedulePersist();
}
// Mover uma conta para outro workspace (arrastando a conta da sidebar para o
// ícone de um workspace na coluna da esquerda). A conta preserva sessão
// (partição), cor, ícone e configurações — só troca de "pasta".
function moveAccountToWorkspace(accountId, targetWorkspaceId) {
  const targetWs = state.workspaces.find((w) => w.id === targetWorkspaceId);
  if (!targetWs) return;
  let sourceWs = null;
  for (const w of state.workspaces) {
    if (w.accounts.some((a) => a.id === accountId)) { sourceWs = w; break; }
  }
  if (!sourceWs || sourceWs.id === targetWs.id) return;
  const acc = sourceWs.accounts.find((a) => a.id === accountId);
  sourceWs.accounts = sourceWs.accounts.filter((a) => a.id !== accountId);
  targetWs.accounts.push(acc);
  if (activeAccountId === accountId) activeAccountId = null;
  if (state.activeWorkspaceId === targetWs.id) setActiveAccount(accountId);
  renderWorkspaceRail(); renderSidebar(); renderGrid(); updateStatusBar(); updateNavButtons(); updateZoomLabel(); updateMuteButton();
  schedulePersist();
}
function setActiveAccount(id) {
  if (activeAccountId === id) return;
  const previousId = activeAccountId;
  activeAccountId = id;
  // Se a conta anterior estava maximizada, a maximização "segue" pra conta
  // que você acabou de selecionar, em vez de ficar presa na antiga cobrindo a tela.
  const prevCard = previousId != null ? grid.querySelector(`.account-card[data-id="${previousId}"]`) : null;
  if (prevCard && prevCard.classList.contains('maximized')) {
    prevCard.classList.remove('maximized');
    const newCard = grid.querySelector(`.account-card[data-id="${id}"]`);
    if (newCard) newCard.classList.add('maximized');
  }
  const acc = getAccountById(id);
  if (acc) addressBar.value = acc.url;
  renderSidebar();
  const ws = getActiveWorkspace();
  if (ws && ws.layout === 'single') renderGrid();
  document.querySelectorAll('.account-card').forEach((el) => el.classList.toggle('active-card', Number(el.dataset.id) === id));
  updateStatusBar(); updateNavButtons(); updateZoomLabel(); updateMuteButton();
}
// ---------------------------------------------------------------------------
// Sidebar
// ---------------------------------------------------------------------------
function renderSidebar() {
  const ws = getActiveWorkspace();
  $('#workspace-title').textContent = ws ? ws.name : '';
  $('#workspace-icon-badge').innerHTML = ws ? ICONS[ws.iconKey] || ICONS.apps : '';
  $('#workspace-icon-badge').style.color = ws ? ws.color : '';
  accountListEl.innerHTML = '';
  if (!ws) return;
  ws.accounts.forEach((acc) => {
    const item = document.createElement('div');
    item.className = 'account-item' + (acc.id === activeAccountId ? ' active' : '') + (acc.status === 'closed' ? ' closed' : '');
    item.dataset.id = acc.id;
    item.draggable = true;
    const statsLine = acc.status === 'open' ? `CPU —  RAM —` : '';
    item.innerHTML = `
      <div class="row1">
        <span class="dot ${acc.status === 'closed' ? 'closed-dot' : ''}" style="background:${acc.status === 'closed' ? '' : ACCOUNT_COLORS[acc.colorIdx % ACCOUNT_COLORS.length]}"></span>
        <span class="acc-icn">${ICONS[acc.iconKey] || ICONS.apps}</span>
        <span class="blur-target">${escapeHtml(acc.name)}</span>
      </div>
      <div class="row2">${acc.status === 'open' ? t('statusOnline') + ' · ' + formatUptime(acc.createdAt) : t('statusClosed')}</div>
      <div class="row3" data-stats="${acc.id}">${statsLine}</div>
    `;
    item.addEventListener('click', () => { if (acc.status === 'closed') openAccount(acc.id); else setActiveAccount(acc.id); });
    item.addEventListener('contextmenu', (e) => { e.preventDefault(); openContextMenu(e.clientX, e.clientY, acc.id); });
    item.addEventListener('dragstart', (e) => { item.classList.add('dragging'); e.dataTransfer.setData('text/acc-id', String(acc.id)); });
    item.addEventListener('dragend', () => item.classList.remove('dragging'));
    item.addEventListener('dragover', (e) => { e.preventDefault(); item.classList.add('drag-over'); });
    item.addEventListener('dragleave', () => item.classList.remove('drag-over'));
    item.addEventListener('drop', (e) => {
      e.preventDefault(); item.classList.remove('drag-over');
      const draggedId = Number(e.dataTransfer.getData('text/acc-id'));
      if (draggedId) reorderAccount(draggedId, acc.id);
    });
    accountListEl.appendChild(item);
  });
  // Atualiza os botões do seletor rápido de contas (1-12) na barra superior
  renderQuickAccounts();
}
$('#close-all-btn').addEventListener('click', closeAllAccountsOfActiveWorkspace);
// ---------------------------------------------------------------------------
// Grid principal — mantém webviews de TODOS os workspaces montadas (nunca
// remove/reparenta ao trocar de workspace: só oculta com display:none),
// para que as contas continuem rodando em segundo plano sem recarregar.
// ---------------------------------------------------------------------------
function computeAutoGrid(n) {
  if (n === 0) return { cols: 1, rows: 1 };
  const cols = Math.ceil(Math.sqrt(n));
  return { cols, rows: Math.ceil(n / cols) };
}
// ---------------------------------------------------------------------------
// Divisórias arrastáveis na Grade automática (estilo editor de código:
// arrastar a linha entre 2 painéis vizinhos só redimensiona esses dois)
//
// Otimizações:
// - "criar" (DOM + listeners) só roda quando o grid é reconstruído; durante
//   o arraste usamos "reposicionar", que só recalcula números e atualiza
//   `style.left`/`style.top` dos elementos já existentes (sem recriar nada).
// - o tamanho do container é lido (grid.clientWidth/Height) UMA vez no
//   mousedown, não a cada mousemove — ler layout logo depois de escrever
//   `gridTemplateColumns` força um reflow síncrono ("layout thrashing");
//   guardando o valor em cache evitamos qualquer leitura de layout durante
//   o arraste inteiro.
// - as atualizações de mousemove são agrupadas com requestAnimationFrame,
//   então mesmo que o mouse dispare dezenas de eventos entre frames, só
//   aplicamos uma vez por frame.
// ---------------------------------------------------------------------------
const GRID_PADDING = 6; // deve bater com o padding do #grid no CSS
const GRID_GAP = 6;
const MIN_FR = 0.2;
function clearAutoGridGutters() {
  grid.querySelectorAll('.col-gutter, .row-gutter').forEach((el) => el.remove());
}
function computeTrackBoundaries(fracArray, containerSize, gap) {
  const totalFr = fracArray.reduce((a, b) => a + b, 0) || 1;
  const totalGaps = gap * Math.max(fracArray.length - 1, 0);
  const usable = Math.max(containerSize - totalGaps, 0);
  let pos = 0;
  const boundaries = [];
  fracArray.forEach((fr) => {
    pos += (fr / totalFr) * usable;
    boundaries.push(pos);
    pos += gap;
  });
  return boundaries; // boundaries[i] = borda direita/inferior da faixa i (antes do gap seguinte)
}
// Recria os elementos de divisória do zero (cara — só na renderização do grid)
function layoutAutoGridGutters(ws, cols, rows) {
  clearAutoGridGutters();
  if (!ws || ws.layout !== 'auto') return;
  const contentWidth = grid.clientWidth - GRID_PADDING * 2;
  const contentHeight = grid.clientHeight - GRID_PADDING * 2;
  if (cols > 1) {
    for (let i = 0; i < cols - 1; i++) {
      const gutter = document.createElement('div');
      gutter.className = 'col-gutter';
      gutter.addEventListener('mousedown', (e) => startColumnDrag(e, ws, i));
      grid.appendChild(gutter);
    }
    repositionGutters('col', ws.autoGridColFr, contentWidth);
  }
  if (rows > 1) {
    for (let i = 0; i < rows - 1; i++) {
      const gutter = document.createElement('div');
      gutter.className = 'row-gutter';
      gutter.addEventListener('mousedown', (e) => startRowDrag(e, ws, i));
      grid.appendChild(gutter);
    }
    repositionGutters('row', ws.autoGridRowFr, contentHeight);
  }
}
// Só reposiciona os elementos já existentes — nenhuma leitura de layout,
// nenhuma criação de nó/listener. Chamado a cada frame durante o arraste.
function repositionGutters(axis, fracArray, containerSize) {
  const boundaries = computeTrackBoundaries(fracArray, containerSize, GRID_GAP);
  const els = grid.querySelectorAll(axis === 'col' ? '.col-gutter' : '.row-gutter');
  const prop = axis === 'col' ? 'left' : 'top';
  els.forEach((el, idx) => {
    el.style[prop] = `${GRID_PADDING + boundaries[idx] + GRID_GAP / 2 - 3}px`;
  });
}
function startAxisDrag(e, ws, i, axis) {
  e.preventDefault();
  const isCol = axis === 'col';
  const frArray = isCol ? ws.autoGridColFr : ws.autoGridRowFr;
  const startPos = isCol ? e.clientX : e.clientY;
  const startA = frArray[i];
  const startB = frArray[i + 1];
  const sum = startA + startB;
  // Lido UMA vez — o tamanho do container não muda durante o arraste de um só eixo.
  const containerSize = (isCol ? grid.clientWidth : grid.clientHeight) - GRID_PADDING * 2;
  const totalFr = frArray.reduce((a, b) => a + b, 0);
  const frPerPixel = totalFr / Math.max(containerSize, 1);
  // Cada <webview> roda num processo separado e "engole" os eventos de mouse
  // quando o cursor passa por cima dela — por isso o arraste "parava" ao
  // cruzar outra conta. Uma camada transparente por cima de tudo (elemento
  // comum do documento, não um webview) captura o mouse o tempo todo,
  // independente de sobre qual conta o cursor esteja passando.
  const captureLayer = document.createElement('div');
  captureLayer.className = 'drag-capture-layer';
  captureLayer.style.cursor = isCol ? 'col-resize' : 'row-resize';
  document.body.appendChild(captureLayer);
  document.body.style.cursor = isCol ? 'col-resize' : 'row-resize';
  let rafId = null;
  let lastEvent = null;
  function apply() {
    rafId = null;
    const deltaFr = ((isCol ? lastEvent.clientX : lastEvent.clientY) - startPos) * frPerPixel;
    // Clamp preservando a soma (startA+startB) — garante os dois lados dentro
    // do limite mínimo ao mesmo tempo, sem os "saltos" do clamp sequencial.
    let newA = Math.min(Math.max(startA + deltaFr, MIN_FR), sum - MIN_FR);
    const newB = sum - newA;
    frArray[i] = newA;
    frArray[i + 1] = newB;
    grid.style[isCol ? 'gridTemplateColumns' : 'gridTemplateRows'] = frArray.map((v) => `${v.toFixed(4)}fr`).join(' ');
    repositionGutters(axis, frArray, containerSize);
  }
  function onMove(ev) {
    lastEvent = ev;
    if (rafId == null) rafId = requestAnimationFrame(apply);
  }
  function onUp() {
    captureLayer.removeEventListener('mousemove', onMove);
    captureLayer.removeEventListener('mouseup', onUp);
    captureLayer.remove();
    if (rafId != null) cancelAnimationFrame(rafId);
    document.body.style.cursor = '';
    schedulePersist();
  }
  captureLayer.addEventListener('mousemove', onMove);
  captureLayer.addEventListener('mouseup', onUp);
  captureLayer.addEventListener('mouseleave', onUp);
}
function startColumnDrag(e, ws, i) { startAxisDrag(e, ws, i, 'col'); }
function startRowDrag(e, ws, i) { startAxisDrag(e, ws, i, 'row'); }
function renderGrid() {
  const ws = getActiveWorkspace();
  const layout = ws ? (ws.layout || 'auto') : 'auto';
  const allOpenThisWorkspace = ws ? ws.accounts.filter((a) => a.status === 'open') : [];
  let visibleAccounts = allOpenThisWorkspace;
  if (layout === 'single') {
    const active = allOpenThisWorkspace.find((a) => a.id === activeAccountId);
    visibleAccounts = active ? [active] : (allOpenThisWorkspace[0] ? [allOpenThisWorkspace[0]] : []);
  }
  const visibleOrder = new Map(visibleAccounts.map((a, idx) => [a.id, idx]));
  grid.classList.toggle('layout-single', layout === 'single');
  grid.classList.toggle('layout-free', layout === 'free');
  const allOpenIdsEverywhere = new Set(state.workspaces.flatMap((w) => w.accounts.filter((a) => a.status === 'open').map((a) => a.id)));
  Array.from(grid.children).forEach((child) => {
    if (!child.classList || !child.classList.contains('account-card')) return;
    const id = Number(child.dataset.id);
    if (!allOpenIdsEverywhere.has(id)) { child.remove(); rafThrottleState.delete(id); return; }
    const isVisible = visibleOrder.has(id);
    if (isVisible) { child.style.display = ''; child.style.order = String(visibleOrder.get(id)); }
    else { child.style.display = 'none'; }
    const webview = child.querySelector('webview');
    if (webview) applyRafThrottle(webview, id, isVisible);
  });
  visibleAccounts.forEach((acc, idx) => {
    if (!grid.querySelector(`.account-card[data-id="${acc.id}"]`)) {
      const card = buildCard(acc);
      card.style.order = String(idx);
      grid.appendChild(card);
    }
  });
  if (layout === 'columns') {
    grid.style.gridTemplateColumns = `repeat(${Math.max(visibleAccounts.length, 1)}, 1fr)`;
    grid.style.gridTemplateRows = '1fr';
  } else if (layout === 'rows') {
    grid.style.gridTemplateColumns = '1fr';
    grid.style.gridTemplateRows = `repeat(${Math.max(visibleAccounts.length, 1)}, 1fr)`;
  } else if (layout === 'single' || layout === 'free') {
    grid.style.gridTemplateColumns = ''; grid.style.gridTemplateRows = '';
  } else if (layout === 'custom') {
    const cols = Math.max(1, Math.min(8, (ws && ws.customCols) || 2));
    const rows = Math.max(1, Math.min(8, (ws && ws.customRows) || 2));
    grid.style.gridTemplateColumns = `repeat(${cols}, 1fr)`;
    grid.style.gridTemplateRows = `repeat(${rows}, 1fr)`;
  } else {
    const { cols, rows } = computeAutoGrid(visibleAccounts.length);
    if (ws) {
      if (!Array.isArray(ws.autoGridColFr) || ws.autoGridColFr.length !== cols) ws.autoGridColFr = new Array(cols).fill(1);
      if (!Array.isArray(ws.autoGridRowFr) || ws.autoGridRowFr.length !== rows) ws.autoGridRowFr = new Array(rows).fill(1);
      grid.style.gridTemplateColumns = ws.autoGridColFr.map((v) => `${v}fr`).join(' ');
      grid.style.gridTemplateRows = ws.autoGridRowFr.map((v) => `${v}fr`).join(' ');
    } else {
      grid.style.gridTemplateColumns = `repeat(${cols}, 1fr)`;
      grid.style.gridTemplateRows = `repeat(${rows}, 1fr)`;
    }
  }
  const emptyEl = $('#grid-empty-state');
  if (emptyEl) emptyEl.classList.toggle('hidden', visibleAccounts.length !== 0);
  clearAutoGridGutters();
  if (layout === 'auto' && ws) {
    const { cols, rows } = computeAutoGrid(visibleAccounts.length);
    if (cols > 1 || rows > 1) requestAnimationFrame(() => layoutAutoGridGutters(ws, cols, rows));
  }
}
// ---------------------------------------------------------------------------
// Throttle de requestAnimationFrame — corrige o "bug de segundo plano" (uma
// conta com display:none continua rodando a 60fps completos por dentro,
// já que o Electron não pausa isso sozinho) e serve de base pro Modo Eco.
//
// Como funciona: injetamos uma pequena função na página de cada conta que
// TROCA window.requestAnimationFrame por uma versão baseada em setTimeout
// com um intervalo configurável. O jogo continua recebendo os "ticks" de
// animação normalmente (com o timestamp certo), só que com menos frequência
// — jogos idle/incremental calculam progresso pela diferença de tempo real
// (Date.now()), não pela quantidade de frames, então o progresso NÃO se
// perde, só a frequência de redesenho cai. Nada é pausado/congelado.
// ---------------------------------------------------------------------------
const RAF_THROTTLE_INJECT = `(function(){
  if (window.__idleHubRafPatched) return;
  window.__idleHubRafPatched = true;
  var nativeRAF = window.requestAnimationFrame.bind(window);
  var nativeCAF = window.cancelAnimationFrame.bind(window);
  var throttleMs = 0;
  var pending = Object.create(null);
  var nextId = 1;
  window.__idleHubSetRafThrottle = function(ms) { throttleMs = ms || 0; };
  window.requestAnimationFrame = function(cb) {
    if (!throttleMs) return nativeRAF(cb);
    var id = nextId++;
    pending[id] = setTimeout(function(){ delete pending[id]; cb(performance.now()); }, throttleMs);
    return id;
  };
  window.cancelAnimationFrame = function(id) {
    if (pending[id]) { clearTimeout(pending[id]); delete pending[id]; return; }
    nativeCAF(id);
  };
})();`;
const BACKGROUND_THROTTLE_MS = 1500; // contas ocultas (outro workspace, ou cobertas no layout "Painel único")
const ECO_ACTIVE_THROTTLE_MS = 200;  // conta visível, mas com Modo Eco ligado
const rafThrottleState = new Map(); // accountId -> valor já aplicado (evita mandar executeJavaScript à toa)
function computeThrottleFor(isVisible) {
  if (!isVisible) return BACKGROUND_THROTTLE_MS;
  return state.settings.modoEco ? ECO_ACTIVE_THROTTLE_MS : 0;
}
function applyRafThrottle(webview, accountId, isVisible) {
  const ms = computeThrottleFor(isVisible);
  if (rafThrottleState.get(accountId) === ms) return;
  rafThrottleState.set(accountId, ms);
  webview.executeJavaScript(`window.__idleHubSetRafThrottle && window.__idleHubSetRafThrottle(${ms})`).catch(() => {});
}
// Chamado ao ligar/desligar o Modo Eco — reaplica o throttle certo em tudo
// que já está montado (contas ocultas não mudam, só as visíveis).
function refreshAllRafThrottles() {
  document.querySelectorAll('.account-card').forEach((card) => {
    const id = Number(card.dataset.id);
    const isVisible = card.style.display !== 'none';
    const webview = card.querySelector('webview');
    if (webview) applyRafThrottle(webview, id, isVisible);
  });
}
function buildCard(acc) {
  const card = document.createElement('div');
  card.className = 'account-card';
  card.dataset.id = acc.id;
  card.draggable = true;
  const ws = state.workspaces.find((w) => w.accounts.some((a) => a.id === acc.id));
  if (ws && ws.layout === 'free') {
    card.style.width = (acc.freeWidth || 420) + 'px';
    card.style.height = (acc.freeHeight || 300) + 'px';
  }
  const header = document.createElement('div');
  header.className = 'card-header';
  header.innerHTML = `
    <span class="drag-handle">::</span>
    <span class="dot" style="background:${ACCOUNT_COLORS[acc.colorIdx % ACCOUNT_COLORS.length]}"></span>
    <span class="acc-icn">${ICONS[acc.iconKey] || ICONS.apps}</span>
    <span class="name blur-target">${escapeHtml(acc.name)}</span>
    <span class="url blur-target">${escapeHtml(acc.url)}</span>
    <button class="mute" title="Mudo">${muteIcon(acc.muted)}</button>
    <button class="reload" title="Recarregar">${ICONS_MINI.reload}</button>
    <button class="report" title="Kit-Ticket" style="color:#f5a524">${ICONS_MINI.report}</button>
    <button class="netrecord" title="Gravar rede (HAR)">${ICONS_MINI.record}</button>
    <button class="open-window" title="Abrir em nova janela">${ICONS_MINI.openWindow}</button>
    <button class="expand" title="Maximizar/Restaurar">${ICONS_MINI.expand}</button>
    <button class="close" title="Fechar conta">${ICONS_MINI.close}</button>
  `;
  const wrap = document.createElement('div');
  wrap.className = 'card-webview-wrap';
  const webview = document.createElement('webview');
  webview.setAttribute('src', acc.url);
  webview.setAttribute('partition', acc.partition);
  webview.setAttribute('allowpopups', '');
  try { window.nativeAPI.registerPartitionDownloads(acc.partition); } catch (err) { /* ignore */ }
  // Interagir com o conteúdo da página seleciona a conta automaticamente
  webview.addEventListener('focus', () => setActiveAccount(acc.id));
  webview.addEventListener('dom-ready', () => {
    acc.webContentsId = webview.getWebContentsId();
    if (effectiveMuted(acc)) webview.setAudioMuted(true);
    webview.setZoomFactor(acc.zoomFactor || 1);
    if (acc.id === activeAccountId) { updateNavButtons(); updateZoomLabel(); }
    rafThrottleState.delete(acc.id); // página recarregou — a patch some, precisa injetar de novo
    webview.executeJavaScript(RAF_THROTTLE_INJECT).then(() => {
      applyRafThrottle(webview, acc.id, card.style.display !== 'none');
    }).catch((err) => console.error('Erro ao aplicar throttle de rAF:', err));
    // Kit-Ticket: reinjeta a captura de console a cada carregamento de página
    // (window.__idleHubConsoleCaptureReady garante que não duplica o patch,
    // e o buffer reseta sozinho porque é uma variável nova na nova página).
    webview.executeJavaScript(CONSOLE_CAPTURE_INJECT).catch((err) => console.error('Erro ao aplicar captura de console:', err));
    if (credentials[acc.id] && credentials[acc.id].length) {
      autofillAccount(acc.id, false);
    }
    if (ws) {
      state.scripts.filter((s) => scriptAppliesToAccount(s, ws.id, acc.id)).forEach((s) => {
        webview.executeJavaScript(s.code).catch((err) => console.error(`Erro no script "${s.name}":`, err));
      });
    }
  });
  webview.addEventListener('did-navigate', (e) => {
    acc.url = e.url;
    header.querySelector('.url').textContent = e.url;
    if (acc.id === activeAccountId) { addressBar.value = e.url; updateNavButtons(); }
    schedulePersist();
  });
  webview.addEventListener('did-navigate-in-page', (e) => {
    acc.url = e.url;
    header.querySelector('.url').textContent = e.url;
    if (acc.id === activeAccountId) updateNavButtons();
    // SPAs trocam de "página" sem recarregar o documento — tenta preencher o
    // formulário que o site montou, com um atraso pro campo existir.
    if (credentials[acc.id] && credentials[acc.id].length) {
      setTimeout(() => autofillAccount(acc.id, false), 700);
    }
  });
  wrap.appendChild(webview);
  card.appendChild(header);
  card.appendChild(wrap);
  card.addEventListener('mousedown', () => setActiveAccount(acc.id));
  card.addEventListener('contextmenu', (e) => { e.preventDefault(); openContextMenu(e.clientX, e.clientY, acc.id); });
  header.querySelector('.mute').addEventListener('click', (ev) => {
    ev.stopPropagation();
    acc.muted = !acc.muted;
    webview.setAudioMuted(effectiveMuted(acc));
    header.querySelector('.mute').innerHTML = muteIcon(acc.muted);
    if (acc.id === activeAccountId) updateMuteButton();
    schedulePersist();
  });
  header.querySelector('.reload').addEventListener('click', (ev) => { ev.stopPropagation(); webview.reload(); });
  header.querySelector('.report').addEventListener('click', (ev) => { ev.stopPropagation(); openReportConfirm(acc.id); });
  header.querySelector('.netrecord').addEventListener('click', (ev) => { ev.stopPropagation(); toggleNetworkRecording(acc.id); });
  header.querySelector('.open-window').addEventListener('click', (ev) => { ev.stopPropagation(); openAccountInWindow(acc.id); });
  header.dataset.tooltip = t('dblClickHint');
  header.querySelector('.expand').addEventListener('click', (ev) => { ev.stopPropagation(); card.classList.toggle('maximized'); });
  header.addEventListener('dblclick', (ev) => {
    if (ev.target.closest('button')) return; // duplo-clique num botão do cabeçalho não deve maximizar
    card.classList.toggle('maximized');
  });
  header.querySelector('.close').addEventListener('click', (ev) => { ev.stopPropagation(); closeAccount(acc.id); });
  card.addEventListener('dragstart', (e) => { card.classList.add('dragging'); e.dataTransfer.setData('text/acc-id', String(acc.id)); });
  card.addEventListener('dragend', () => card.classList.remove('dragging'));
  card.addEventListener('dragover', (e) => { e.preventDefault(); card.classList.add('drag-over'); });
  card.addEventListener('dragleave', () => card.classList.remove('drag-over'));
  card.addEventListener('drop', (e) => {
    e.preventDefault(); card.classList.remove('drag-over');
    const draggedId = Number(e.dataTransfer.getData('text/acc-id'));
    if (draggedId) reorderAccount(draggedId, acc.id);
  });
  if (ws && ws.layout === 'free' && 'ResizeObserver' in window) {
    let resizeTimer = null;
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const w = Math.round(entry.contentRect.width + 2);
        const h = Math.round(entry.contentRect.height + 34);
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => { acc.freeWidth = w; acc.freeHeight = h; schedulePersist(); }, 300);
      }
    });
    observer.observe(card);
  }
  return card;
}
// ---------------------------------------------------------------------------
// Menu de contexto (conta)
// ---------------------------------------------------------------------------
const ctxMenu = $('#context-menu');
let ctxAccountId = null;
function openContextMenu(x, y, accountId) {
  ctxAccountId = accountId;
  const acc = getAccountById(accountId);
  if (!acc) return;
  const muteBtn = ctxMenu.querySelector('[data-action="mute"] span');
  muteBtn.textContent = acc.muted ? t('ctxUnmute') : t('ctxMute');
  const closeBtn = ctxMenu.querySelector('[data-action="close"]');
  closeBtn.style.display = acc.status === 'open' ? 'flex' : 'none';
  ctxMenu.classList.remove('hidden');
  const w = 220, h = 376; // +36px pela nova opção "Abrir em nova janela"
  ctxMenu.style.left = `${Math.max(4, Math.min(x, window.innerWidth - w - 8))}px`;
  ctxMenu.style.top = `${Math.max(4, Math.min(y, window.innerHeight - h - 8))}px`;
}
function closeContextMenu() { ctxMenu.classList.add('hidden'); ctxAccountId = null; }
document.addEventListener('click', (e) => { if (!ctxMenu.contains(e.target)) closeContextMenu(); });
ctxMenu.addEventListener('click', (e) => {
  const btn = e.target.closest('button[data-action]');
  if (!btn || ctxAccountId == null) return;
  const id = ctxAccountId, acc = getAccountById(id), action = btn.dataset.action;
  switch (action) {
    case 'reload': {
      const webview = grid.querySelector(`.account-card[data-id="${id}"] webview`);
      if (webview) webview.reload(); else if (acc) openAccount(id);
      break;
    }
    case 'devtools': {
      const webview = grid.querySelector(`.account-card[data-id="${id}"] webview`);
      if (webview) { if (webview.isDevToolsOpened()) webview.closeDevTools(); else webview.openDevTools(); }
      else if (acc) openAccount(id);
      break;
    }
    case 'default-url': {
      if (!acc) break;
      if (acc.status === 'open') {
        const webview = grid.querySelector(`.account-card[data-id="${id}"] webview`);
        if (webview) webview.loadURL(acc.defaultUrl);
        acc.url = acc.defaultUrl;
      } else openAccount(id, acc.defaultUrl);
      break;
    }
    case 'mute': {
      if (!acc) break;
      acc.muted = !acc.muted;
      const card = grid.querySelector(`.account-card[data-id="${id}"]`);
      const webview = card && card.querySelector('webview');
      if (webview) webview.setAudioMuted(effectiveMuted(acc));
      const cardMuteBtn = card && card.querySelector('.mute');
      if (cardMuteBtn) cardMuteBtn.innerHTML = muteIcon(acc.muted);
      if (id === activeAccountId) updateMuteButton();
      schedulePersist();
      break;
    }
    case 'close': closeAccount(id); break;
    case 'edit': openAccountModal('edit', id); break;
    case 'duplicate': duplicateAccount(id); break;
    case 'open-window': openAccountInWindow(id); break;
    case 'clear-data': clearAccountData(id); break;
    case 'delete': deleteAccount(id); break;
  }
  closeContextMenu();
});
// ---------------------------------------------------------------------------
// Toolbar: voltar / avançar / recarregar / início / endereço / aplicar a todas
// ---------------------------------------------------------------------------
function updateNavButtons() {
  const webview = getActiveWebview();
  const back = $('#nav-back'), fwd = $('#nav-forward');
  if (!webview) { back.disabled = true; fwd.disabled = true; return; }
  try { back.disabled = !webview.canGoBack(); fwd.disabled = !webview.canGoForward(); }
  catch (err) { back.disabled = true; fwd.disabled = true; }
}
$('#nav-back').addEventListener('click', () => { const w = getActiveWebview(); if (w && w.canGoBack()) w.goBack(); });
$('#nav-forward').addEventListener('click', () => { const w = getActiveWebview(); if (w && w.canGoForward()) w.goForward(); });
$('#nav-reload').addEventListener('click', () => { const w = getActiveWebview(); if (w) w.reload(); });
$('#nav-home').addEventListener('click', () => {
  const ws = getActiveWorkspace(), w = getActiveWebview();
  if (w && ws) { w.loadURL(ws.defaultUrl); const acc = getActiveAccount(); if (acc) acc.url = ws.defaultUrl; }
});
function navigateActive(url) {
  if (!activeAccountId) return;
  const full = normalizeUrl(url.trim());
  const webview = getActiveWebview();
  if (webview) webview.loadURL(full);
  const acc = getAccountById(activeAccountId);
  if (acc) acc.url = full;
}
function navigateAllOpen(url) {
  const ws = getActiveWorkspace();
  if (!ws) return;
  const full = normalizeUrl(url.trim());
  ws.accounts.filter((a) => a.status === 'open').forEach((acc) => {
    const webview = grid.querySelector(`.account-card[data-id="${acc.id}"] webview`);
    if (webview) webview.loadURL(full);
    acc.url = full;
  });
}
$('#nav-go-all').addEventListener('click', () => navigateAllOpen(addressBar.value || DEFAULT_URL));
addressBar.addEventListener('keydown', (e) => { if (e.key === 'Enter') navigateActive(addressBar.value); });
// ---------------------------------------------------------------------------
// Toolbar: mudo / zoom / downloads / modo tela limpa / tela cheia / config / ajuda
// ---------------------------------------------------------------------------
function updateMuteButton() {
  const muted = !!state.settings.mudoGlobal;
  const btn = $('#topbar-mute');
  btn.innerHTML = muteIcon(muted);
  btn.classList.toggle('active-state', muted);
}
$('#topbar-mute').addEventListener('click', () => {
  state.settings.mudoGlobal = !state.settings.mudoGlobal;
  const allOpen = state.workspaces.flatMap((w) => w.accounts.filter((a) => a.status === 'open'));
  allOpen.forEach((acc) => {
    const card = grid.querySelector(`.account-card[data-id="${acc.id}"]`);
    const webview = card && card.querySelector('webview');
    if (webview) webview.setAudioMuted(effectiveMuted(acc));
  });
  updateMuteButton();
  schedulePersist();
});
function updateZoomLabel() {
  const acc = getActiveAccount();
  $('#zoom-label').textContent = `${Math.round((acc ? acc.zoomFactor || 1 : 1) * 100)}%`;
}
function adjustZoom(delta) {
  const acc = getActiveAccount();
  const webview = getActiveWebview();
  if (!acc || !webview) return;
  let z = Math.min(2, Math.max(0.5, Math.round(((acc.zoomFactor || 1) + delta) * 100) / 100));
  acc.zoomFactor = z;
  webview.setZoomFactor(z);
  updateZoomLabel();
  schedulePersist();
}
function resetZoom() {
  const acc = getActiveAccount();
  const webview = getActiveWebview();
  if (!acc || !webview) return;
  acc.zoomFactor = 1;
  webview.setZoomFactor(1);
  updateZoomLabel();
  schedulePersist();
}
$('#topbar-zoom').addEventListener('click', (e) => { e.stopPropagation(); $('#downloads-popover').classList.add('hidden'); $('#zoom-popover').classList.toggle('hidden'); });
document.addEventListener('click', () => $('#zoom-popover').classList.add('hidden'));
$('#zoom-popover').addEventListener('click', (e) => e.stopPropagation());
$('#zoom-in').addEventListener('click', () => adjustZoom(0.1));
$('#zoom-out').addEventListener('click', () => adjustZoom(-0.1));
$('#zoom-reset').addEventListener('click', resetZoom);
// ---------------------------------------------------------------------------
// Downloads: popover flutuante com os downloads desta sessão
// ---------------------------------------------------------------------------
let downloadsLog = [];
function formatBytes(n) {
  if (!n) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  let i = 0; let v = n;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(v >= 10 || i === 0 ? 0 : 1)} ${units[i]}`;
}
function renderDownloadsList() {
  const wrap = $('#downloads-list');
  if (!downloadsLog.length) {
    wrap.innerHTML = `<div class="downloads-empty">${t('downloadsEmpty')}</div>`;
    return;
  }
  wrap.innerHTML = downloadsLog.slice().reverse().map((d) => {
    let statusLabel;
    if (d.state === 'completed') statusLabel = `✓ ${formatBytes(d.totalBytes || d.receivedBytes)}`;
    else if (d.state === 'progressing') statusLabel = `${formatBytes(d.receivedBytes)} / ${formatBytes(d.totalBytes)}`;
    else if (d.state === 'cancelled' || d.state === 'interrupted') statusLabel = '✕';
    else statusLabel = '…';
    return `<div class="download-item">
      <span class="download-name" title="${escapeHtml(d.filename || '')}">${escapeHtml(d.filename || '')}</span>
      <span class="download-status ${d.state}">${statusLabel}</span>
    </div>`;
  }).join('');
}
try {
  window.nativeAPI.onDownloadEvent((data) => {
    const idx = downloadsLog.findIndex((d) => d.id === data.id);
    if (idx === -1) downloadsLog.push(data);
    else downloadsLog[idx] = { ...downloadsLog[idx], ...data };
    if (downloadsLog.length > 50) downloadsLog = downloadsLog.slice(-50);
    if (!$('#downloads-popover').classList.contains('hidden')) renderDownloadsList();
  });
} catch (err) { /* ignore */ }
$('#topbar-downloads').addEventListener('click', (e) => {
  e.stopPropagation();
  $('#zoom-popover').classList.add('hidden');
  const pop = $('#downloads-popover');
  pop.classList.toggle('hidden');
  if (!pop.classList.contains('hidden')) renderDownloadsList();
});
$('#downloads-popover').addEventListener('click', (e) => e.stopPropagation());
document.addEventListener('click', () => $('#downloads-popover').classList.add('hidden'));
$('#topbar-eco').addEventListener('click', toggleEcoMode);
$('#topbar-presentation').addEventListener('click', togglePresentationMode);
$('#topbar-cleanmode').addEventListener('click', toggleCleanMode);
async function toggleFullscreenMode() {
  try {
    const isFull = await window.nativeAPI.toggleFullscreen();
    document.body.classList.toggle('is-fullscreen', !!isFull);
  } catch (err) { /* ignore */ }
}
$('#topbar-fullscreen').addEventListener('click', toggleFullscreenMode);
$('#topbar-settings').addEventListener('click', () => openSettingsModal());
$('#topbar-help').addEventListener('click', () => openShortcutsModal());
// ---------------------------------------------------------------------------
// Abertura de links do Midgard Idle no navegador padrão
// ---------------------------------------------------------------------------
$('#topbar-midgard-wiki').addEventListener('click', () => {
  window.nativeAPI.openExternal('https://midgardidlewikifull.vercel.app/');
});
$('#topbar-midgard-ranking').addEventListener('click', () => {
  window.nativeAPI.openExternal('https://midgardidle.ro/rankings');
});
$('#topbar-midgard-discord').addEventListener('click', () => {
  window.nativeAPI.openExternal('https://discord.gg/R7rRrFxBPd');
});
// ---------------------------------------------------------------------------
// Atalhos de teclado — sistema com combinações remapeáveis pelo usuário
// ---------------------------------------------------------------------------
const ACTION_DEFS = [
  { id: 'nextPanel', labelKey: 'shcNextPanel', def: { ctrl: true, key: 'Tab' } },
  { id: 'newWorkspace', labelKey: 'shcNewWorkspace', def: { ctrl: true, shift: true, key: 'n' } },
  { id: 'newAccount', labelKey: 'shcNewAccount', def: { ctrl: true, key: 'n' } },
  { id: 'deleteAccount', labelKey: 'shcDeleteAccount', def: { ctrl: true, key: 'x' } },
  { id: 'devtools', labelKey: 'shcDevtools', def: { key: 'F12' } },
  { id: 'reloadActive', labelKey: 'shcReloadActive', def: { ctrl: true, key: 'r' } },
  { id: 'reloadNoCache', labelKey: 'shcReloadNoCache', def: { ctrl: true, shift: true, key: 'r' } },
  { id: 'reloadAll', labelKey: 'shcReloadAll', def: { ctrl: true, alt: true, key: 'r' } },
  { id: 'muteActive', labelKey: 'shcMuteActive', def: { ctrl: true, key: 'm' } },
  { id: 'muteAll', labelKey: 'shcMuteAll', def: { ctrl: true, shift: true, key: 'm' } },
  { id: 'focusAddress', labelKey: 'shcFocusAddress', def: { ctrl: true, key: 'l' } },
  { id: 'zoomIn', labelKey: 'shcZoomIn', def: { ctrl: true, key: '=' } },
  { id: 'zoomOut', labelKey: 'shcZoomOut', def: { ctrl: true, key: '-' } },
  { id: 'zoomReset', labelKey: 'shcZoomReset', def: { ctrl: true, key: '0' } },
  { id: 'cleanMode', labelKey: 'shcCleanMode', def: { ctrl: true, shift: true, key: 'z' } },
  { id: 'presentationMode', labelKey: 'shcPresentation', def: { ctrl: true, shift: true, key: 'p' } },
  { id: 'ecoMode', labelKey: 'shcEcoMode', def: { ctrl: true, shift: true, key: 'e' } },
  { id: 'fullscreen', labelKey: 'shcFullscreen', def: { key: 'F11' } },
  { id: 'fillCredentials', labelKey: 'shcFillCredentials', def: { ctrl: true, shift: true, key: 'f' } },
  { id: 'settings', labelKey: 'shcSettings', def: { ctrl: true, key: ',' } },
  { id: 'help', labelKey: 'shcHelp', def: { key: 'F1' } },
];
// Combos que continuam sendo o padrão do sistema operacional/navegador
// (recortar/copiar/colar/desfazer/refazer) enquanto o foco estiver num campo
// de texto NOSSO (endereço, nome de script, etc.) — nunca interceptamos esses
// ali, mesmo que "excluir conta" use Ctrl+X por padrão.
const NATIVE_EDIT_KEYS = ['x', 'c', 'v', 'a', 'z', 'y'];
function getBinding(actionId) {
  const custom = state.settings.keybindings && state.settings.keybindings[actionId];
  if (custom) return custom;
  const def = ACTION_DEFS.find((a) => a.id === actionId);
  return def ? def.def : null;
}
function normalizeKey(key) {
  return key.length === 1 ? key.toLowerCase() : key;
}
function comboMatches(e, combo) {
  if (!combo) return false;
  const hasCtrl = e.ctrlKey || e.metaKey;
  if (hasCtrl !== !!combo.ctrl) return false;
  if (e.shiftKey !== !!combo.shift) return false;
  if (e.altKey !== !!combo.alt) return false;
  return normalizeKey(e.key) === combo.key;
}
function comboToKeyParts(combo) {
  if (!combo) return ['—'];
  const parts = [];
  if (combo.ctrl) parts.push('Ctrl');
  if (combo.shift) parts.push('Shift');
  if (combo.alt) parts.push('Alt');
  let k = combo.key;
  if (k === ' ') k = 'Space';
  else if (k.length === 1) k = k.toUpperCase();
  parts.push(k);
  return parts;
}
function isEditableTarget(target) {
  const tag = target.tagName;
  return tag === 'INPUT' || tag === 'TEXTAREA' || target.isContentEditable;
}
function runAction(id) {
  switch (id) {
    case 'nextPanel': {
      const open = getOpenAccountsOfActiveWorkspace();
      if (!open.length) return;
      const idx = open.findIndex((a) => a.id === activeAccountId);
      setActiveAccount(open[(idx + 1) % open.length].id);
      break;
    }
    case 'newWorkspace': createWorkspace(); break;
    case 'newAccount': openAccountModal('create'); break;
    case 'deleteAccount': if (activeAccountId) deleteAccount(activeAccountId); break;
    case 'devtools': {
      const w = getActiveWebview();
      if (w) { if (w.isDevToolsOpened()) w.closeDevTools(); else w.openDevTools(); }
      break;
    }
    case 'reloadActive': { const w = getActiveWebview(); if (w) w.reload(); break; }
    case 'reloadNoCache': { const w = getActiveWebview(); if (w) w.reloadIgnoringCache(); break; }
    case 'reloadAll':
      getOpenAccountsOfActiveWorkspace().forEach((acc) => {
        const w = grid.querySelector(`.account-card[data-id="${acc.id}"] webview`);
        if (w) w.reload();
      });
      break;
    case 'muteActive': $('#topbar-mute').click(); break;
    case 'muteAll': {
      const open = getOpenAccountsOfActiveWorkspace();
      const anyUnmuted = open.some((a) => !a.muted);
      open.forEach((acc) => {
        acc.muted = anyUnmuted;
        const w = grid.querySelector(`.account-card[data-id="${acc.id}"] webview`);
        if (w) w.setAudioMuted(effectiveMuted(acc));
        const btn = grid.querySelector(`.account-card[data-id="${acc.id}"] .mute`);
        if (btn) btn.innerHTML = muteIcon(anyUnmuted);
      });
      updateMuteButton(); schedulePersist();
      break;
    }
    case 'focusAddress': addressBar.focus(); addressBar.select(); break;
    case 'zoomIn': adjustZoom(0.1); break;
    case 'zoomOut': adjustZoom(-0.1); break;
    case 'zoomReset': resetZoom(); break;
    case 'cleanMode': toggleCleanMode(); break;
    case 'presentationMode': togglePresentationMode(); break;
    case 'ecoMode': toggleEcoMode(); break;
    case 'fullscreen': toggleFullscreenMode(); break;
    case 'fillCredentials': if (activeAccountId != null) autofillAccount(activeAccountId, true); break;
    case 'settings': openSettingsModal(); break;
    case 'help': openShortcutsModal(); break;
  }
}
window.addEventListener('keydown', (e) => {
  // Modo "capturando nova tecla" no editor de atalhos tem prioridade sobre tudo
  if (capturingActionId) { captureKeybinding(e); return; }
  const mod = e.ctrlKey || e.metaKey;
  // Nunca atrapalha recortar/copiar/colar/desfazer normais enquanto o foco
  // está num campo de texto nosso (mesmo que "Excluir conta" use Ctrl+X).
  if (isEditableTarget(e.target) && mod && !e.altKey && NATIVE_EDIT_KEYS.includes(e.key.toLowerCase())) return;
  // Ctrl+1..9 seleciona o painel — é uma faixa, não faz parte do remapeamento
  if (mod && !e.shiftKey && !e.altKey && /^[1-9]$/.test(e.key)) {
    e.preventDefault();
    const open = getOpenAccountsOfActiveWorkspace();
    const acc = open[Number(e.key) - 1];
    if (acc) setActiveAccount(acc.id);
    return;
  }
  for (const def of ACTION_DEFS) {
    if (comboMatches(e, getBinding(def.id))) { e.preventDefault(); runAction(def.id); return; }
  }
});
// ---------------------------------------------------------------------------
// Modal: Atalhos de teclado (editável — clique em "Alterar" pra remapear)
// ---------------------------------------------------------------------------
let capturingActionId = null;
function startCapture(actionId, btnEl) {
  capturingActionId = actionId;
  document.querySelectorAll('.shortcut-change-btn').forEach((b) => b.classList.remove('capturing'));
  btnEl.textContent = t('pressKeys');
  btnEl.classList.add('capturing');
}
function captureKeybinding(e) {
  e.preventDefault();
  if (e.key === 'Escape') { capturingActionId = null; renderShortcutsList(); return; }
  if (['Control', 'Shift', 'Alt', 'Meta'].includes(e.key)) return; // espera uma tecla "de verdade", não só o modificador
  const combo = { ctrl: e.ctrlKey || e.metaKey, shift: e.shiftKey, alt: e.altKey, key: normalizeKey(e.key) };
  if (!state.settings.keybindings) state.settings.keybindings = {};
  state.settings.keybindings[capturingActionId] = combo;
  capturingActionId = null;
  schedulePersist();
  renderShortcutsList();
}
function renderShortcutsList() {
  const wrap = $('#shortcuts-list');
  wrap.innerHTML = '';
  const fixedRow = document.createElement('div');
  fixedRow.className = 'shortcut-row';
  fixedRow.innerHTML = `<span>${escapeHtml(t('shcPanel19'))}</span><span class="kbd-group"><kbd>Ctrl</kbd><span class="plus">+</span><kbd>1–9</kbd></span>`;
  wrap.appendChild(fixedRow);
  ACTION_DEFS.forEach((def) => {
    const combo = getBinding(def.id);
    const row = document.createElement('div');
    row.className = 'shortcut-row';
    const kbdHtml = comboToKeyParts(combo).map((k) => `<kbd>${escapeHtml(k)}</kbd>`).join('<span class="plus">+</span>');
    row.innerHTML = `
      <span>${escapeHtml(t(def.labelKey))}</span>
      <span class="shortcut-edit-wrap">
        <span class="kbd-group">${kbdHtml}</span>
        <button class="shortcut-change-btn" type="button">${escapeHtml(t('changeBtn'))}</button>
      </span>`;
    row.querySelector('.shortcut-change-btn').addEventListener('click', (e) => startCapture(def.id, e.currentTarget));
    wrap.appendChild(row);
  });
}
function openShortcutsModal() { capturingActionId = null; renderShortcutsList(); $('#shortcuts-overlay').classList.remove('hidden'); }
$('#shortcuts-close').addEventListener('click', () => { capturingActionId = null; $('#shortcuts-overlay').classList.add('hidden'); });
$('#shortcuts-overlay').addEventListener('click', (e) => { if (e.target === $('#shortcuts-overlay')) { capturingActionId = null; $('#shortcuts-overlay').classList.add('hidden'); } });
$('#shortcuts-reset').addEventListener('click', () => {
  showConfirm(t('resetShortcutsTitle'), t('resetShortcutsBody'), () => {
    state.settings.keybindings = {};
    schedulePersist();
    renderShortcutsList();
  });
});
// ---------------------------------------------------------------------------
// Modal: criar / editar conta (nome + cor + ícone + URL + workspace +
// credenciais de autopreenchimento)
// ---------------------------------------------------------------------------
const overlay = $('#modal-overlay');
let modalMode = 'create';
let modalTargetId = null;
let modalColorIdx = 0;
let modalIconKey = 'apps';
let modalCreds = [];
function openAccountModal(mode, accountId) {
  modalMode = mode === 'edit' ? 'edit' : 'create';
  modalTargetId = modalMode === 'edit' ? accountId : null;
  const acc = modalTargetId != null ? getAccountById(modalTargetId) : null;
  const activeWs = getActiveWorkspace() || { accounts: [], id: state.workspaces[0] ? state.workspaces[0].id : null };
  const defaultName = nextSequentialName(activeWs.accounts.map((a) => a.name), t('accountWord'));
  $('#modal-title').textContent = modalTargetId != null ? t('editAccount') : t('addAccount');
  $('#modal-name').value = acc ? acc.name : defaultName;
  $('#modal-url').value = acc ? acc.defaultUrl : '';
  // Na criação dá pra escolher o workspace; na edição a conta já tem workspace
  $('#modal-workspace-wrap').classList.toggle('hidden', modalMode === 'edit');
  const wsSelect = $('#modal-workspace');
  wsSelect.innerHTML = state.workspaces.map((w) => `<option value="${w.id}">${escapeHtml(w.name)}</option>`).join('');
  if (activeWs.id != null) wsSelect.value = String(activeWs.id);
  $('#modal-open-wrap').classList.toggle('hidden', modalMode === 'edit');
  $('#modal-open').checked = true;
  modalColorIdx = acc ? (acc.colorIdx || 0) : (activeWs.accounts.length % ACCOUNT_COLORS.length);
  modalIconKey = acc ? (acc.iconKey || 'apps') : 'apps';
  renderModalColors();
  renderModalIcons();
  modalCreds = (modalMode === 'edit' && acc && credentials[acc.id]) ? credentials[acc.id].map((c) => ({ ...c })) : [];
  $('#modal-creds-sec').classList.toggle('hidden', modalMode !== 'edit');
  renderModalCreds();
  overlay.classList.remove('hidden');
  $('#modal-name').focus();
}
function renderModalColors() {
  const wrap = $('#modal-colors'); wrap.innerHTML = '';
  COLORS.forEach((c, i) => {
    const b = document.createElement('button');
    b.style.background = c; b.style.color = c;
    if (i === modalColorIdx) b.classList.add('selected');
    b.addEventListener('click', () => { modalColorIdx = i; renderModalColors(); });
    wrap.appendChild(b);
  });
}
function renderModalIcons() {
  const wrap = $('#modal-icons'); wrap.innerHTML = '';
  ICON_KEYS.forEach((key) => {
    const b = document.createElement('button');
    b.innerHTML = ICONS[key];
    if (key === modalIconKey) b.classList.add('selected');
    b.addEventListener('click', () => { modalIconKey = key; renderModalIcons(); });
    wrap.appendChild(b);
  });
}
function renderModalCreds() {
  const wrap = $('#modal-creds-list');
  if (!modalCreds.length) {
    wrap.innerHTML = `<div class="creds-empty">${t('credsEmpty')}</div>`;
    return;
  }
  wrap.innerHTML = '';
  modalCreds.forEach((c, idx) => {
    const row = document.createElement('div');
    row.className = 'cred-entry';
    row.innerHTML = `
      <input class="cred-site" type="text" placeholder="exemplo.com" value="${escapeHtml(c.site)}" style="grid-column:1 / -1" />
      <div class="cred-pass-wrap">
        <input class="cred-login" type="text" placeholder="${t('credsLoginPh')}" value="${escapeHtml(c.login)}" />
      </div>
      <div class="cred-pass-wrap">
        <input class="cred-senha" type="password" placeholder="${t('credsPassPh')}" value="${escapeHtml(c.senha)}" />
        <button type="button" class="cred-toggle" title="${t('credsShow')}">
          <svg viewBox="0 0 24 24"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
        </button>
      </div>
      <label class="cred-auto-row" title="${t('credsAutoTitle')}">
        <span>${t('credsAuto')}</span>
        <label class="switch"><input type="checkbox" class="cred-autofill" ${c.autoFill !== false ? 'checked' : ''}><span class="switch-track"></span></label>
      </label>
      <button type="button" class="cred-del" title="${t('credsDel')}">
        <svg viewBox="0 0 24 24"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
      </button>
    `;
    const readEntry = () => {
      c.site = row.querySelector('.cred-site').value.trim();
      c.login = row.querySelector('.cred-login').value.trim();
      c.senha = row.querySelector('.cred-senha').value;
      c.autoFill = row.querySelector('.cred-autofill').checked;
      c.selectors = c.selectors || { login: '', senha: '' };
    };
    row.querySelector('.cred-toggle').addEventListener('click', () => {
      const inp = row.querySelector('.cred-senha');
      inp.type = inp.type === 'password' ? 'text' : 'password';
    });
    row.querySelector('.cred-del').addEventListener('click', () => { modalCreds.splice(idx, 1); renderModalCreds(); });
    ['cred-site', 'cred-login', 'cred-senha'].forEach((cls) => {
      row.querySelector('.' + cls).addEventListener('input', readEntry);
    });
    row.querySelector('.cred-autofill').addEventListener('change', readEntry);
    wrap.appendChild(row);
  });
}
$('#modal-creds-add').addEventListener('click', () => { modalCreds.push({ site: '', login: '', senha: '', autoFill: true, selectors: { login: '', senha: '' } }); renderModalCreds(); });
$('#modal-cancel').addEventListener('click', () => overlay.classList.add('hidden'));
$('#modal-confirm').addEventListener('click', async () => {
  const name = $('#modal-name').value.trim();
  const url = $('#modal-url').value.trim();
  overlay.classList.add('hidden');
  if (modalMode === 'edit' && modalTargetId != null) {
    editAccount(modalTargetId, name, url, { colorIdx: modalColorIdx, iconKey: modalIconKey });
    persistAccountCredentials(modalTargetId, modalCreds);
  } else {
    const wsId = Number($('#modal-workspace').value);
    const openNow = $('#modal-open').checked;
    const acc = createAccount(name, url, openNow, { workspaceId: wsId, colorIdx: modalColorIdx, iconKey: modalIconKey });
    if (acc && modalCreds.length) persistAccountCredentials(acc.id, modalCreds);
  }
});
overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.classList.add('hidden'); });
$('#add-account-btn').addEventListener('click', () => openAccountModal('create'));
$('#empty-add-account-btn').addEventListener('click', () => openAccountModal('create'));
$('#add-workspace-btn').addEventListener('click', () => createWorkspace());
// ---------------------------------------------------------------------------
// Credenciais de autopreenchimento — login/senha por conta, criptografadas no
// arquivo credentials.json (safeStorage). Chamadas de autofill são rejeitadas
// silenciosamente (o site bloqueia ou não acha o campo), então nada quebra.
// ---------------------------------------------------------------------------
let credentials = {}; // accountId -> [{ site, login, senha, autoFill, selectors }]
async function persistAccountCredentials(accountId, list) {
  const clean = (list || [])
    .map((c) => ({
      site: String(c.site || '').trim(),
      login: String(c.login || '').trim(),
      senha: String(c.senha || ''),
      autoFill: c.autoFill !== false,
      selectors: { login: String((c.selectors && c.selectors.login) || ''), senha: String((c.selectors && c.selectors.senha) || '') },
    }))
    .filter((c) => c.site || c.login || c.senha);
  if (!clean.length) {
    delete credentials[accountId];
    try { await window.nativeAPI.deleteCredentials(accountId); } catch (err) { /* ignore */ }
    return;
  }
  credentials[accountId] = clean;
  try { await window.nativeAPI.saveCredentials({ accountId, list: clean }); } catch (err) { console.error('Falha ao salvar credenciais', err); }
}
async function loadCredentials() {
  try { credentials = await window.nativeAPI.loadCredentials(); } catch (err) { console.error('Falha ao carregar credenciais', err); }
  if (!credentials || typeof credentials !== 'object') credentials = {};
}
// ---------------------------------------------------------------------------
// Autofill: script injetado na página de cada conta. Detecta campos de
// login/senha por heurística (ou seletores customizados por site) e usa
// o setter nativo + eventos input/change.
const AUTOFILL_INJECT = `(function(){
  if (window.__idleHubFillReady) return;
  window.__idleHubFillReady = true;
  function nativeSet(el, value) {
    var proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    try { Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value); }
    catch (err) { el.value = value; }
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.focus();
    el.blur();
  }
  function query(selector) {
    if (!selector) return null;
    try { return document.querySelector(selector); } catch (err) { return null; }
  }
  function siteMatches(host, site) {
    if (!site) return false;
    var s = String(site).toLowerCase().trim();
    var p = s.indexOf('://');
    if (p !== -1) s = s.slice(p + 3);
    var q = s.indexOf('/');
    if (q !== -1) s = s.slice(0, q);
    var c = s.indexOf(':');
    if (c !== -1) s = s.slice(0, c);
    if (s.indexOf('www.') === 0) s = s.slice(4);
    var h = String(host || '').toLowerCase().trim();
    if (h.indexOf('www.') === 0) h = h.slice(4);
    return s !== '' && (h === s || h.endsWith('.' + s) || s.endsWith('.' + h));
  }
  function pickLogin(force) {
    var inputs = Array.prototype.slice.call(document.querySelectorAll('input:not([type]), input[type=text], input[type=email], input[type=tel], input[type=password]'));
    var scored = [];
    inputs.forEach(function (el) {
      var n = ((el.name || '') + ' ' + (el.id || '') + ' ' + (el.placeholder || '')).toLowerCase();
      var a = (el.autocomplete || '').toLowerCase();
      var s = 0;
      if (el.type === 'password') s += 0;
      if (a === 'username' || a === 'email' || a === 'user-name') s += 5;
      if (a.indexOf('user') !== -1 || a === 'login') s += 3;
      if (n.indexOf('user') !== -1 || n.indexOf('login') !== -1 || n.indexOf('mail') !== -1 || n.indexOf('email') !== -1) s += 2;
      if (el.type !== 'password' && el.type !== 'email' && el.type !== 'tel') s += 1;
      if (s > 0 && (force || el.value === '')) scored.push({ el: el, s: s });
    });
    if (!scored.length) return null;
    scored.sort(function (a, b) { return b.s - a.s; });
    for (var i = 0; i < scored.length; i++) {
      if (scored[i].el.type !== 'password') return scored[i].el;
    }
    return scored[0].el;
  }
  window.__idleHubFill = function (list, force) {
    var host = location.hostname;
    var entry = null;
    for (var i = 0; i < list.length; i++) {
      if (siteMatches(host, list[i].site)) { entry = list[i]; break; }
    }
    if (!entry || !entry.login) return false;
    if (!force && entry.autoFill === false) return false;
    var loginSel = entry.selectors && entry.selectors.login;
    var passSel = entry.selectors && entry.selectors.senha;
    var loginEl = query(loginSel) || pickLogin(force);
    var passEl = query(passSel) || document.querySelector('input[type=password]');
    if (!loginEl || !passEl) return false;
    var done = false;
    if (entry.login && (force || loginEl.value === '')) { nativeSet(loginEl, entry.login); done = true; }
    if (entry.senha && (force || passEl.value === '')) { nativeSet(passEl, entry.senha); done = true; }
    return done;
  };
  window.__idleHubAutoFill = function (list) {
    if (window.__idleHubFill(list, false)) return true;
    var tried = 0;
    var timer = setInterval(function () {
      tried++;
      if (window.__idleHubFill(list, false) || tried >= 6) clearInterval(timer);
    }, 400);
    return false;
  };
})();`;
function autofillAccount(accountId, force) {
  const list = credentials[accountId];
  if (!list || !list.length) return;
  const webview = grid.querySelector(`.account-card[data-id="${accountId}"] webview`);
  if (!webview) return;
  const call = force ? 'window.__idleHubFill(%s, true)' : 'window.__idleHubAutoFill(%s)';
  webview.executeJavaScript(AUTOFILL_INJECT + '; ' + call.replace('%s', JSON.stringify(list)) + ';').catch(() => { /* site bloqueia ou não tem o campo — segue o jogo */ });
}
// ---------------------------------------------------------------------------
// Titlebar custom
// ---------------------------------------------------------------------------
$('#btn-min').addEventListener('click', () => window.nativeAPI.minimize());
$('#btn-max').addEventListener('click', () => window.nativeAPI.maximize());
$('#btn-close').addEventListener('click', () => window.nativeAPI.close());
// ---------------------------------------------------------------------------
// DOAÇÃO — edite tudo aqui: textos, imagem e o código Pix (somente o
// códigoPix precisa ser trocado; a imagem pix-qrcode.png é a mesma).
// Se preencher urlExterna, o botão Doar abre o link em vez do modal.
// ---------------------------------------------------------------------------
const DONATE_CONFIG = {
  titulo: '☕ Apoie o Midgard Idle Hub',
  subtitulo: 'Se o launcher te ajudou, um cafezinho via Pix é muito bem-vindo!',
  imagem: 'pix-qrcode.png',
  codigoPix: '00020126580014BR.GOV.BCB.PIX0136c18ee687-2a17-48c1-9497-878dd35cbb0d5204000053039865802BR5925Jafre de Santana Belantan6009SAO PAULO62140510tSjUXn7FY46304EB58***63046A77',
  textoFechar: 'Fechar',
  textoCopiar: 'Copiar código Pix',
  textoCopiado: 'Código Pix copiado!',
  textoFallbackImagem: 'QR Code indisponível — use o código Pix abaixo',
  urlExterna: '', // ex: 'https://github.com/sponsors/' (modal é usado se vazio)
};
const donateOverlay = $('#donate-overlay');
function openDonateModal() {
  if (DONATE_CONFIG.urlExterna) { window.nativeAPI.openExternal(DONATE_CONFIG.urlExterna); return; }
  $('#donate-title').textContent = DONATE_CONFIG.titulo;
  $('#donate-sub').textContent = DONATE_CONFIG.subtitulo;
  const qr = $('#donate-qr');
  qr.src = DONATE_CONFIG.imagem;
  qr.style.display = '';
  $('#donate-qr-fallback').style.display = 'none';
  $('#donate-qr-fallback-text').textContent = DONATE_CONFIG.textoFallbackImagem;
  $('#donate-pix').textContent = DONATE_CONFIG.codigoPix;
  $('#donate-close2').textContent = DONATE_CONFIG.textoFechar;
  $('#donate-copy').textContent = DONATE_CONFIG.textoCopiar;
  donateOverlay.classList.remove('hidden');
}
function closeDonateModal() {
  donateOverlay.classList.add('hidden');
  const copyBtn = $('#donate-copy');
  copyBtn.textContent = DONATE_CONFIG.textoCopiar;
}
function copyPixCode() {
  const code = DONATE_CONFIG.codigoPix;
  const done = () => {
    const btn = $('#donate-copy');
    btn.textContent = DONATE_CONFIG.textoCopiado;
    setTimeout(() => { btn.textContent = DONATE_CONFIG.textoCopiar; }, 2000);
  };
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(code).then(done).catch(() => legacyCopyPix(code, done));
  } else legacyCopyPix(code, done);
}
function legacyCopyPix(code, done) {
  const ta = document.createElement('textarea');
  ta.value = code;
  ta.style.position = 'fixed';
  ta.style.opacity = '0';
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand('copy'); done(); } catch (err) { /* ignore */ }
  ta.remove();
}
$('#donate-btn').addEventListener('click', openDonateModal);
$('#donate-close').addEventListener('click', closeDonateModal);
$('#donate-close2').addEventListener('click', closeDonateModal);
$('#donate-copy').addEventListener('click', copyPixCode);
donateOverlay.addEventListener('click', (e) => { if (e.target === donateOverlay) closeDonateModal(); });
// ---------------------------------------------------------------------------
// Barra de status
// ---------------------------------------------------------------------------
function layoutLabel(layout) {
  const map = { auto: 'layoutAuto', single: 'layoutSingle', columns: 'layoutColumns', rows: 'layoutRows', free: 'layoutFree' };
  if (layout === 'custom') return 'Grade personalizada';
  return t(map[layout] || 'layoutAuto');
}
function updateStatusBar() {
  const ws = getActiveWorkspace();
  const openCount = ws ? ws.accounts.filter((a) => a.status === 'open').length : 0;
  $('#status-workspace').innerHTML = `${ws ? escapeHtml(ws.name) : ''} · ${layoutLabel(ws ? ws.layout : 'auto')} · <span id="status-count">${openCount}</span>`;
  const acc = getActiveAccount();
  $('#status-active').textContent = acc ? t('activeAccountSuffix', { name: acc.name }) : t('noActiveAccount');
}
// ---------------------------------------------------------------------------
// Estatísticas reais de CPU / RAM
// ---------------------------------------------------------------------------
async function refreshStats() {
  try {
    const metrics = await window.nativeAPI.getProcessStats();
    const byPid = new Map(metrics.map((m) => [m.pid, m]));
    let totalCpu = 0, totalMem = 0;
    const ws = getActiveWorkspace();
    const allOpenAccounts = state.workspaces.flatMap((w) => w.accounts.filter((a) => a.status === 'open'));
    for (const acc of allOpenAccounts) {
      if (acc.webContentsId != null && acc.pid == null) acc.pid = await window.nativeAPI.getPidForWebContents(acc.webContentsId);
      const m = acc.pid != null ? byPid.get(acc.pid) : null;
      if (ws && ws.accounts.includes(acc)) {
        const el = document.querySelector(`[data-stats="${acc.id}"]`);
        if (el) el.textContent = `CPU ${m ? m.cpu.toFixed(1) + '%' : '—'}  RAM ${m ? m.memoryMB + ' MB' : '—'}`;
      }
      if (m) { totalCpu += m.cpu; totalMem += m.memoryMB; }
    }
    $('#status-cpu').textContent = `CPU ${totalCpu.toFixed(1)}%`;
    $('#status-ram').textContent = `RAM ${totalMem} MB`;
  } catch (err) { console.error('Erro ao obter estatísticas', err); }
}
setInterval(refreshStats, 2000);
// ---------------------------------------------------------------------------
// Zeny/h — lê o "Saldo potencial/h" que o próprio jogo já mostra em cada
// conta (via <dt>/<dd>) e soma de todas as contas abertas, em qualquer
// workspace. Procura pelo TEXTO do rótulo, não pelas classes do Tailwind
// (essas mudam fácil entre builds do jogo; o texto do rótulo é mais estável).
// ---------------------------------------------------------------------------
const EXTRACT_ZENY_INJECT = `(function(){
  var dts = document.querySelectorAll('dt');
  for (var i = 0; i < dts.length; i++) {
    var label = (dts[i].textContent || '').trim().toLowerCase();
    if (label.indexOf('saldo potencial') !== -1) {
      var dd = dts[i].parentElement ? dts[i].parentElement.querySelector('dd') : null;
      if (!dd) return null;
      var raw = (dd.textContent || '').trim();
      var cleaned = raw.replace(/[^0-9.,-]/g, '');
      var intPart = cleaned.split(',')[0].replace(/\\./g, ''); // "." = milhar, vírgula = decimal (formato BR)
      var num = parseInt(intPart, 10);
      return isNaN(num) ? null : num;
    }
  }
  return null;
})();`;
function formatZeny(n) { return Math.round(n).toLocaleString('pt-BR'); }
function ensureZenyStatusEl() {
  let el = $('#status-zeny');
  if (el) return el;
  const cpuEl = $('#status-cpu');
  if (!cpuEl || !cpuEl.parentElement) return null;
  el = document.createElement('span');
  el.id = 'status-zeny';
  el.style.marginLeft = '12px';
  cpuEl.parentElement.insertBefore(el, cpuEl);
  return el;
}
async function refreshZenyRates() {
  const allOpen = state.workspaces.flatMap((w) => w.accounts.filter((a) => a.status === 'open'));
  let total = 0, found = 0;
  for (const acc of allOpen) {
    const card = grid.querySelector(`.account-card[data-id="${acc.id}"]`);
    const isVisible = !!card && card.style.display !== 'none';
    // Conta oculta (outro workspace, ou coberta no layout "Painel único"):
    // não gasta executeJavaScript nela — mesmo princípio do throttle de rAF.
    // Usa o último valor já lido pra continuar contando na soma total.
    if (isVisible) {
      const webview = card.querySelector('webview');
      if (webview) {
        try {
          const val = await webview.executeJavaScript(EXTRACT_ZENY_INJECT);
          if (typeof val === 'number' && !isNaN(val)) acc.zenyRate = val;
        } catch (err) {
          // conta pode estar numa tela sem esse elemento (login, splash, etc) — ignora nesse ciclo
        }
      }
    }
    if (typeof acc.zenyRate === 'number') { total += acc.zenyRate; found++; }
  }
  const el = ensureZenyStatusEl();
  if (el) el.textContent = found > 0 ? `${formatZeny(total)} Zeny/h (${found} conta${found > 1 ? 's' : ''})` : '';
}
setInterval(refreshZenyRates, 5000);
// ---------------------------------------------------------------------------
// Botão de pânico: limpa o cache HTTP e recarrega TODAS as contas abertas
// (de todos os workspaces), ignorando cache — pra usar quando o jogo
// atualiza e o cache antigo trava a tela. NÃO mexe em cookies, login nem
// nas credenciais salvas no Idle Hub — só força buscar os arquivos
// (JS/CSS/imagens) de novo, a conta continua logada depois.
// ---------------------------------------------------------------------------
function ensurePanicButton() {
  let btn = $('#panic-btn');
  if (btn) return btn;
  const toolbar = $('#toolbar');
  const anchor = $('#topbar-mute');
  if (!toolbar || !anchor) return null;
  btn = document.createElement('button');
  btn.id = 'panic-btn';
  btn.className = 'btn-icon';
  btn.title = 'Botão de pânico: limpa cache e recarrega todas as contas (use após atualização do jogo)';
  btn.innerHTML = '<svg viewBox="0 0 24 24"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0Z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>';
  btn.addEventListener('click', triggerPanicReload);
  toolbar.insertBefore(btn, anchor);
  return btn;
}
async function triggerPanicReload() {
  const allOpen = state.workspaces.flatMap((w) => w.accounts.filter((a) => a.status === 'open'));
  if (!allOpen.length) return;
  showConfirm(
    'Botão de pânico',
    `Isso vai limpar o cache e recarregar TODAS as ${allOpen.length} conta(s) aberta(s), de todos os workspaces. Login e credenciais salvas continuam intactos — só busca a versão mais nova do jogo de novo. Continuar?`,
    async () => {
      for (const acc of allOpen) {
        try { await window.nativeAPI.clearCache(acc.partition); }
        catch (err) { console.error(`Erro ao limpar cache da conta ${acc.name}:`, err); }
        const webview = grid.querySelector(`.account-card[data-id="${acc.id}"] webview`);
        if (webview) {
          try { webview.reloadIgnoringCache(); }
          catch (err) { console.error(`Erro ao recarregar a conta ${acc.name}:`, err); }
        }
      }
    }
  );
}
ensurePanicButton();
// ---------------------------------------------------------------------------
// Proxy opcional (a "VPN" das contas). Botão na barra de ferramentas + popover
// com liga/desliga, tipo/host/porta, predefinições (WARP/Tor) e teste de IP.
// A lógica de rede fica no main.js (session.setProxy nas partições das contas).
// Tudo é montado por aqui (CSS incluso), sem precisar editar o index.html nem
// rodar o build do Tailwind.
// ---------------------------------------------------------------------------
Object.assign(I18N.pt, {
  proxyTitle: 'Proxy / VPN das contas', proxyUse: 'Usar proxy nas contas', proxyPreset: 'Predefinição',
  proxyPresetCustom: 'Personalizado', proxyType: 'Tipo', proxyHost: 'Host', proxyPort: 'Porta',
  proxyApply: 'Aplicar', proxyTest: 'Testar IP', proxyStateOn: 'Ativo', proxyStateOff: 'Desligado',
  proxyHint: 'O serviço (WARP, Tor...) precisa estar rodando no seu PC. Só as contas passam pelo proxy; o app e as atualizações continuam em conexão direta.',
  proxyConfirmTitle: 'Alterar o proxy?',
  proxyConfirmBody: 'As conexões atuais serão fechadas e as contas abertas serão recarregadas para usar a nova rota.',
  proxyApplied: 'Proxy aplicado.', proxyOffApplied: 'Proxy desligado — conexão direta.',
  proxyTestNeedOn: 'Ligue e aplique o proxy antes de testar.', proxyTesting: 'Testando...',
  proxyTestOk: 'IP pelo proxy: {proxy} · IP direto: {direct}',
  proxyTestSame: 'O IP pelo proxy ({proxy}) é igual ao direto. Confira se o serviço está rodando e se host/porta estão certos.',
  proxyTestFail: 'Falha ao testar: {error}',
});
Object.assign(I18N.en, {
  proxyTitle: 'Accounts proxy / VPN', proxyUse: 'Use proxy for accounts', proxyPreset: 'Preset',
  proxyPresetCustom: 'Custom', proxyType: 'Type', proxyHost: 'Host', proxyPort: 'Port',
  proxyApply: 'Apply', proxyTest: 'Test IP', proxyStateOn: 'On', proxyStateOff: 'Off',
  proxyHint: 'The service (WARP, Tor...) must be running on your PC. Only accounts go through the proxy; the app itself and updates stay on a direct connection.',
  proxyConfirmTitle: 'Change the proxy?',
  proxyConfirmBody: 'Current connections will be closed and open accounts will be reloaded to use the new route.',
  proxyApplied: 'Proxy applied.', proxyOffApplied: 'Proxy off — direct connection.',
  proxyTestNeedOn: 'Turn on and apply the proxy before testing.', proxyTesting: 'Testing...',
  proxyTestOk: 'IP via proxy: {proxy} · Direct IP: {direct}',
  proxyTestSame: 'The IP via proxy ({proxy}) is the same as the direct one. Check that the service is running and host/port are correct.',
  proxyTestFail: 'Test failed: {error}',
});
Object.assign(I18N.es, {
  proxyTitle: 'Proxy / VPN de las cuentas', proxyUse: 'Usar proxy en las cuentas', proxyPreset: 'Preajuste',
  proxyPresetCustom: 'Personalizado', proxyType: 'Tipo', proxyHost: 'Host', proxyPort: 'Puerto',
  proxyApply: 'Aplicar', proxyTest: 'Probar IP', proxyStateOn: 'Activo', proxyStateOff: 'Apagado',
  proxyHint: 'El servicio (WARP, Tor...) debe estar ejecutándose en tu PC. Solo las cuentas pasan por el proxy; la app y las actualizaciones siguen en conexión directa.',
  proxyConfirmTitle: '¿Cambiar el proxy?',
  proxyConfirmBody: 'Se cerrarán las conexiones actuales y las cuentas abiertas se recargarán para usar la nueva ruta.',
  proxyApplied: 'Proxy aplicado.', proxyOffApplied: 'Proxy apagado — conexión directa.',
  proxyTestNeedOn: 'Activa y aplica el proxy antes de probar.', proxyTesting: 'Probando...',
  proxyTestOk: 'IP por el proxy: {proxy} · IP directa: {direct}',
  proxyTestSame: 'La IP por el proxy ({proxy}) es igual a la directa. Revisa que el servicio esté en ejecución y que host/puerto sean correctos.',
  proxyTestFail: 'Error al probar: {error}',
});
const PROXY_PRESETS = [
  { id: 'warp', label: 'Cloudflare WARP (modo proxy)', scheme: 'socks5', host: '127.0.0.1', port: 40000 },
  { id: 'tor', label: 'Tor (serviço)', scheme: 'socks5', host: '127.0.0.1', port: 9050 },
  { id: 'torbrowser', label: 'Tor Browser', scheme: 'socks5', host: '127.0.0.1', port: 9150 },
];
const PROXY_SCHEMES_UI = ['socks5', 'http', 'https', 'socks4'];
let proxyState = { enabled: false, scheme: 'socks5', host: '127.0.0.1', port: 40000 };
function matchProxyPreset(c) {
  const p = PROXY_PRESETS.find((x) => x.scheme === c.scheme && x.host === c.host && x.port === Number(c.port));
  return p ? p.id : 'custom';
}
function injectProxyStyles() {
  if ($('#proxy-style')) return;
  const st = document.createElement('style');
  st.id = 'proxy-style';
  st.textContent = `
    #proxy-wrap { position: relative; }
    #proxy-btn .proxy-dot { position: absolute; top: 5px; right: 5px; width: 7px; height: 7px; border-radius: 50%; background: #34d399; display: none; }
    #proxy-btn.active-state .proxy-dot { display: block; }
    #proxy-popover { position: absolute; top: 40px; right: 0; width: 310px; background: #0c131d; border: 1px solid #223247; border-radius: 12px; padding: 14px; z-index: 60; box-shadow: 0 8px 24px rgba(0,0,0,.5); color: #fff; font-size: 12px; }
    #proxy-popover.hidden { display: none; }
    #proxy-popover .proxy-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; }
    #proxy-popover .proxy-head b { font-size: 11px; font-weight: 700; letter-spacing: .06em; color: #9fa9b9; text-transform: uppercase; }
    #proxy-popover .proxy-badge { font-size: 10px; font-weight: 700; padding: 2px 8px; border-radius: 999px; background: #111b28; color: #9fa9b9; }
    #proxy-popover .proxy-badge.on { background: rgba(52,211,153,.15); color: #34d399; }
    #proxy-popover .proxy-switch { display: flex; align-items: center; gap: 8px; margin-bottom: 12px; font-size: 13px; cursor: pointer; }
    #proxy-popover .proxy-switch input { width: 16px; height: 16px; accent-color: #c89b3c; }
    #proxy-popover .proxy-field { display: flex; flex-direction: column; gap: 4px; margin-bottom: 8px; min-width: 0; }
    #proxy-popover .proxy-field label { color: #9fa9b9; font-size: 11px; }
    #proxy-popover .proxy-field input, #proxy-popover .proxy-field select { height: 30px; width: 100%; background: #111b28; border: 1px solid #223247; border-radius: 8px; color: #fff; padding: 0 8px; font-size: 12px; }
    #proxy-popover .proxy-row { display: flex; gap: 8px; }
    #proxy-popover .proxy-row .proxy-field { flex: 1; }
    #proxy-popover .proxy-row .proxy-field.scheme { flex: 0 0 84px; }
    #proxy-popover .proxy-row .proxy-field.port { flex: 0 0 68px; }
    #proxy-popover .proxy-actions { display: flex; gap: 8px; margin-top: 12px; }
    #proxy-popover .proxy-actions button { flex: 1; padding: 8px; border-radius: 8px; border: 1px solid #c89b3c; background: transparent; color: #c89b3c; font-size: 12px; }
    #proxy-popover .proxy-actions button:hover { background: #223247; }
    #proxy-popover .proxy-actions button.primary { background: #c89b3c; color: #05070b; font-weight: 700; }
    #proxy-popover .proxy-actions button.primary:hover { background: #e3b341; }
    #proxy-popover .proxy-actions button:disabled { opacity: .4; cursor: default; }
    #proxy-popover .proxy-msg { margin-top: 10px; font-size: 11px; line-height: 1.5; color: #9fa9b9; }
    #proxy-popover .proxy-msg.ok { color: #34d399; }
    #proxy-popover .proxy-msg.err { color: #d94c4c; }
    #proxy-popover .proxy-msg.warn { color: #e3b341; }
    #proxy-popover .proxy-hint { margin-top: 10px; padding-top: 10px; border-top: 1px solid #1a2129; font-size: 11px; line-height: 1.5; color: #9fa9b9; }
  `;
  document.head.appendChild(st);
}
function proxyPopoverHtml() {
  const c = proxyState;
  const presetId = matchProxyPreset(c);
  const presetOpts = PROXY_PRESETS.map((p) => `<option value="${p.id}"${presetId === p.id ? ' selected' : ''}>${p.label}</option>`).join('')
    + `<option value="custom"${presetId === 'custom' ? ' selected' : ''}>${t('proxyPresetCustom')}</option>`;
  const schemeOpts = PROXY_SCHEMES_UI.map((s) => `<option value="${s}"${c.scheme === s ? ' selected' : ''}>${s.toUpperCase()}</option>`).join('');
  return `
    <div class="proxy-head"><b>${t('proxyTitle')}</b><span class="proxy-badge${c.enabled ? ' on' : ''}">${t(c.enabled ? 'proxyStateOn' : 'proxyStateOff')}</span></div>
    <label class="proxy-switch"><input type="checkbox" id="proxy-enabled"${c.enabled ? ' checked' : ''}> ${t('proxyUse')}</label>
    <div class="proxy-field"><label for="proxy-preset">${t('proxyPreset')}</label><select id="proxy-preset">${presetOpts}</select></div>
    <div class="proxy-row">
      <div class="proxy-field scheme"><label for="proxy-scheme">${t('proxyType')}</label><select id="proxy-scheme">${schemeOpts}</select></div>
      <div class="proxy-field"><label for="proxy-host">${t('proxyHost')}</label><input id="proxy-host" type="text" spellcheck="false" value="${escapeHtml(c.host)}"></div>
      <div class="proxy-field port"><label for="proxy-port">${t('proxyPort')}</label><input id="proxy-port" type="text" inputmode="numeric" value="${Number(c.port)}"></div>
    </div>
    <div class="proxy-actions">
      <button type="button" id="proxy-test">${t('proxyTest')}</button>
      <button type="button" id="proxy-apply" class="primary">${t('proxyApply')}</button>
    </div>
    <div class="proxy-msg" id="proxy-msg"></div>
    <div class="proxy-hint">${t('proxyHint')}</div>
  `;
}
function setProxyMsg(text, kind) {
  const el = $('#proxy-msg');
  if (!el) return;
  el.textContent = text || '';
  el.className = 'proxy-msg' + (kind ? ' ' + kind : '');
}
function updateProxyButton() {
  const btn = $('#proxy-btn');
  if (!btn) return;
  btn.classList.toggle('active-state', !!proxyState.enabled);
  btn.title = proxyState.enabled
    ? `${t('proxyTitle')}: ${proxyState.scheme}://${proxyState.host}:${proxyState.port}`
    : `${t('proxyTitle')}: ${t('proxyStateOff')}`;
}
async function refreshProxyState() {
  try {
    const cfg = await window.nativeAPI.getProxyConfig();
    if (cfg) proxyState = cfg;
  } catch (err) { console.error('Erro ao ler configuração de proxy:', err); }
  updateProxyButton();
}
function readProxyForm() {
  return {
    enabled: !!($('#proxy-enabled') && $('#proxy-enabled').checked),
    scheme: $('#proxy-scheme').value,
    host: $('#proxy-host').value.trim(),
    port: parseInt($('#proxy-port').value, 10),
  };
}
async function submitProxy(cfg) {
  setProxyMsg('', '');
  try {
    const res = await window.nativeAPI.setProxyConfig(cfg);
    if (!res || !res.ok) { setProxyMsg((res && res.error) || 'Erro', 'err'); return; }
    proxyState = res.config;
    updateProxyButton();
    const pop = $('#proxy-popover');
    if (pop && !pop.classList.contains('hidden')) {
      pop.innerHTML = proxyPopoverHtml();
      setProxyMsg(t(res.config.enabled ? 'proxyApplied' : 'proxyOffApplied'), 'ok');
    }
  } catch (err) { setProxyMsg(String(err), 'err'); }
}
function applyProxyFromForm() {
  const cfg = readProxyForm();
  const prev = proxyState;
  const routeChanged = cfg.enabled !== !!prev.enabled
    || (cfg.enabled && (cfg.scheme !== prev.scheme || cfg.host !== prev.host || cfg.port !== Number(prev.port)));
  const hasOpen = state.workspaces.some((w) => w.accounts.some((a) => a.status === 'open'));
  if (routeChanged && hasOpen) showConfirm(t('proxyConfirmTitle'), t('proxyConfirmBody'), () => submitProxy(cfg));
  else submitProxy(cfg);
}
async function runProxyTest() {
  if (!proxyState.enabled) { setProxyMsg(t('proxyTestNeedOn'), 'warn'); return; }
  const btn = $('#proxy-test');
  if (btn) btn.disabled = true;
  setProxyMsg(t('proxyTesting'), '');
  try {
    const r = await window.nativeAPI.testProxy();
    if (!r || !r.ok) setProxyMsg(t('proxyTestFail', { error: (r && r.error) || '?' }), 'err');
    else if (r.differs) setProxyMsg(t('proxyTestOk', { proxy: r.proxyIp, direct: r.directIp || '—' }), 'ok');
    else setProxyMsg(t('proxyTestSame', { proxy: r.proxyIp }), 'warn');
  } catch (err) {
    setProxyMsg(t('proxyTestFail', { error: String(err) }), 'err');
  } finally {
    const b = $('#proxy-test'); if (b) b.disabled = false;
  }
}
// As contas (webviews) precisam reconectar quando a rota muda: as conexões
// abertas — WebSocket dos jogos inclusive — foram fechadas pelo main.js.
function reloadAllWebviewsForProxy() {
  document.querySelectorAll('.account-card webview').forEach((wv) => {
    try { wv.reload(); } catch (err) { /* webview ainda não terminou de iniciar */ }
  });
}
function ensureProxyUi() {
  if ($('#proxy-btn')) return;
  const toolbar = $('#toolbar');
  const anchor = $('#panic-btn') || $('#topbar-mute');
  if (!toolbar || !anchor || !window.nativeAPI.getProxyConfig) return;
  injectProxyStyles();
  const wrap = document.createElement('div');
  wrap.id = 'proxy-wrap';
  wrap.innerHTML = `
    <button id="proxy-btn" class="btn-icon" type="button">
      <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
      <span class="proxy-dot"></span>
    </button>
    <div id="proxy-popover" class="hidden"></div>`;
  toolbar.insertBefore(wrap, anchor);
  const pop = $('#proxy-popover');
  const closePop = () => pop.classList.add('hidden');
  $('#proxy-btn').addEventListener('click', async (e) => {
    e.stopPropagation();
    if (!pop.classList.contains('hidden')) { closePop(); return; }
    await refreshProxyState();
    pop.innerHTML = proxyPopoverHtml();
    pop.classList.remove('hidden');
  });
  pop.addEventListener('click', (e) => {
    e.stopPropagation();
    if (e.target.id === 'proxy-apply') applyProxyFromForm();
    else if (e.target.id === 'proxy-test') runProxyTest();
  });
  pop.addEventListener('change', (e) => {
    if (e.target.id === 'proxy-preset') {
      const p = PROXY_PRESETS.find((x) => x.id === e.target.value);
      if (!p) return;
      $('#proxy-scheme').value = p.scheme; $('#proxy-host').value = p.host; $('#proxy-port').value = p.port;
    } else if (['proxy-scheme', 'proxy-host', 'proxy-port'].includes(e.target.id)) {
      $('#proxy-preset').value = matchProxyPreset({ scheme: $('#proxy-scheme').value, host: $('#proxy-host').value.trim(), port: parseInt($('#proxy-port').value, 10) });
    }
  });
  document.addEventListener('click', (e) => { if (!wrap.contains(e.target)) closePop(); });
  window.addEventListener('blur', closePop); // clicar dentro de uma webview tira o foco desta janela
  window.nativeAPI.onProxyEvent((data) => {
    if (!data) return;
    if (data.config) {
      proxyState = data.config;
      updateProxyButton();
      if (!pop.classList.contains('hidden')) pop.innerHTML = proxyPopoverHtml();
    }
    if (data.routeChanged) reloadAllWebviewsForProxy();
  });
  refreshProxyState();
}
ensureProxyUi();
// Atualiza só o texto do cronômetro "Online · Xm Ys" a cada segundo, sem
// recriar a lista inteira da sidebar (evita descartar nós/listeners à toa).
function updateUptimeTimers() {
  document.querySelectorAll('.account-item:not(.closed)').forEach((item) => {
    const acc = getAccountById(Number(item.dataset.id));
    if (!acc || acc.status !== 'open') return;
    const row2 = item.querySelector('.row2');
    if (row2) row2.textContent = `${t('statusOnline')} · ${formatUptime(acc.createdAt)}`;
  });
}
setInterval(updateUptimeTimers, 1000);
setInterval(() => { if (isDirty) persistState(); }, 15000);
window.addEventListener('beforeunload', () => { persistState(); });
// ---------------------------------------------------------------------------
// Atalhos de teclado globais
// ---------------------------------------------------------------------------
// (Os atalhos de teclado agora são tratados pelo sistema data-driven definido
// mais acima, junto com o editor de atalhos do modal de Ajuda — ver ACTION_DEFS.)
// ---------------------------------------------------------------------------
// Modal: Configurações
// ---------------------------------------------------------------------------
const settingsOverlay = $('#settings-overlay');
function switchSettingsTab(tab) {
  document.querySelectorAll('.settings-tab').forEach((b) => b.classList.toggle('active', b.dataset.tab === tab));
  document.querySelectorAll('.settings-panel').forEach((p) => p.classList.toggle('active', p.dataset.panel === tab));
}
document.querySelectorAll('.settings-tab').forEach((b) => b.addEventListener('click', () => switchSettingsTab(b.dataset.tab)));
async function openSettingsModal() {
  const s = state.settings;
  $('#update-result-box').classList.add('hidden');
  $('#set-idioma').value = s.idioma;
  $('#set-tema').value = s.tema;
  $('#set-login-item').checked = !!s.iniciarComSistema;
  $('#set-reopen-last').checked = s.reabrirUltimoWorkspace !== false;
  $('#set-clean-mode').checked = !!s.modoTelaLimpa;
  $('#set-edge-reveal').checked = s.encostarBordas !== false;
  $('#set-presentation-mode').checked = !!s.modoApresentacao;
  $('#set-eco-mode').checked = !!s.modoEco;
  $('#set-url-padrao').value = s.urlInicialPadrao || DEFAULT_URL;
  $('#set-zoom').value = String(s.zoomPadrao || 1);
  $('#set-layout-padrao').value = s.layoutPadrao || 'auto';
  $('#set-downloads-path').textContent = s.downloadsPath || t('downloadsFolderDefault');
  $('#set-ask-download').checked = s.perguntarOndeSalvar !== false;
  switchSettingsTab('geral');
  settingsOverlay.classList.remove('hidden');
  try {
    const v = await window.nativeAPI.getVersions();
    $('#about-version').textContent = v.app;
    $('#about-electron').textContent = v.electron;
    $('#about-chrome').textContent = v.chrome;
  } catch (err) { /* ignore */ }
}
$('#settings-close').addEventListener('click', () => settingsOverlay.classList.add('hidden'));
settingsOverlay.addEventListener('click', (e) => { if (e.target === settingsOverlay) settingsOverlay.classList.add('hidden'); });
$('#set-idioma').addEventListener('change', (e) => { state.settings.idioma = e.target.value; applyLanguage(e.target.value); schedulePersist(); });
$('#set-tema').addEventListener('change', (e) => { state.settings.tema = e.target.value; applyTheme(e.target.value); schedulePersist(); });
$('#set-login-item').addEventListener('change', async (e) => {
  state.settings.iniciarComSistema = e.target.checked;
  schedulePersist();
  try { await window.nativeAPI.setLoginItem(e.target.checked); } catch (err) { console.error(err); }
});
$('#set-reopen-last').addEventListener('change', (e) => { state.settings.reabrirUltimoWorkspace = e.target.checked; schedulePersist(); });
$('#set-clean-mode').addEventListener('change', (e) => { state.settings.modoTelaLimpa = e.target.checked; applyCleanMode(); schedulePersist(); });
$('#set-edge-reveal').addEventListener('change', (e) => { state.settings.encostarBordas = e.target.checked; applyCleanMode(); schedulePersist(); });
$('#set-presentation-mode').addEventListener('change', (e) => { state.settings.modoApresentacao = e.target.checked; applyPresentationMode(); schedulePersist(); });
$('#set-eco-mode').addEventListener('change', (e) => { state.settings.modoEco = e.target.checked; applyEcoMode(); schedulePersist(); });
$('#set-url-padrao').addEventListener('change', (e) => { state.settings.urlInicialPadrao = normalizeUrl(e.target.value.trim() || DEFAULT_URL); schedulePersist(); });
$('#set-zoom').addEventListener('change', (e) => { state.settings.zoomPadrao = parseFloat(e.target.value); schedulePersist(); });
$('#set-layout-padrao').addEventListener('change', (e) => { state.settings.layoutPadrao = e.target.value; schedulePersist(); });
$('#set-choose-folder').addEventListener('click', async () => {
  try {
    const folder = await window.nativeAPI.chooseDownloadsFolder();
    if (folder) { state.settings.downloadsPath = folder; $('#set-downloads-path').textContent = folder; schedulePersist(); }
  } catch (err) { console.error(err); }
});
$('#set-ask-download').addEventListener('change', (e) => { state.settings.perguntarOndeSalvar = e.target.checked; schedulePersist(); });
$('#set-export').addEventListener('click', async () => {
  try { const result = await window.nativeAPI.exportState(serializeState()); if (result && result.ok) alert(t('backupSaved', { path: result.path })); }
  catch (err) { console.error(err); }
});
$('#set-import').addEventListener('click', async () => {
  try {
    const data = await window.nativeAPI.importState();
    if (!data || !data.workspaces) return;
    showConfirm(t('confirmImportTitle'), t('confirmImportBody'), () => {
      state = data;
      if (!state.settings) state.settings = defaultSettings();
      activeAccountId = null;
      if (!state.activeWorkspaceId && state.workspaces.length) state.activeWorkspaceId = state.workspaces[0].id;
      applyLanguage(state.settings.idioma); applyTheme(state.settings.tema); applyCleanMode();
      renderWorkspaceRail(); renderSidebar(); renderGrid(); updateStatusBar(); schedulePersist();
      settingsOverlay.classList.add('hidden');
    });
  } catch (err) { console.error(err); }
});
// ---------------------------------------------------------------------------
// Verificação de atualização via Gist (JSON simples com "version"/"url"/
// "message"). Sem download/instalação automática — só compara e avisa.
// A URL do Gist é fixa em UPDATE_GIST_URL (topo do arquivo), não aparece
// em lugar nenhum da interface.
// ---------------------------------------------------------------------------
function renderUpdateResult(html, stateClass) {
  const box = $('#update-result-box');
  box.classList.remove('hidden');
  box.className = `update-result ${stateClass}`;
  box.innerHTML = html;
  const openBtn = box.querySelector('.update-open-link');
  if (openBtn) openBtn.addEventListener('click', () => window.nativeAPI.openExternal(openBtn.dataset.url));
}
function updateErrorMessage(error) {
  if (error === 'invalid-url') return t('updateInvalidUrl');
  return t('updateCheckFailed');
}
$('#set-check-updates').addEventListener('click', async () => {
  const btn = $('#set-check-updates');
  const gistUrl = UPDATE_GIST_URL;
  if (!gistUrl) { renderUpdateResult(`<div class="update-result-row">${escapeHtml(t('updateInvalidUrl'))}</div>`, 'state-error'); return; }
  btn.disabled = true;
  renderUpdateResult(`<div class="update-result-row"><svg viewBox="0 0 24 24"><path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/></svg> ${escapeHtml(t('checkingUpdates'))}</div>`, 'state-checking');
  try {
    const result = await window.nativeAPI.checkForUpdates(gistUrl);
    if (!result.ok) {
      renderUpdateResult(`<div class="update-result-row">${escapeHtml(updateErrorMessage(result.error))}</div>`, 'state-error');
    } else if (result.upToDate) {
      renderUpdateResult(`<div class="update-result-row"><svg viewBox="0 0 24 24"><path d="M20 6 9 17l-5-5"/></svg> ${escapeHtml(t('updatesUpToDate'))}</div>`, 'state-ok');
    } else {
      const msg = result.message ? `${result.message} ` : '';
      let html = `<div class="update-result-row">${escapeHtml(msg + t('updateAvailableBody', { version: result.remoteVersion }))}</div>`;
      if (result.updateUrl) html += `<button class="ghost-btn update-open-link" type="button" data-url="${escapeHtml(result.updateUrl)}">${escapeHtml(t('updateToastOpen'))}</button>`;
      renderUpdateResult(html, 'state-update');
    }
  } catch (err) {
    console.error(err);
    renderUpdateResult(`<div class="update-result-row">${escapeHtml(t('updateCheckFailed'))}</div>`, 'state-error');
  } finally {
    btn.disabled = false;
  }
});
// Verificação silenciosa ao abrir o app — só mostra o toast se houver
// atualização de verdade; erros/link não configurado ficam em silêncio.
let updateToastTimer = null;
function showUpdateToast(remoteVersion, updateUrl, message) {
  const toast = $('#update-toast');
  $('#update-toast-text').textContent = message || t('updateToastBody', { version: remoteVersion });
  const openBtn = $('#update-toast-open');
  if (updateUrl) {
    openBtn.classList.remove('hidden');
    openBtn.onclick = () => window.nativeAPI.openExternal(updateUrl);
  } else {
    openBtn.classList.add('hidden');
  }
  toast.classList.remove('hidden', 'closing');
  clearTimeout(updateToastTimer);
  updateToastTimer = setTimeout(closeUpdateToast, 60000); // 1 minuto
}
function closeUpdateToast() {
  const toast = $('#update-toast');
  if (toast.classList.contains('hidden')) return;
  clearTimeout(updateToastTimer);
  toast.classList.add('closing');
  setTimeout(() => toast.classList.add('hidden'), 200);
}
$('#update-toast-close').addEventListener('click', closeUpdateToast);
function checkForUpdatesOnStartup() {
  const gistUrl = UPDATE_GIST_URL;
  if (!gistUrl) return;
  window.nativeAPI.checkForUpdates(gistUrl).then((result) => {
    if (result.ok && !result.upToDate) {
      showUpdateToast(result.remoteVersion, result.updateUrl, result.message);
    }
  }).catch(() => { /* silencioso — não incomoda o usuário com erro de rede ao abrir o app */ });
}

// ---------------------------------------------------------------------------
// Auto-update de verdade (electron-updater), só funciona no app empacotado
// (.exe instalado) — quem roda direto do código-fonte não recebe esses
// eventos do main.js, então esse banner simplesmente nunca aparece pra eles.
// Fica separado do toast do Gist acima porque precisa ficar na tela durante
// todo o download e não pode sumir sozinho (a pessoa decide quando reiniciar).
// ---------------------------------------------------------------------------
function ensureAutoUpdateBanner() {
  let banner = $('#autoupdate-banner');
  if (banner) return banner;
  banner = document.createElement('div');
  banner.id = 'autoupdate-banner';
  banner.style.cssText = 'position:fixed; left:50%; transform:translateX(-50%); bottom:16px; background:#12151c; border:1px solid #2a2f3a; border-radius:10px; padding:10px 16px; display:none; align-items:center; gap:12px; z-index:99999; color:#e5e7eb; font-size:13px; box-shadow:0 8px 24px rgba(0,0,0,.45);';
  banner.innerHTML = `<span id="autoupdate-banner-text"></span><button id="autoupdate-banner-btn" class="btn-icon" style="width:auto; padding:4px 12px; display:none; background:#e3b341; color:#05070b; font-weight:600;"></button>`;
  document.body.appendChild(banner);
  return banner;
}
function showAutoUpdateBanner(text, buttonText, onClick) {
  const banner = ensureAutoUpdateBanner();
  banner.style.display = 'flex';
  banner.querySelector('#autoupdate-banner-text').textContent = text;
  const btn = banner.querySelector('#autoupdate-banner-btn');
  if (buttonText) {
    btn.textContent = buttonText;
    btn.style.display = '';
    btn.onclick = onClick;
  } else {
    btn.style.display = 'none';
  }
}
if (!STANDALONE_ACCOUNT && window.nativeAPI.onAutoUpdateEvent) {
  window.nativeAPI.onAutoUpdateEvent((data) => {
    if (!data) return;
    switch (data.status) {
      case 'available':
        showAutoUpdateBanner(`Atualização v${data.version} encontrada — baixando em segundo plano...`);
        break;
      case 'downloading':
        showAutoUpdateBanner(`Baixando atualização... ${data.percent}%`);
        break;
      case 'downloaded':
        showAutoUpdateBanner(`Atualização v${data.version} pronta pra instalar!`, 'Reiniciar agora', () => window.nativeAPI.installAppUpdate());
        break;
      case 'error':
        console.error('Erro no auto-update:', data.message);
        break;
      // 'checking' e 'not-available' ficam em silêncio — não precisa incomodar o usuário
    }
  });
}
// ---------------------------------------------------------------------------
// Scripts / Extras — userscripts estilo Tampermonkey, com alvo por workspace/conta
// ---------------------------------------------------------------------------
function scriptAppliesToAccount(script, workspaceId, accountId) {
  if (!script.enabled) return false;
  if (!script.scopeWorkspaceId) return true; // aplica em todos os workspaces e contas
  if (script.scopeWorkspaceId !== workspaceId) return false;
  if (!script.scopeAccountIds || !script.scopeAccountIds.length) return true; // todo o workspace
  return script.scopeAccountIds.includes(accountId);
}
function scopeSummary(script) {
  if (!script.scopeWorkspaceId) return 'Todos os workspaces e contas';
  const ws = state.workspaces.find((w) => w.id === script.scopeWorkspaceId);
  const wsName = ws ? ws.name : '?';
  if (!script.scopeAccountIds || !script.scopeAccountIds.length) return `${wsName} · todas as contas`;
  return `${wsName} · ${script.scopeAccountIds.length} conta(s)`;
}
function injectScriptIntoOpenMatches(script) {
  document.querySelectorAll('.account-card').forEach((card) => {
    const accId = Number(card.dataset.id);
    const acc = getAccountById(accId);
    if (!acc) return;
    const ws = state.workspaces.find((w) => w.accounts.some((a) => a.id === accId));
    if (!ws || !scriptAppliesToAccount(script, ws.id, accId)) return;
    const webview = card.querySelector('webview');
    if (webview) webview.executeJavaScript(script.code).catch((err) => console.error(`Erro no script "${script.name}":`, err));
  });
}
let editingScriptId = null;
function populateScriptTargetWorkspaces() {
  const sel = $('#script-target-ws');
  const current = sel.value;
  sel.innerHTML = '<option value="">Todos os workspaces e contas</option>' +
    state.workspaces.map((w) => `<option value="${w.id}">${escapeHtml(w.name)}</option>`).join('');
  sel.value = current && state.workspaces.some((w) => String(w.id) === current) ? current : '';
}
function renderScriptTargetAccounts() {
  const wsId = Number($('#script-target-ws').value) || null;
  const wrap = $('#script-target-accounts-wrap');
  const list = $('#script-target-accounts');
  if (!wsId) { wrap.style.display = 'none'; list.innerHTML = ''; return; }
  const ws = state.workspaces.find((w) => w.id === wsId);
  wrap.style.display = '';
  if (!ws || !ws.accounts.length) { list.innerHTML = '<span class="settings-subtext">Este workspace não tem contas.</span>'; return; }
  list.innerHTML = ws.accounts.map((a) => `
    <label><input type="checkbox" value="${a.id}"> ${escapeHtml(a.name)}</label>
  `).join('');
}
$('#script-target-ws').addEventListener('change', renderScriptTargetAccounts);
function renderScriptsList() {
  const wrap = $('#scripts-list');
  if (!state.scripts.length) { wrap.innerHTML = '<span class="settings-subtext">Nenhum script adicionado ainda.</span>'; return; }
  wrap.innerHTML = '';
  state.scripts.forEach((script) => {
    const row = document.createElement('div');
    row.className = 'script-row';
    row.innerHTML = `
      <input type="checkbox" ${script.enabled ? 'checked' : ''} title="Ativar/desativar" />
      <div class="script-info">
        <div class="script-name">${escapeHtml(script.name)}</div>
        <div class="script-scope">${escapeHtml(scopeSummary(script))}</div>
      </div>
      <button class="script-edit" title="Editar">
        <svg viewBox="0 0 24 24"><path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/></svg>
      </button>
      <button class="script-delete" title="Excluir">
        <svg viewBox="0 0 24 24"><path d="M4 6h16"/><path d="M6 6V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v2m2 0-1 14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2L4 6"/></svg>
      </button>
    `;
    row.querySelector('input[type="checkbox"]').addEventListener('change', (e) => {
      script.enabled = e.target.checked;
      schedulePersist();
      if (script.enabled) injectScriptIntoOpenMatches(script);
    });
    row.querySelector('.script-edit').addEventListener('click', () => startEditScript(script.id));
    row.querySelector('.script-delete').addEventListener('click', () => {
      showConfirm('Excluir este script?', `O script "${script.name}" será removido permanentemente.`, () => {
        state.scripts = state.scripts.filter((s) => s.id !== script.id);
        renderScriptsList(); schedulePersist();
      });
    });
    wrap.appendChild(row);
  });
}
function resetScriptForm() {
  editingScriptId = null;
  $('#scripts-form-title').textContent = 'Adicionar script';
  $('#script-save-btn').textContent = '+ Adicionar script';
  $('#script-cancel-edit').classList.add('hidden');
  $('#script-name').value = '';
  $('#script-code').value = '';
  $('#script-target-ws').value = '';
  renderScriptTargetAccounts();
}
function startEditScript(id) {
  const script = state.scripts.find((s) => s.id === id);
  if (!script) return;
  editingScriptId = id;
  $('#scripts-form-title').textContent = 'Editar script';
  $('#script-save-btn').textContent = 'Salvar alterações';
  $('#script-cancel-edit').classList.remove('hidden');
  $('#script-name').value = script.name;
  $('#script-code').value = script.code;
  $('#script-target-ws').value = script.scopeWorkspaceId || '';
  renderScriptTargetAccounts();
  if (script.scopeAccountIds && script.scopeAccountIds.length) {
    document.querySelectorAll('#script-target-accounts input[type="checkbox"]').forEach((cb) => {
      cb.checked = script.scopeAccountIds.includes(Number(cb.value));
    });
  }
  $('#script-name').scrollIntoView({ block: 'nearest' });
}
$('#script-cancel-edit').addEventListener('click', resetScriptForm);
$('#script-save-btn').addEventListener('click', () => {
  const name = $('#script-name').value.trim();
  const code = $('#script-code').value;
  if (!name || !code.trim()) return;
  const scopeWorkspaceId = Number($('#script-target-ws').value) || null;
  const checkedAccounts = Array.from(document.querySelectorAll('#script-target-accounts input[type="checkbox"]:checked')).map((cb) => Number(cb.value));
  if (editingScriptId != null) {
    const script = state.scripts.find((s) => s.id === editingScriptId);
    if (script) {
      script.name = name; script.code = code; script.scopeWorkspaceId = scopeWorkspaceId;
      script.scopeAccountIds = checkedAccounts.length ? checkedAccounts : null;
      if (script.enabled) injectScriptIntoOpenMatches(script);
    }
  } else {
    const script = {
      id: Date.now(), name, code, enabled: true,
      scopeWorkspaceId, scopeAccountIds: checkedAccounts.length ? checkedAccounts : null,
    };
    state.scripts.push(script);
    injectScriptIntoOpenMatches(script);
  }
  resetScriptForm();
  renderScriptsList();
  schedulePersist();
});
function openScriptsModal() {
  populateScriptTargetWorkspaces();
  resetScriptForm();
  renderScriptsList();
  $('#scripts-overlay').classList.remove('hidden');
}
$('#open-scripts-btn').addEventListener('click', openScriptsModal);
$('#scripts-close').addEventListener('click', () => $('#scripts-overlay').classList.add('hidden'));
$('#scripts-overlay').addEventListener('click', (e) => { if (e.target === $('#scripts-overlay')) $('#scripts-overlay').classList.add('hidden'); });
// ---------------------------------------------------------------------------
// Tooltip customizado — substitui o balão nativo do sistema (lento e feio)
// por um bem mais rápido de aparecer e no estilo visual do app. Qualquer
// elemento com atributo data-tooltip="texto" ganha o tooltip automaticamente.
// ---------------------------------------------------------------------------
const TOOLTIP_DELAY_MS = 150;
let tooltipEl = null;
let tooltipTimer = null;
let currentTooltipTarget = null;
function positionTooltip(target) {
  const rect = target.getBoundingClientRect();
  const tRect = tooltipEl.getBoundingClientRect();
  let left = rect.left + rect.width / 2 - tRect.width / 2;
  left = Math.max(6, Math.min(left, window.innerWidth - tRect.width - 6));
  let top = rect.bottom + 8;
  if (top + tRect.height > window.innerHeight - 6) top = rect.top - tRect.height - 8;
  tooltipEl.style.left = `${left}px`;
  tooltipEl.style.top = `${top}px`;
}
function showTooltip(target) {
  const text = target.dataset.tooltip;
  if (!text) return;
  tooltipEl.textContent = text;
  tooltipEl.classList.remove('hidden');
  positionTooltip(target);
  requestAnimationFrame(() => tooltipEl.classList.add('visible'));
}
function hideTooltip() {
  if (!tooltipEl) return;
  tooltipEl.classList.remove('visible');
  currentTooltipTarget = null;
  clearTimeout(tooltipTimer);
}
function initTooltipSystem() {
  tooltipEl = $('#app-tooltip');
  document.addEventListener('mouseover', (e) => {
    const target = e.target.closest('[data-tooltip]');
    if (!target || target === currentTooltipTarget) return;
    currentTooltipTarget = target;
    clearTimeout(tooltipTimer);
    tooltipTimer = setTimeout(() => showTooltip(target), TOOLTIP_DELAY_MS);
  });
  document.addEventListener('mouseout', (e) => {
    const target = e.target.closest('[data-tooltip]');
    if (!target || target !== currentTooltipTarget) return;
    if (e.relatedTarget && target.contains(e.relatedTarget)) return;
    hideTooltip();
  });
  document.addEventListener('mousedown', hideTooltip);
  document.addEventListener('wheel', hideTooltip, { passive: true });
  window.addEventListener('blur', hideTooltip);
}
initTooltipSystem();
// ---------------------------------------------------------------------------
// Seletor Rápido de Contas (1-12) na Barra Superior
// ---------------------------------------------------------------------------
function renderQuickAccounts() {
  const bar = $('#quick-accounts-bar');
  if (!bar) return;
  bar.innerHTML = '';    
  const ws = getActiveWorkspace();
  if (!ws || !ws.accounts.length) return;
  ws.accounts.slice(0, 12).forEach((acc, index) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'quick-acc-btn' + (acc.id === activeAccountId ? ' active' : '') + (acc.status === 'closed' ? ' closed' : '');
    btn.textContent = index + 1;
    btn.dataset.tooltip = `${acc.name} (${acc.status === 'open' ? 'Online' : 'Fechada'})`;      
    btn.addEventListener('click', () => {
      if (acc.status === 'closed') {
        openAccount(acc.id);
      } else {
        setActiveAccount(acc.id);
      }
    });      
    bar.appendChild(btn);
  });
}
// ---------------------------------------------------------------------------
// Start
// ---------------------------------------------------------------------------
window.addEventListener('resize', () => {
  const ws = getActiveWorkspace();
  if (ws && ws.layout === 'auto') {
    const { cols, rows } = computeAutoGrid(getOpenAccountsOfActiveWorkspace().length);
    if (cols > 1 || rows > 1) layoutAutoGridGutters(ws, cols, rows);
  }
});
init();
