
const { app, BrowserWindow, ipcMain, webContents, session, Menu, dialog, shell, safeStorage } = require('electron');
const { autoUpdater } = require('electron-updater');
const path = require('path');
const fs = require('fs');
const https = require('https');
let mainWindow;

// ---------------------------------------------------------------------------
// Perfil isolado (opcional). Por padrão o app usa a pasta de dados normal
// (state, contas, cache, proxy.json etc.), igual sempre foi. Só quando você
// pede explicitamente um perfil — pela variável de ambiente IDLEHUB_PROFILE
// ou por --profile=nome na linha de comando — ele passa a gravar tudo numa
// subpasta separada. Assim dá para rodar esta versão (com proxy) ao mesmo
// tempo que a instalação que já está aberta, sem uma mexer nos dados da
// outra: cada uma com suas próprias contas, sessões/cookies e configuração
// de proxy. Precisa rodar ANTES de app.getPath('userData') ser usado por
// qualquer outra coisa, por isso fica logo no topo do arquivo.
// ---------------------------------------------------------------------------
// Para fixar o perfil direto no código (sem precisar de variável de ambiente
// nem de --profile= toda vez que abrir o app), preencha o nome aqui. Deixe
// '' (vazio) para manter o comportamento por variável de ambiente/argumento.
const FIXED_PROFILE = 'proxy-teste';

function resolveProfileName() {
  if (FIXED_PROFILE) return FIXED_PROFILE.trim().replace(/[^a-zA-Z0-9_-]/g, '') || null;
  const fromEnv = process.env.IDLEHUB_PROFILE;
  const fromArg = process.argv.find((a) => a.startsWith('--profile='));
  const raw = fromArg ? fromArg.slice('--profile='.length) : fromEnv;
  if (!raw) return null;
  const clean = raw.trim().replace(/[^a-zA-Z0-9_-]/g, '');
  return clean || null;
}
const PROFILE_NAME = resolveProfileName();
if (PROFILE_NAME) {
  const base = app.getPath('userData'); // pasta padrão, ex: .../Midgard Idle-Hub
  app.setPath('userData', path.join(base, 'profiles', PROFILE_NAME));
  app.setName(`${app.getName()} (${PROFILE_NAME})`); // some no título/taskbar/tray, se houver
}

const STATE_FILE = () => path.join(app.getPath('userData'), 'state.json');
const registeredPartitions = new Set();

// ---------------------------------------------------------------------------
// Proxy opcional (a "VPN" do Idle Hub). Em vez de uma VPN de sistema (que exige
// admin/driver e muda a rede do PC inteiro), roteamos SÓ o tráfego das contas
// (as sessões/partições das <webview>) por um proxy SOCKS5/HTTP — ligado ou
// desligado em tempo real, sem reiniciar o app. A janela principal (default
// session) e o auto-update continuam sempre em conexão direta.
// A config fica em proxy.json (arquivo próprio: o state.json é reescrito
// inteiro pelo renderer a cada save-state e apagaria isso).
// ---------------------------------------------------------------------------
const PROXY_FILE = () => path.join(app.getPath('userData'), 'proxy.json');
const PROXY_SCHEMES = ['socks5', 'socks4', 'http', 'https'];
const DEFAULT_PROXY = { enabled: false, scheme: 'socks5', host: '127.0.0.1', port: 40000 };
let proxyConfig = { ...DEFAULT_PROXY };
const proxiedSessions = new Set();

// Valida a config vinda da UI. Ligado + dados inválidos = erro; desligado +
// dados inválidos = só desliga e mantém o host/porta anteriores.
function parseProxyConfig(input, fallback) {
  const src = input && typeof input === 'object' ? input : {};
  const base = fallback || DEFAULT_PROXY;
  const enabled = !!src.enabled;
  const scheme = String(src.scheme != null ? src.scheme : base.scheme).toLowerCase();
  const host = String(src.host != null ? src.host : base.host).trim();
  const port = Number.parseInt(src.port != null ? src.port : base.port, 10);
  const valid =
    PROXY_SCHEMES.includes(scheme) &&
    /^[A-Za-z0-9.-]+$/.test(host) &&
    Number.isInteger(port) && port >= 1 && port <= 65535;
  if (valid) return { ok: true, cfg: { enabled, scheme, host, port } };
  if (!enabled) return { ok: true, cfg: { ...base, enabled: false } };
  return { ok: false, error: 'Proxy inválido: confira o tipo, o host e a porta (1-65535).' };
}
function loadProxyConfig() {
  try {
    if (!fs.existsSync(PROXY_FILE())) return;
    const r = parseProxyConfig(JSON.parse(fs.readFileSync(PROXY_FILE(), 'utf-8')));
    if (r.ok) proxyConfig = r.cfg;
  } catch (err) {
    console.error('Falha ao carregar proxy.json:', err);
  }
}
function saveProxyConfig() {
  try {
    fs.writeFileSync(PROXY_FILE(), JSON.stringify(proxyConfig, null, 2), 'utf-8');
  } catch (err) {
    console.error('Falha ao salvar proxy.json:', err);
  }
}
function electronProxyConfig() {
  if (!proxyConfig.enabled) return { mode: 'system' }; // comportamento original do Electron
  return {
    mode: 'fixed_servers',
    proxyRules: `${proxyConfig.scheme}://${proxyConfig.host}:${proxyConfig.port}`,
    proxyBypassRules: '<local>', // localhost/rede local não passam pelo proxy
  };
}
async function applyProxyToSession(ses, { closeConnections = false } = {}) {
  try {
    await ses.setProxy(electronProxyConfig());
    // Conexões keep-alive/WebSocket já abertas seguiriam pelo caminho antigo
    if (closeConnections) await ses.closeAllConnections();
  } catch (err) {
    console.error('Falha ao aplicar proxy na sessão:', err);
  }
}
// Registra uma sessão de conta e já aplica o proxy atual nela
function trackSession(ses) {
  if (!ses || ses === session.defaultSession || proxiedSessions.has(ses)) return;
  proxiedSessions.add(ses);
  applyProxyToSession(ses);
}
// WebRTC pode vazar o IP real via STUN/UDP, ignorando o proxy. Com o proxy
// ligado, só permite UDP que passe pelo proxy.
function applyWebRtcPolicy(wc) {
  try {
    if (wc.getType() === 'webview') {
      wc.setWebRTCIPHandlingPolicy(proxyConfig.enabled ? 'disable_non_proxied_udp' : 'default');
    }
  } catch (err) { /* ignore */ }
}
ipcMain.handle('proxy-get', () => proxyConfig);
ipcMain.handle('proxy-set', async (event, input) => {
  const r = parseProxyConfig(input, proxyConfig);
  if (!r.ok) return { ok: false, error: r.error };
  const routeBefore = JSON.stringify(electronProxyConfig());
  proxyConfig = r.cfg;
  saveProxyConfig();
  const routeChanged = routeBefore !== JSON.stringify(electronProxyConfig());
  for (const partition of registeredPartitions) trackSession(session.fromPartition(partition));
  // Só derruba as conexões abertas (WebSocket etc.) se o caminho realmente mudou
  for (const ses of proxiedSessions) await applyProxyToSession(ses, { closeConnections: routeChanged });
  for (const wc of webContents.getAllWebContents()) applyWebRtcPolicy(wc);
  // Avisa TODAS as janelas (principal + janelas avulsas): elas compartilham as
  // mesmas partições, então todas precisam atualizar o botão e recarregar.
  for (const win of BrowserWindow.getAllWindows()) {
    if (!win.isDestroyed()) win.webContents.send('proxy-event', { config: proxyConfig, routeChanged });
  }
  return { ok: true, config: proxyConfig, routeChanged };
});
// Botão "Testar": consulta o IP público por dentro do proxy e diretamente,
// para você ver se realmente mudou. (Só faz a requisição quando você clica.)
ipcMain.handle('proxy-test', async () => {
  const lookup = async (ses) => {
    const res = await ses.fetch('https://api.ipify.org?format=json', { signal: AbortSignal.timeout(10000) });
    const json = await res.json();
    return json && json.ip ? String(json.ip) : null;
  };
  try {
    const testSession = session.fromPartition('proxy-test');
    trackSession(testSession);
    await applyProxyToSession(testSession, { closeConnections: true });
    const [viaProxy, direct] = await Promise.allSettled([lookup(testSession), lookup(session.defaultSession)]);
    const proxyIp = viaProxy.status === 'fulfilled' ? viaProxy.value : null;
    const directIp = direct.status === 'fulfilled' ? direct.value : null;
    return {
      ok: proxyIp != null,
      enabled: proxyConfig.enabled,
      proxyIp,
      directIp,
      differs: proxyIp != null && directIp != null && proxyIp !== directIp,
      error: proxyIp == null ? String((viaProxy.reason && viaProxy.reason.message) || viaProxy.reason || 'falha') : undefined,
    };
  } catch (err) {
    return { ok: false, error: String(err) };
  }
});

// ---------------------------------------------------------------------------
// Auto-update via electron-updater, lendo as Releases do GitHub do próprio
// repositório (configurado em package.json > build > publish). Só funciona
// no app empacotado (.exe instalado) — em modo dev (`npm start`) não tem o
// que checar, então tudo aqui é protegido por app.isPackaged.
// ---------------------------------------------------------------------------
autoUpdater.autoDownload = true; // baixa sozinho assim que encontra uma versão nova
autoUpdater.autoInstallOnAppQuit = false; // só instala quando a pessoa clicar em "Reiniciar agora"

function sendUpdateEvent(payload) {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('autoupdate-event', payload);
}
autoUpdater.on('checking-for-update', () => sendUpdateEvent({ status: 'checking' }));
autoUpdater.on('update-available', (info) => sendUpdateEvent({ status: 'available', version: info.version }));
autoUpdater.on('update-not-available', () => sendUpdateEvent({ status: 'not-available' }));
autoUpdater.on('download-progress', (p) => sendUpdateEvent({ status: 'downloading', percent: Math.round(p.percent || 0) }));
autoUpdater.on('update-downloaded', (info) => sendUpdateEvent({ status: 'downloaded', version: info.version }));
autoUpdater.on('error', (err) => sendUpdateEvent({ status: 'error', message: String((err && err.message) || err) }));

ipcMain.handle('autoupdate-check', async () => {
  if (!app.isPackaged) return { ok: false, error: 'dev-mode' };
  try {
    await autoUpdater.checkForUpdates();
    return { ok: true };
  } catch (err) {
    console.error('Falha ao checar atualização (electron-updater):', err);
    return { ok: false, error: String(err) };
  }
});
ipcMain.on('autoupdate-install', () => {
  autoUpdater.quitAndInstall();
});

// Janelas independentes abertas via "Abrir em nova janela" (uma por conta).
// accountId -> BrowserWindow
const accountWindows = new Map();
function createWindow() {
  // Em desenvolvimento (npm start), usa build/icon.png se existir — sem quebrar
  // caso o arquivo ainda não tenha sido criado. No build final (.exe/.AppImage/.dmg)
  // quem define o ícone é a config "build" do package.json (electron-builder).
  const devIconPath = path.join(__dirname, 'build', 'icon.png');
  const devIcon = fs.existsSync(devIconPath) ? devIconPath : undefined;
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    backgroundColor: '#05070b',
    title: 'Idle Hub',
    icon: devIcon,
    frame: false, // usamos nossa própria titlebar em HTML — remove a barra nativa e o menu File/Edit/View...
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webviewTag: true,
      sandbox: false,
    },
  });
  mainWindow.loadFile('index.html');
}
// Impede que o Chromium reduza a frequência de temporizadores (setInterval/setTimeout) em segundo plano
app.commandLine.appendSwitch('disable-background-timer-throttling');
// Desativa a suspensão de processos de renderização quando a janela perde o foco ou é oculta
app.commandLine.appendSwitch('disable-renderer-backgrounding');
// Evita que janelas encobertas por outros aplicativos entrem em modo de economia de recursos
app.commandLine.appendSwitch('disable-backgrounding-occluded-windows');
app.whenReady().then(() => {
  Menu.setApplicationMenu(null); // remove qualquer resquício do menu padrão (File/Edit/View/Window/Help)
  loadProxyConfig();
  app.on('web-contents-created', (event, wc) => applyWebRtcPolicy(wc));
  createWindow();
  // Toda sessão de conta criada daqui pra frente já nasce com o proxy atual
  app.on('session-created', trackSession);
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
  if (app.isPackaged) {
    setTimeout(() => {
      autoUpdater.checkForUpdates().catch((err) => console.error('Falha ao checar atualização no início:', err));
    }, 3000);
  }
});
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
// ---------------------------------------------------------------------------
// Estatísticas reais de CPU/RAM
// ---------------------------------------------------------------------------
ipcMain.handle('get-process-stats', async () => {
  const metrics = app.getAppMetrics();
  return metrics.map((m) => ({
    pid: m.pid,
    type: m.type,
    cpu: m.cpu ? m.cpu.percentCPUUsage : 0,
    memoryMB: m.memory ? Math.round(m.memory.workingSetSize / 1024) : 0,
  }));
});
ipcMain.handle('get-pid-for-webcontents', (event, webContentsId) => {
  const wc = webContents.fromId(webContentsId);
  return wc ? wc.getOSProcessId() : null;
});
// ---------------------------------------------------------------------------
// Persistência (salvar/restaurar contas, workspaces e configurações)
// ---------------------------------------------------------------------------
ipcMain.handle('save-state', (event, data) => {
  try {
    fs.writeFileSync(STATE_FILE(), JSON.stringify(data, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error('Falha ao salvar estado:', err);
    return false;
  }
});
ipcMain.handle('load-state', () => {
  try {
    if (!fs.existsSync(STATE_FILE())) return null;
    return JSON.parse(fs.readFileSync(STATE_FILE(), 'utf-8'));
  } catch (err) {
    console.error('Falha ao carregar estado:', err);
    return null;
  }
});
// ---------------------------------------------------------------------------
// Credenciais de autopreenchimento (logins/senhas por conta) — criptografadas
// com safeStorage (chave por usuário/máquina no sistema), num arquivo próprio
// separado do state.json. Estrutura: { "<accountId>": [ { site, login, senha,
// autoFill, selectors } ] }. Senhas NUNCA vão para o state.json/backup.
// ---------------------------------------------------------------------------
const CREDENTIALS_FILE = () => path.join(app.getPath('userData'), 'credentials.json');
function readAllCredentials() {
  try {
    if (!fs.existsSync(CREDENTIALS_FILE())) return {};
    const buf = fs.readFileSync(CREDENTIALS_FILE());
    const json = safeStorage.decryptString(buf);
    return JSON.parse(json);
  } catch (err) {
    console.error('Falha ao ler credenciais:', err);
    return {};
  }
}
function writeAllCredentials(data) {
  try {
    if (!safeStorage.isEncryptionAvailable()) return false;
    const encrypted = safeStorage.encryptString(JSON.stringify(data || {}));
    fs.writeFileSync(CREDENTIALS_FILE(), encrypted);
    return true;
  } catch (err) {
    console.error('Falha ao salvar credenciais:', err);
    return false;
  }
}
ipcMain.handle('save-credentials', (event, data) => {
  const all = readAllCredentials();
  const accountId = String(data && data.accountId != null ? data.accountId : '');
  const list = Array.isArray(data && data.list) ? data.list : [];
  all[accountId] = list.map((c) => ({
    site: String(c.site || '').trim(),
    login: String(c.login || '').trim(),
    senha: String(c.senha || ''),
    autoFill: c.autoFill !== false,
    selectors: {
      login: String((c.selectors && c.selectors.login) || ''),
      senha: String((c.selectors && c.selectors.senha) || ''),
    },
  }));
  return { ok: writeAllCredentials(all) };
});
ipcMain.handle('delete-credentials', (event, accountId) => {
  const all = readAllCredentials();
  delete all[String(accountId)];
  return { ok: writeAllCredentials(all) };
});
ipcMain.handle('load-credentials', () => readAllCredentials());
// ---------------------------------------------------------------------------
// Limpar dados de sessão (cookies/localStorage/cache) de uma partição
// ---------------------------------------------------------------------------
ipcMain.handle('clear-partition', async (event, partition) => {
  try {
    await session.fromPartition(partition).clearStorageData();
    return true;
  } catch (err) {
    console.error('Falha ao limpar partição:', err);
    return false;
  }
});
// "Botão de pânico": limpa só o CACHE HTTP de uma partição (JS/CSS/imagens
// já baixados) — diferente do clear-partition acima, isso NÃO mexe em
// cookies, localStorage nem login. Usado quando o jogo atualiza e o cache
// antigo trava a tela; a conta continua logada depois.
ipcMain.handle('clear-cache', async (event, partition) => {
  try {
    await session.fromPartition(partition).clearCache();
    return true;
  } catch (err) {
    console.error('Falha ao limpar cache:', err);
    return false;
  }
});
// ---------------------------------------------------------------------------
// Configurações: versões, iniciar com o sistema, exportar/importar, downloads
// ---------------------------------------------------------------------------
ipcMain.handle('get-versions', () => ({
  app: app.getVersion(),
  electron: process.versions.electron,
  chrome: process.versions.chrome,
}));
ipcMain.handle('get-login-item', () => app.getLoginItemSettings().openAtLogin);
ipcMain.handle('set-login-item', (event, enabled) => {
  try {
    app.setLoginItemSettings({ openAtLogin: !!enabled });
    return true;
  } catch (err) {
    console.error('Falha ao configurar início automático:', err);
    return false;
  }
});
ipcMain.handle('choose-downloads-folder', async () => {
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openDirectory'] });
  if (result.canceled || !result.filePaths.length) return null;
  return result.filePaths[0];
});
ipcMain.handle('export-state', async (event, data) => {
  const result = await dialog.showSaveDialog(mainWindow, {
    defaultPath: 'multi-conta-manager-backup.json',
    filters: [{ name: 'JSON', extensions: ['json'] }],
  });
  if (result.canceled || !result.filePath) return { ok: false };
  try {
    fs.writeFileSync(result.filePath, JSON.stringify(data, null, 2), 'utf-8');
    return { ok: true, path: result.filePath };
  } catch (err) {
    console.error('Falha ao exportar:', err);
    return { ok: false };
  }
});
ipcMain.handle('import-state', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [{ name: 'JSON', extensions: ['json'] }],
  });
  if (result.canceled || !result.filePaths.length) return null;
  try {
    return JSON.parse(fs.readFileSync(result.filePaths[0], 'utf-8'));
  } catch (err) {
    console.error('Falha ao importar:', err);
    return null;
  }
});
// Downloads dentro das <webview>: cada conta usa sua própria partição/sessão,
// então registramos o listener de download nela assim que a conta é criada.
function handleDownload(event, item, webContents) {
  const downloadId = `dl-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const send = (payload) => { if (mainWindow) mainWindow.webContents.send('download-event', { id: downloadId, ...payload }); };
  send({ state: 'started', filename: item.getFilename(), url: item.getURL(), startTime: Date.now() });
  try {
    let settings = {};
    if (fs.existsSync(STATE_FILE())) {
      const raw = JSON.parse(fs.readFileSync(STATE_FILE(), 'utf-8'));
      settings = raw.settings || {};
    }
    const folder = settings.downloadsPath || app.getPath('downloads');
    if (settings.perguntarOndeSalvar !== false) {
      const chosen = dialog.showSaveDialogSync(mainWindow, { defaultPath: path.join(folder, item.getFilename()) });
      if (chosen) item.setSavePath(chosen);
      else { item.cancel(); send({ state: 'cancelled' }); return; }
    } else {
      item.setSavePath(path.join(folder, item.getFilename()));
    }
  } catch (err) {
    console.error('Erro ao tratar download:', err);
  }
  item.on('updated', (e, state) => {
    if (state === 'progressing') {
      send({ state: 'progressing', receivedBytes: item.getReceivedBytes(), totalBytes: item.getTotalBytes() });
    } else if (state === 'interrupted') {
      send({ state: 'interrupted' });
    }
  });
  item.once('done', (e, state) => {
    send({ state: state === 'completed' ? 'completed' : 'cancelled', savePath: item.getSavePath() });
  });
}
function ensurePartitionDownloads(partition) {
  if (!partition || registeredPartitions.has(partition)) return;
  registeredPartitions.add(partition);
  session.fromPartition(partition).on('will-download', handleDownload);
  trackSession(session.fromPartition(partition));
}
ipcMain.on('register-partition-downloads', (event, partition) => {
  ensurePartitionDownloads(partition);
});
// ---------------------------------------------------------------------------
// Abrir conta em uma janela própria (fora do grid) — carrega a MESMA UI do
// Idle Hub (index.html), só que em "modo standalone": um novo grid com essa
// única conta pré-carregada. A conta usa a MESMA partition/sessão do painel
// no grid principal — cookies/login continuam sincronizados, é a mesma conta
// sendo exibida em duas janelas, não uma cópia. Só uma janela por conta: se
// já existir, apenas foca em vez de abrir outra.
// ---------------------------------------------------------------------------
ipcMain.handle('open-account-window', (event, data) => {
  const accountId = data && data.accountId;
  const partition = String((data && data.partition) || '').trim();
  const url = String((data && data.url) || '').trim();
  if (!accountId || !partition || !/^https?:\/\//i.test(url)) {
    return { ok: false, error: 'invalid-args' };
  }
  const existing = accountWindows.get(accountId);
  if (existing && !existing.isDestroyed()) {
    if (existing.isMinimized()) existing.restore();
    existing.focus();
    return { ok: true, focused: true };
  }
  const win = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 640,
    minHeight: 420,
    backgroundColor: '#05070b',
    title: (data && data.title) ? String(data.title) : 'Idle Hub',
    frame: false, // mesma titlebar custom em HTML do index.html (não a nativa)
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webviewTag: true,
      sandbox: false,
    },
  });
  ensurePartitionDownloads(partition);
  win.on('closed', () => accountWindows.delete(accountId));
  accountWindows.set(accountId, win);
  win.loadFile('index.html', {
    query: {
      standalone: '1',
      account: JSON.stringify({
        id: accountId,
        name: (data && data.title) ? String(data.title) : 'Conta',
        url,
        partition,
        colorIdx: (data && data.colorIdx) || 0,
        iconKey: (data && data.iconKey) || 'apps',
        muted: !!(data && data.muted),
        zoomFactor: (data && data.zoomFactor) || 1,
      }),
    },
  });
  return { ok: true, focused: false };
});
// Fecha a janela própria de uma conta, se existir (usado ao fechar/excluir a
// conta ou limpar seus dados a partir do painel principal).
ipcMain.handle('close-account-window', (event, accountId) => {
  const win = accountWindows.get(accountId);
  if (win && !win.isDestroyed()) win.close();
  return true;
});
// ---------------------------------------------------------------------------
// Kit-Ticket: gera um pacote de suporte (log do console + estado do
// personagem, ambos extraídos direto do HTML/console da própria página —
// sem screenshot, já que todos os dados relevantes já vêm do front-end) para
// anexar em tickets — ajuda a staff quando o usuário abre um chamado
// incompleto. Fica numa pasta FIXA dentro dos dados do app (Kit-Ticket) —
// usamos app.getPath('userData') em vez de montar o caminho na mão, então
// não importa se o app está rodando como "idle-hub" ou "Midgard Idle-Hub".
// ---------------------------------------------------------------------------
const REPORT_FOLDER = () => path.join(app.getPath('userData'), 'Kit-Ticket');
function ensureReportFolder() {
  const folder = REPORT_FOLDER();
  if (!fs.existsSync(folder)) fs.mkdirSync(folder, { recursive: true });
  return folder;
}
ipcMain.handle('generate-report', async (event, data) => {
  try {
    const { logName, logContent, stateName, stateContent } = data || {};
    const folder = ensureReportFolder();
    const logPath = path.join(folder, logName || `report-log-${Date.now()}.txt`);
    fs.writeFileSync(logPath, logContent || '(nenhuma mensagem de console foi registrada nesta sessão)', 'utf-8');
    let statePath = null;
    if (stateName) {
      statePath = path.join(folder, stateName);
      fs.writeFileSync(statePath, stateContent || '(não foi possível extrair o estado do personagem nesta sessão)', 'utf-8');
    }
    // Abre a pasta no explorador de arquivos do sistema (Explorer/Finder/etc.)
    shell.openPath(folder);
    return { ok: true, folder, logPath, statePath };
  } catch (err) {
    console.error('Falha ao gerar report (Kit-Ticket):', err);
    return { ok: false, error: String(err) };
  }
});
// ---------------------------------------------------------------------------
// Captura de rede (HAR): ideia do Poring — um botão tipo "gravar", clica pra
// começar, reproduz o bug, clica de novo pra parar e salvar um arquivo .har
// (o mesmo formato que o Chrome DevTools exporta em Network > Save all as
// HAR). Usamos o protocolo de depuração do Chromium (CDP) via
// webContents.debugger — o mesmo mecanismo por trás do próprio DevTools —
// para escutar TODA requisição de rede da conta em silêncio, sem precisar
// abrir o DevTools visualmente.
// ---------------------------------------------------------------------------
const networkRecordings = new Map(); // webContentsId -> { requests: Map, contents }
function buildHarEntry(reqData) {
  const req = reqData.request || {};
  const res = reqData.response || {};
  const headersToArray = (h) => Object.entries(h || {}).map(([name, value]) => ({ name, value: String(value) }));
  const startedDateTime = new Date(reqData.wallTime ? reqData.wallTime * 1000 : Date.now()).toISOString();
  const time = reqData.endTimestamp && reqData.startTimestamp
    ? Math.max(0, Math.round((reqData.endTimestamp - reqData.startTimestamp) * 1000))
    : -1;
  return {
    startedDateTime,
    time,
    request: {
      method: req.method || 'GET',
      url: req.url || '',
      httpVersion: 'HTTP/1.1',
      cookies: [],
      headers: headersToArray(req.headers),
      queryString: [],
      headersSize: -1,
      bodySize: req.postData ? Buffer.byteLength(req.postData) : 0,
      postData: req.postData ? { mimeType: (req.headers && req.headers['Content-Type']) || 'text/plain', text: req.postData } : undefined,
    },
    response: {
      status: res.status || 0,
      statusText: res.statusText || '',
      httpVersion: 'HTTP/1.1',
      cookies: [],
      headers: headersToArray(res.headers),
      content: {
        size: reqData.encodedDataLength || 0,
        mimeType: res.mimeType || 'application/octet-stream',
      },
      redirectURL: '',
      headersSize: -1,
      bodySize: reqData.encodedDataLength || 0,
    },
    cache: {},
    timings: { send: 0, wait: time > 0 ? time : 0, receive: 0 },
    _resourceType: reqData.resourceType || '',
    _error: reqData.error || undefined,
  };
}
ipcMain.handle('network-record-start', async (event, data) => {
  try {
    const webContentsId = data && data.webContentsId;
    const contents = webContentsId != null ? webContents.fromId(webContentsId) : null;
    if (!contents) return { ok: false, error: 'Conta não encontrada.' };
    if (networkRecordings.has(webContentsId)) return { ok: true }; // já gravando

    const dbg = contents.debugger;
    try { dbg.attach('1.3'); }
    catch (err) {
      return { ok: false, error: 'Não foi possível anexar o depurador (o DevTools já pode estar aberto nessa conta).' };
    }

    const recSession = { requests: new Map(), contents };
    networkRecordings.set(webContentsId, recSession);

    dbg.on('message', (_evt, method, params) => {
      const s = networkRecordings.get(webContentsId);
      if (!s) return;
      if (method === 'Network.requestWillBeSent') {
        s.requests.set(params.requestId, {
          request: {
            method: params.request.method,
            url: params.request.url,
            headers: params.request.headers,
            postData: params.request.postData,
          },
          wallTime: params.wallTime,
          startTimestamp: params.timestamp,
          resourceType: params.type,
        });
      } else if (method === 'Network.responseReceived') {
        const r = s.requests.get(params.requestId);
        if (r) {
          r.response = {
            status: params.response.status,
            statusText: params.response.statusText,
            headers: params.response.headers,
            mimeType: params.response.mimeType,
          };
        }
      } else if (method === 'Network.loadingFinished') {
        const r = s.requests.get(params.requestId);
        if (r) {
          r.endTimestamp = params.timestamp;
          r.encodedDataLength = params.encodedDataLength;
        }
      } else if (method === 'Network.loadingFailed') {
        const r = s.requests.get(params.requestId);
        if (r) {
          r.endTimestamp = params.timestamp;
          r.error = params.errorText;
        }
      }
    });

    await dbg.sendCommand('Network.enable');
    return { ok: true };
  } catch (err) {
    return { ok: false, error: String(err) };
  }
});
ipcMain.handle('network-record-stop', async (event, data) => {
  try {
    const webContentsId = data && data.webContentsId;
    const harName = data && data.harName;
    const recSession = networkRecordings.get(webContentsId);
    if (!recSession) return { ok: false, error: 'Nenhuma gravação em andamento para essa conta.' };
    const { contents, requests } = recSession;
    try { await contents.debugger.sendCommand('Network.disable'); } catch (e) { /* ignore */ }
    try { contents.debugger.detach(); } catch (e) { /* ignore */ }
    networkRecordings.delete(webContentsId);

    const entries = [...requests.values()].map(buildHarEntry);
    const har = {
      log: {
        version: '1.2',
        creator: { name: 'Idle Hub Kit-Ticket', version: '1.0' },
        pages: [],
        entries,
      },
    };
    const folder = ensureReportFolder();
    const harPath = path.join(folder, harName || `network-${Date.now()}.har`);
    fs.writeFileSync(harPath, JSON.stringify(har, null, 2), 'utf-8');

    // Diagnóstico do Poring: window.__midgardIdlePresentationTimelineDiagnostics
    // + window.__midgardIdleGameSocketDiagnostics (capture = {presentation, receipts, socket})
    // — salvo como arquivo irmão do .har, mesmo nome base, sufixo -diagnostics.json.
    let diagnosticsPath = null;
    const diagnosticsSnapshot = data && data.diagnosticsSnapshot;
    if (diagnosticsSnapshot != null) {
      const base = (harName || `network-${Date.now()}.har`).replace(/\.har$/i, '');
      diagnosticsPath = path.join(folder, `${base}-diagnostics.json`);
      try {
        fs.writeFileSync(diagnosticsPath, JSON.stringify(diagnosticsSnapshot, null, 2), 'utf-8');
      } catch (err) {
        console.error('Falha ao salvar snapshot de diagnóstico:', err);
        diagnosticsPath = null;
      }
    }

    shell.openPath(folder);
    return { ok: true, harPath, diagnosticsPath, totalRequests: entries.length };
  } catch (err) {
    return { ok: false, error: String(err) };
  }
});
// ---------------------------------------------------------------------------
// Controles de janela custom
// ---------------------------------------------------------------------------
ipcMain.on('win-minimize', (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  if (win) win.minimize();
});
ipcMain.on('win-maximize', (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  if (!win) return;
  if (win.isMaximized()) win.unmaximize();
  else win.maximize();
});
ipcMain.on('win-close', (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  if (win) win.close();
});
ipcMain.handle('toggle-fullscreen', (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  if (!win) return false;
  const next = !win.isFullScreen();
  win.setFullScreen(next);
  return next;
});
ipcMain.handle('is-fullscreen', (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  return win ? win.isFullScreen() : false;
});
ipcMain.handle('open-external', (event, url) => {
  if (/^https?:\/\//i.test(url)) shell.openExternal(url);
});
function fetchJson(url) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, {
      headers: { 'User-Agent': 'idle-hub-update-check', Accept: 'application/vnd.github+json' },
    }, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try { resolve(JSON.parse(data)); } catch (err) { reject(err); }
      });
    });
    req.on('error', reject);
    req.setTimeout(10000, () => req.destroy(new Error('timeout')));
  });
}
// Verificação de atualização via um Gist do GitHub contendo um JSON simples
// tipo { "version": "1.3.0", "url": "...", "message": "..." }. Compara com a
// versão real do app (package.json) — SEM baixar/instalar nada, só avisa.
ipcMain.handle('check-for-updates', async (event, gistUrl) => {
  try {
    const match = String(gistUrl || '').match(/gist\.github(?:usercontent)?\.com\/[^/]+\/([a-f0-9]+)/i);
    const gistId = match ? match[1] : null;
    if (!gistId) return { ok: false, error: 'invalid-url' };
    const data = await fetchJson(`https://api.github.com/gists/${gistId}`);
    if (!data || !data.files) return { ok: false, error: 'gist-error' };
    const fileKeys = Object.keys(data.files);
    const fileKey = fileKeys.find((k) => k.toLowerCase().endsWith('.json')) || fileKeys[0];
    if (!fileKey || !data.files[fileKey] || typeof data.files[fileKey].content !== 'string') {
      return { ok: false, error: 'no-file' };
    }
    let remote;
    try { remote = JSON.parse(data.files[fileKey].content); }
    catch (err) { return { ok: false, error: 'bad-json' }; }
    if (!remote || !remote.version) return { ok: false, error: 'no-version-field' };
    const localVersion = app.getVersion();
    return {
      ok: true,
      upToDate: String(remote.version) === String(localVersion),
      remoteVersion: remote.version,
      localVersion,
      updateUrl: remote.url || null,
      message: remote.message || null,
    };
  } catch (err) {
    return { ok: false, error: String(err) };
  }
});
